package com.formbuilder.sdk.presenter.fragments

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Rect
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.INVISIBLE
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance.Companion.APPEARANCE_COLORS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.LINEAR_PROGRESS_INDICATOR_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.LINEAR_PROGRESS_TRACK_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.PROGRESS_BAR_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.SHOW_CANCEL_BUTTON
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TOAST_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TOAST_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TOAST_TEXT_SIZE
import com.formbuilder.sdk.databinding.FragmentDocDataBinding
import com.formbuilder.sdk.presenter.activities.FormBuilderMainActivity
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.Constants
import com.formbuilder.sdk.utils.Constants.CURRENT
import com.formbuilder.sdk.utils.Constants.HEIGHT
import com.formbuilder.sdk.utils.Constants.MAX
import com.formbuilder.sdk.utils.Constants.MESSAGE
import com.formbuilder.sdk.utils.Constants.NN_CONNECTED
import com.formbuilder.sdk.utils.Constants.OCR
import com.formbuilder.sdk.utils.Constants.OCR_PROGRESS
import com.formbuilder.sdk.utils.Constants.POSITION
import com.formbuilder.sdk.utils.Constants.QUALITY
import com.formbuilder.sdk.utils.Constants.RECTANGLE
import com.formbuilder.sdk.utils.Constants.START_CAMERA
import com.formbuilder.sdk.utils.Constants.STATUS
import com.formbuilder.sdk.utils.Constants.STOP
import com.formbuilder.sdk.utils.Constants.TYPE
import com.formbuilder.sdk.utils.Constants.WIDTH
import com.formbuilder.sdk.utils.Constants.X_COORDINATE
import com.formbuilder.sdk.utils.Constants.Y_COORDINATE
import com.formbuilder.sdk.utils.EdgeToEdgeHelper
import com.formbuilder.sdk.utils.EdgeToEdgeHelper.applyStatusBarForSystemTheme
import com.formbuilder.sdk.utils.KYCStatuses
import com.formbuilder.sdk.utils.SDKProperties
import com.formbuilder.sdk.utils.SDKProperties.aspectRatio
import com.formbuilder.sdk.utils.SDKProperties.blackLineRatio
import com.formbuilder.sdk.utils.helpers.multimedia.FrameHandler
import com.formbuilder.sdk.utils.helpers.multimedia.VideoEncoder
import com.formbuilder.sdk.utils.managers.KoinInitializer
import com.formbuilder.sdk.utils.managers.MessageListener
import com.formbuilder.sdk.utils.managers.NetworkOutputStream
import com.formbuilder.sdk.utils.managers.WebSocketManager
import kotlinx.coroutines.launch
import org.json.JSONObject
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf
//import org.webrtc.IceCandidate
//import org.webrtc.SessionDescription
import java.io.IOException

class FBDocDataFragment() : Fragment(), MessageListener {

    private val uiHolder by lazy { arguments?.getParcelable<UIHolder>(UI_HOLDER) }
    private var lastStatus: String = ""
    private val webSocketManager: WebSocketManager by inject {
        parametersOf(
            uiHolder?.section?.settings?.streamUrl + "mobile/android",
            uiHolder?.section?.settings?.userHash
        )
    }
    private var _binding: FragmentDocDataBinding? = null
    private val binding get() = _binding
    private val mViewModel: FBDocDataViewModel by viewModel()
//    private var answerSessionDescription: SessionDescription? = null
    private var networkOutputStream: NetworkOutputStream? = null
    private var frameHandler: FrameHandler? = null
    private var videoEncoder: VideoEncoder? = null
    private var isStreaming: Boolean = false
    private var isCheckingFace: Boolean = false
    private var connectNum: Int = 0
    private var paint = Paint()
    private lateinit var rect: Rect
    private var width: Int = 0
    private var height: Int = 0
    private var x: Float = 0F
    private var y: Float = 0F
    private var previewHeight: Int = 0
    private var previewWidth: Int = 0
    private var isBackCamera = false
    private var isNNConnected = true
    private var isViewDestroyed = false
    private lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        preferences = context?.getSharedPreferences(APPEARANCE_COLORS, Context.MODE_PRIVATE)!!

        KoinInitializer.initializeIfNeeded(requireContext())
        connectWebSocket()
        binding?.docDataLocalView?.setWebSocketManager(webSocketManager)
        lifecycleScope.launchWhenStarted {
            while (true) {
                val message = mViewModel.observeErrorChannel().receive()
                Toast.makeText(requireContext(), "Error - $message", Toast.LENGTH_LONG)
                    .show()
            }
        }

        mViewModel.observeGetStepSectionView().observe(this) {
            webSocketManager.close()
            mViewModel.cancelCoroutines()
            _binding?.docDataLocalView?.stop()
            stopStreaming()
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            _binding?.container?.visibility = GONE
            _binding?.startProgress?.visibility = GONE
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            activity?.window?.statusBarColor = resources.getColor(R.color.background_color)
            activity?.window?.applyStatusBarForSystemTheme(resources.configuration)
            (activity as? AppCompatActivity)?.findViewById<View>(R.id.svLayout)
                ?.setBackgroundColor(resources.getColor(R.color.background_color))
            binding?.root?.let { it1 -> EdgeToEdgeHelper.applyStatusBarColor(it1, binding!!.statusBarBackground, R.color.background_color) }
            val act = activity as? FormBuilderMainActivity
            if (act != null && !act.isFinishing && !act.isDestroyed) {
                act.navigateForwardPagerAdapter(it)
            }
            //(activity as FormBuilderMainActivity).navigateForward(it)

        }
        Log.i("WEBSOCKET", "DOC_DATA ON_CREATE")
    }

//    override fun onStart() {
//        super.onStart()
//        KoinInitializer.initializeIfNeeded(requireContext())
//    }

    private fun idStatuses(type: String){
        //startStreaming()
        Log.i("WEBSOCKET", "statusServer "+ type )
        when (type) {
            KYCStatuses.KYC_STATUS_ID_HOLOS_TILT_ID.toString() ->{
                if (lastStatus != type){
                    if (_binding?.startProgress?.isVisible == true)
                        _binding?.startProgress?.visibility = GONE
                    switchCamera(true)
                    _binding?.shadowFace?.visibility = GONE
                    lastStatus = type
                }
            }
            KYCStatuses.KYC_STATUS_ID_PREPARE_FACE.toString(),
            KYCStatuses.KYC_STATUS_ID_PREPARE_BACK.toString() -> {
                if (lastStatus != type){
                    if (_binding?.startProgress?.isVisible == true)
                        _binding?.startProgress?.visibility = GONE
                    activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                    activity?.window?.statusBarColor = resources.getColor(R.color.black)
                    activity?.window?.let { EdgeToEdgeHelper.setStatusBarTextDark(it, false) }
                    (activity as? AppCompatActivity)?.findViewById<View>(R.id.svLayout)?.setBackgroundColor(resources.getColor(R.color.black))
                    binding?.root?.let { it1 -> EdgeToEdgeHelper.applyStatusBarColor(it1, binding!!.statusBarBackground, R.color.black) }
                    _binding?.shadowFace?.visibility = GONE
                    _binding?.shadowID?.visibility = VISIBLE
                    switchCamera(true)
                    lastStatus = type
                }
                isCheckingFace = false
            }
            KYCStatuses.KYC_STATUS_ID_NO_FACE.toString(),
            KYCStatuses.KYC_STATUS_ID_NO_BACK.toString() -> {
                lastStatus = type
            }

            KYCStatuses.KYC_STATUS_ID_BACK_OK.toString() ->{
                _binding?.shadowFace?.visibility = GONE
                _binding?.shadowID?.visibility = GONE
            }
            KYCStatuses.KYC_STATUS_SELFIE_PREPARE_HEAD.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_TURN_HEAD.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_TOUCH_ELEMENT.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_AFTER_ID_PREPARE_HEAD.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_CLOSE_EYE.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_OPEN_MOUTH.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_NO_HEAD.toString() -> {
                if (lastStatus != type){
                    if (_binding?.startProgress?.isVisible == true)
                        _binding?.startProgress?.visibility = GONE
                        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                        activity?.window?.statusBarColor = resources.getColor(R.color.black)
                        activity?.window?.let { EdgeToEdgeHelper.setStatusBarTextDark(it, false) }
                        (activity as? AppCompatActivity)?.findViewById<View>(R.id.svLayout)?.setBackgroundColor(resources.getColor(R.color.black))
                        binding?.root?.let { it1 -> EdgeToEdgeHelper.applyStatusBarColor(it1, binding!!.statusBarBackground, R.color.black) }
                        switchCamera(isBackFacing = false)
                        _binding?.shadowFace?.visibility = VISIBLE
                        _binding?.shadowID?.visibility = GONE

                }
                isCheckingFace = true
            }
            KYCStatuses.FAILED_NO_VIDEO_STREAM_SERVER.toString() -> {
                webSocketManager.close()
                activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                _binding?.container?.visibility = GONE
            }

            KYCStatuses.KYC_STATUS_SELFIE_OK.toString(),
            KYCStatuses.PROCESS_SUCCESS.toString()
            -> {
                finishProcess()
                ProcessResult.setProcessResult(true)

            }
            KYCStatuses.KYC_STATUS_FAILED.toString(),
            KYCStatuses.PROCESS_FAIL.toString()
            -> {
                finishProcess()
                ProcessResult.setProcessResult(false)
            }
            KYCStatuses.KYC_STATUS_ID_FACE_RESTARTING.toString(),
            KYCStatuses.KYC_STATUS_ID_NO_FACE_HOLOS.toString(),
            KYCStatuses.KYC_STATUS_ID_FACE_OK.toString(),
            KYCStatuses.KYC_STATUS_ID_BACK_RESTARTING.toString(),
            KYCStatuses.KYC_WAIT_FOR_VIDEO_STREAM.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_PREPARE_HEAD.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_EYE_IS_CLOSED_THANK_YOU.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_NO_CLOSED_EYE.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_EYE_IS_OPENED_THANK_YOU.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_NO_OPENED_MOUTH.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_RESTARTING.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_HEAD_TURNED.toString(),
            KYCStatuses.KYC_STATUS_ROI_NOT_FOUND.toString(),
            KYCStatuses.KYC_STATUS_IMAGE_TOO_SMALL.toString(),
            KYCStatuses.KYC_STATUS_SELFIE_NO_TURNED_HEAD.toString() ->{}
            KYCStatuses.STOP_MEDIA.toString() -> {
                _binding?.docDataLocalView?.stop()
                stopStreaming()
                _binding?.topBlackLine?.visibility = GONE
                _binding?.bottomBlackLine?.visibility = GONE
                _binding?.container?.visibility = GONE
                _binding?.endSessionButton?.visibility = GONE
                _binding?.surfaceView?.visibility = GONE
                _binding?.startProgress?.visibility = VISIBLE
            }
            KYCStatuses.NO_NN_SERVER.toString() -> {
                isNNConnected = false
            }
        }
        showToast(type)
    }

    private fun finishProcess(){
        _binding?.topBlackLine?.visibility = GONE
        _binding?.bottomBlackLine?.visibility = GONE
        _binding?.container?.visibility = GONE
        _binding?.endSessionButton?.visibility = GONE
        _binding?.startProgress?.visibility = VISIBLE
        webSocketManager.close()
        stopStreaming()
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        activity?.window?.statusBarColor = resources.getColor(R.color.background_color)
        activity?.window?.applyStatusBarForSystemTheme(resources.configuration)
        (activity as? AppCompatActivity)?.findViewById<View>(R.id.svLayout)
            ?.setBackgroundColor(resources.getColor(R.color.background_color))
        binding?.root?.let { it1 -> EdgeToEdgeHelper.applyStatusBarColor(it1, binding!!.statusBarBackground, R.color.background_color) }
        val direction = if (isNNConnected) uiHolder?.section?.directionId else uiHolder?.section?.settings?.noServiceDirectionStepId
        mViewModel.getStep(
            uiHolder?.section?.submissionId ?: "",
            direction ?: "",
            uiHolder?.section?.directionId ?: "",
            stepFields = emptyList()
        )
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        isViewDestroyed = false

        _binding = FragmentDocDataBinding.inflate(inflater, container, false)
        _binding?.docDataLocalView?.setWebSocketManager(webSocketManager)
        _binding?.progressBar?.trackColor = preferences.getInt(LINEAR_PROGRESS_TRACK_COLOR, ContextCompat.getColor(requireContext(), R.color.black))
        _binding?.progressBar?.setIndicatorColor(preferences.getInt(LINEAR_PROGRESS_INDICATOR_COLOR, ContextCompat.getColor(requireContext(), R.color.a1_color)))
        _binding?.circularProgress?.indeterminateDrawable?.colorFilter = PorterDuffColorFilter(preferences.getInt(PROGRESS_BAR_COLOR, ContextCompat.getColor(requireContext(), R.color.teal_700)), PorterDuff.Mode.SRC_IN)
        _binding?.docDataLayout?.setBackgroundColor(preferences.getInt(BACKGROUND_COLOR, ContextCompat.getColor(requireContext(), R.color.background_color)))
        _binding?.guideTextview?.apply {
            val font = preferences.getInt(TOAST_FONT, 0)
            if (font != 0){
                val tf = font.let { ResourcesCompat.getFont(context, it) }
                if (tf != null) {
                    typeface = tf
                }
            }
            if (preferences.getInt(TOAST_TEXT_SIZE, 0) != 0){
                textSize = preferences.getInt(TOAST_TEXT_SIZE, 18).toFloat()
            }
            setTextColor(preferences.getInt(TOAST_TEXT_COLOR, ContextCompat.getColor(requireContext(),R.color.white)))
        }
        return _binding?.root
    }

    private fun showToast(type: String?){
        var message = ""
        for (field in uiHolder?.section?.fields!!)
            if (field.specialType.equals(type))
                message = field.label.toString()

        if (_binding?.container?.isVisible == false && !message.isEmpty())
            _binding?.container?.visibility = VISIBLE
        if (_binding?.guideTextview?.text != message)
            _binding?.guideTextview?.text = message
    }

    private fun switchCamera(isBackFacing: Boolean){
        if (_binding?.startProgress?.isVisible == true)
            _binding?.startProgress?.visibility = GONE

        if (_binding?.docDataLocalView?.visibility == GONE){
            _binding?.docDataLocalView?.visibility = VISIBLE
            _binding?.endSessionButton?.visibility = VISIBLE
        }
        isBackCamera = isBackFacing
        _binding?.docDataLocalView?.setWebSocketManager(webSocketManager)
        _binding?.docDataLocalView?.swapCamera(isBackFacing)
    }

    private fun connectWebSocket(){
        webSocketManager.setMessageListener(this)
        webSocketManager.connect()
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (preferences.getBoolean(SHOW_CANCEL_BUTTON, false)){
            _binding?.endSessionButton?.visibility = VISIBLE
        }
       _binding?.endSessionButton?.setOnClickListener {
           webSocketManager.close()
           activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
           _binding?.docDataLayout?.visibility = GONE
           activity?.onBackPressed()
           FormFragment.ProcessResult.setClosedForm("")
       }
        _binding?.closeButton?.setOnClickListener{
            _binding?.docDataLayout?.visibility = GONE
            activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            activity?.onBackPressed()
        }
    }

    private fun startStreaming(isBackFacing: Boolean = true){
        Log.i("WEBSOCKET","shouldStartStreaming " + isStreaming.toString())
        if (!isStreaming){
            Log.i("WEBSOCKET", "startedStreaming")
            isStreaming = true

            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            networkOutputStream = NetworkOutputStream(webSocketManager)
            frameHandler = FrameHandler(networkOutputStream)
            switchCamera(isBackFacing)
            _binding?.surfaceView?.visibility = VISIBLE
            try {
                videoEncoder = VideoEncoder(_binding?.docDataLocalView, frameHandler)
                val cameraView = _binding?.docDataLocalView as View
                cameraView.layoutParams.height = (cameraView.width * aspectRatio).toInt()
                //_binding?.surfaceView?.layoutParams?.height = (cameraView.width * 1.33).toInt()

                val displayMetrics = DisplayMetrics()
                (context as Activity?)!!.windowManager.defaultDisplay.getMetrics(displayMetrics)
                val blackLineHeight = (displayMetrics.heightPixels - (cameraView.width * 1.33)) / blackLineRatio

                (_binding?.topBlackLine as View).layoutParams.height = blackLineHeight.toInt()
                (_binding?.bottomBlackLine as View).layoutParams.height = blackLineHeight.toInt()

                _binding?.topBlackLine?.visibility = VISIBLE
                _binding?.bottomBlackLine?.visibility = VISIBLE
                videoEncoder?.start()
            } catch (e: Exception) {
                try {
                    networkOutputStream?.close()
                    networkOutputStream = null
                    frameHandler?.close()
                    frameHandler = null
                    videoEncoder?.close()
                    videoEncoder = null
                } catch (_: IOException) { }
            }
        }
    }

   private fun stopStreaming() {
        isStreaming = false
        try {
            //_binding?.docDataLocalView?.stop()
            networkOutputStream?.close()
            networkOutputStream = null
            frameHandler?.close()
            frameHandler = null
            videoEncoder?.close()
            videoEncoder = null
            Log.i("WEBSOCKET", "stoppedStreaming")
        } catch (_: java.lang.Exception) { }
    }


    override fun onConnectSuccess() {
        webSocketManager.sendMessage(Constants.SOCKET_COMMAND_JOIN)
//      Had to be called one time to init server
//        lifecycleScope.launchWhenStarted {
//                mViewModel.getDocDataStatus(
//                    uiHolder?.section?.submissionId ?: "",
//                    uiHolder?.section?.settings?.userHash ?: ""
//                )
//                Log.i("WEBSOCKET", "getDocDataStatus")
//        }
    }

    override fun onConnectFailed() {
        if (!isViewDestroyed){
            Log.i("WEBSOCKET", "onConnectFailedCalled")
            //showOnConnectionLostDialog()
            //mViewModel.cancelCoroutines()
            webSocketManager.close()
            stopStreaming()
            webSocketManager.setMessageListener(this)
            webSocketManager.reconnect()
        }
    }

    override fun onClose(code: Int) {
       // Log.i("WEBSOCKET", "onCloseCalled")
    }

    override fun onMessage(text: String) {
        Log.d("WEBSOCKET", text)
        val json = JSONObject(text)

        when (json.optString(Constants.SOCKET_COMMAND_CMD)) {
            Constants.SOCKET_COMMAND_HB -> {
                webSocketManager.sendMessage(Constants.SOCKET_COMMAND_HB)
            }
            Constants.SOCKET_PEER -> {
                webSocketManager.sendMessage(Constants.SOCKET_GOT_PEER)
                webSocketManager.sendPeerAnswer()
            }
            OCR_PROGRESS ->{
                requireActivity().runOnUiThread {
                    val current = json.getString(CURRENT).toInt()
                    val max = json.getString(MAX).toInt()
                    showProgress(current, max)
                }
            }
            OCR ->{
                if (json.getString(TYPE) == STOP){
                    lifecycleScope.launchWhenStarted {
                    if (_binding?.progressBar?.isVisible == true){
                        _binding?.progressBar?.visibility = INVISIBLE
                        _binding?.progressBar?.progress = 0
                        _binding?.progressBar?.max = 0
                        }
                    }
                }
            }
            QUALITY -> {
                val message = json.getString(MESSAGE)
                if (message.equals("ok", ignoreCase = true))
                    changeCutOutBackground(0,0,0)
                else
                    changeCutOutBackground(255,59,48)
            }

            STATUS -> {
                lifecycleScope.launchWhenStarted{
                    idStatuses(json.getString(TYPE))
                }
            }

            START_CAMERA -> {
                lifecycleScope.launchWhenStarted {
                    isBackCamera = json.getString(TYPE).equals("back")
                }
            }

            NN_CONNECTED -> {
                lifecycleScope.launchWhenStarted {
                    startStreaming(isBackCamera)
                }
            }

            RECTANGLE -> {
                lifecycleScope.launchWhenStarted {
                    width   = json.getString(WIDTH).toInt()
                    height  = json.getString(HEIGHT).toInt()
                    x       = if(isBackCamera) json.getString(X_COORDINATE).toFloat() else 1 - json.getString(X_COORDINATE).toFloat()
                    y       = json.getString(Y_COORDINATE).toFloat()
                    paint.color = resources.getColor(R.color.white)
                    paint.style = Paint.Style.FILL
                    drawWhiteSquare(height, width, x, y, paint)
                }
            }

            POSITION -> {
                lifecycleScope.launchWhenStarted {
                    val xFinger = json.getString(X_COORDINATE).toFloat()
                    val yFinger = json.getString(Y_COORDINATE).toFloat()

                    if (Math.abs((xFinger * previewWidth) - (x * previewWidth)) < 20 && Math.abs((yFinger * previewHeight) - ( y * previewHeight)) < 20)
                        paint.color = resources.getColor(R.color.white)
                    else
                        paint.color = resources.getColor(R.color.semi_transparent_white)

                    paint.style = Paint.Style.FILL
                    drawWhiteSquare(height, width, x, y, paint)
                }
            }
        }
    }

    private fun showOnConnectionLostDialog(){
        mViewModel.viewModelScope.launch {
            val alertDialog = AlertDialog.Builder(context)

            alertDialog.apply {
                setCancelable(false)
                setTitle("There is no video server")
                setMessage("Please try again later.")
                setPositiveButton("OK") {_,_ ->
                    requireActivity().onBackPressed()}

                setOnDismissListener {
                    requireActivity().onBackPressed()
                }

            }.create().show()
        }
    }

    private fun changeCutOutBackground(r:Int, g:Int, b:Int){
        if (isCheckingFace){
            _binding?.shadowFace?.backgroundPaint = Paint().apply {
                setARGB(80, r, g, b)
            }
            _binding?.shadowFace?.invalidate()
        }else{
            _binding?.shadowID?.backgroundPaint = Paint().apply {
                setARGB(80, r, g, b)
            }
            _binding?.shadowID?.invalidate()
        }
    }

//    override fun onIceCandidateReceived(iceCandidate: IceCandidate) {}
//
//    override fun onAnswerReceived(description: SessionDescription) {
//        answerSessionDescription = description
//    }

    private fun showProgress(current: Int, max: Int){
        _binding?.progressBar?.max = max
        _binding?.progressBar?.visibility = VISIBLE
        if (current in 1..max)
            ObjectAnimator.ofInt(_binding?.progressBar, "progress",current).start()
    }

    private fun drawWhiteSquare(height: Int, width: Int, x: Float, y: Float, paint: Paint){
        previewHeight  = _binding?.docDataLocalView?.height?.minus((2 * binding?.bottomBlackLine?.height!!))!!
        previewWidth   = _binding?.docDataLocalView?.width!!

        _binding?.surfaceView?.layoutParams?.height = previewHeight
        _binding?.surfaceView?.layoutParams?.width  = previewWidth
        _binding?.surfaceView?.setZOrderOnTop(true)
        _binding?.surfaceView?.holder?.setFormat(PixelFormat.TRANSPARENT)
        _binding?.surfaceView?.holder?.surface

        val canvas = binding?.surfaceView?.holder?.lockCanvas()
        canvas?.drawColor( 0, PorterDuff.Mode.CLEAR );
        rect = Rect(
            (x * previewWidth!!).toInt(),
            (y * previewHeight!!).toInt(),
            ((x * previewWidth) + width).toInt(),
            ((y * previewHeight) + height).toInt()
        )
        canvas?.drawRect(rect, paint)
        _binding?.surfaceView?.holder?.unlockCanvasAndPost(canvas)
    }

    override fun onDestroyView() {
        _binding?.docDataLocalView?.stop()
        isViewDestroyed = true
        super.onDestroyView()
        _binding = null
        Log.d("WEBSOCKET", "View destroyed " + isViewDestroyed)
    }

    override fun onDestroy() {
        webSocketManager.close()
        stopStreaming()
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        super.onDestroy()
    }

    companion object {
        const val UI_HOLDER = "UI_HOLDER"

        fun newInstance(uiHolder: UIHolder?): FBDocDataFragment {
            val fragment = FBDocDataFragment()
            val bundle = Bundle().apply {
                putParcelable(UI_HOLDER, uiHolder)
            }
            fragment.arguments = bundle
            return fragment
        }
    }

    object ProcessResult {

        private var result: (( Boolean) -> Unit)? = null

        fun setProcessResult(isSuccessful: Boolean) {
            result?.invoke(isSuccessful)
        }

        fun getProcessResultCallback(callback: (Boolean) -> Unit) {
            this.result = callback
        }
    }
}