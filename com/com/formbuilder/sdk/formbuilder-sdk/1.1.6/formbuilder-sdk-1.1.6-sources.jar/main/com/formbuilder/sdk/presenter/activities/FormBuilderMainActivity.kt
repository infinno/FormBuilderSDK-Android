package com.formbuilder.sdk.presenter.activities

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance.Companion.APPEARANCE_COLORS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.PROGRESS_BAR_COLOR
import com.formbuilder.sdk.data.models.SectionType
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.databinding.ActivityFormBuilderMainBinding
import com.formbuilder.sdk.presenter.activities.StartFormBuilderActivity.Companion.UI_HOLDER
import com.formbuilder.sdk.presenter.common.PagerAdapter
import com.formbuilder.sdk.presenter.common.SectionSubmittedListener
import com.formbuilder.sdk.presenter.fragments.FBCameraFragment
import com.formbuilder.sdk.presenter.fragments.FBCreditCalculatorFragment
import com.formbuilder.sdk.presenter.fragments.FBDocDataFragment
import com.formbuilder.sdk.presenter.fragments.FormFragment
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.EdgeToEdgeHelper
import com.formbuilder.sdk.utils.EdgeToEdgeHelper.applyStatusBarForSystemTheme
import com.formbuilder.sdk.utils.managers.KoinInitializer
import org.koin.androidx.viewmodel.ext.android.viewModel

class FormBuilderMainActivity : AppCompatActivity(), SectionSubmittedListener{

    private lateinit var binding: ActivityFormBuilderMainBinding
    private val allAnswers = mutableListOf<StepField>()
    private val mViewModel: FormBuilderMainActivityViewModel by viewModel()
    private var pagerAdapter: PagerAdapter? = null
    private var uiHolder: UIHolder? = null
    private lateinit var preferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        KoinInitializer.initializeIfNeeded(this@FormBuilderMainActivity)
        binding = ActivityFormBuilderMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EdgeToEdgeHelper.applyFullInsets(this.window, binding.root)
        EdgeToEdgeHelper.applyStatusBarColor(binding.root, binding.statusBarBackground, R.color.background_color)
        window?.applyStatusBarForSystemTheme(resources.configuration)
        preferences = this.getSharedPreferences(APPEARANCE_COLORS, Context.MODE_PRIVATE)
        window?.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window?.statusBarColor = resources.getColor(R.color.background_color)
        pagerAdapter = PagerAdapter(supportFragmentManager, intent.getParcelableExtra(UI_HOLDER))
        uiHolder = intent.getParcelableExtra(UI_HOLDER)
        Log.i("WEBSOCKET", "FB_MAIN_ACT pager uiHolder: " + uiHolder.toString())
        binding.activityMainViewPager.adapter = pagerAdapter
        binding.progressBar.indeterminateDrawable?.colorFilter = PorterDuffColorFilter(preferences.getInt(PROGRESS_BAR_COLOR, ContextCompat.getColor(this, R.color.teal_700)), PorterDuff.Mode.SRC_IN)
        binding.svLayout.setBackgroundColor(preferences.getInt(BACKGROUND_COLOR, ContextCompat.getColor(this, R.color.background_color)))

        lifecycleScope.launchWhenStarted {
            while (true) {
                val message = mViewModel.observeErrorChannel().receive()
                Toast.makeText(this@FormBuilderMainActivity, "Error - $message", Toast.LENGTH_LONG)
                    .show()
            }
        }

        mViewModel.observeLoading().observe(this) {
            binding.progressBar.visibility = if (it) VISIBLE else GONE
        }

        mViewModel.observeFormBuilderView().observe(this) {
            //binding.activityMainViewPager.visibility = GONE
            //addFragmentToActivity(getFragment(it))
            if (it.section?.type == "END"){
                FormFragment.ProcessResult.setPostToHostUI(it.section?.externalKYCStatus.toString().takeIf { !it.isNullOrEmpty() } ?: "End")
            }
            else{
                pagerAdapter?.updateUIHolder(it)
                Log.i("WEBSOCKET", "FB_MAIN_ACT uiHolder: " + it.toString())
            }
        }
        Log.i("WEBSOCKET", "FB_MAIN_ACT ON_CREATE")
    }

    override fun onStart() {
        super.onStart()
        KoinInitializer.initializeIfNeeded(this@FormBuilderMainActivity)
        Log.i("WEBSOCKET", "FB_MAIN_ACT ON_Start")
    }

    private fun addFragmentToActivity(fragment: Fragment) {
        val fm = supportFragmentManager
        val tr = fm.beginTransaction()
        tr.replace(R.id.activity_main_fragment_container, fragment)
        tr.commitAllowingStateLoss()
        Log.i("WEBSOCKET", "FB_MAIN_ACT ADD_FRAGMENT")
    }

    override fun onSectionSubmittedWithValidAnswers(
        submissionId: String,
        directionId: String,
        fromDirectionId: String,
        fromFlowDirectionId: String,
        answers: List<StepField>,
        activityId: Int?
    ) {
        answers.forEach { newAnswer ->
            allAnswers.removeAll {
                it.key == newAnswer.key
            }
        }
        allAnswers.addAll(answers)

        //if last step, then submit all answers
        mViewModel.getStep(
            submissionId,
            directionId,
            fromDirectionId = fromDirectionId,
            fromFlowFieldId = fromFlowDirectionId,
            stepFields = answers
        )
        Log.i("WEBSOCKET", "FB_MAIN_ACT sectionSubmitted")
    }

    override fun onBackPressed() {
        val count = supportFragmentManager.backStackEntryCount

        if (count == 0) {
            super.onBackPressed()
            //additional code
        } else {
            supportFragmentManager.popBackStack()
            binding.activityMainViewPager.visibility = VISIBLE
        }
    }

    fun navigateForward(uiHolder: UIHolder) {
        binding.activityMainViewPager.visibility = GONE
        addFragmentToActivity(getFragment(uiHolder))
    }

    fun navigateForwardPagerAdapter(uiHolder: UIHolder) {
        pagerAdapter?.updateUIHolder(uiHolder)
        Log.i("WEBSOCKET", "FB_MAIN_ACT navigateForward")
    }

    fun handleProgressBarVisibility(isVisible: Boolean) {
        binding.progressBar.visibility = if (isVisible) VISIBLE else GONE
    }

    private fun getFragment(uiHolder: UIHolder?): Fragment {
        return when (uiHolder?.section?.type) {
            SectionType.FORM.name,
            SectionType.FLOW.name -> FormFragment.newInstance(uiHolder)
            SectionType.SELFIE.name -> FBCameraFragment.newInstance(uiHolder)
            SectionType.KYC_ID.name,
            SectionType.DOC_DATA.name -> FBDocDataFragment.newInstance(uiHolder)
            SectionType.CREDIT_CALCULATOR.name -> FBCreditCalculatorFragment.newInstance(uiHolder)
            else -> {
                FormFragment.newInstance(uiHolder)
            }
        }
    }
}