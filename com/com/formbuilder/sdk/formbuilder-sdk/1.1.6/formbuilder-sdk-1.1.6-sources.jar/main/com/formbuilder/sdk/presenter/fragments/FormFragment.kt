package com.formbuilder.sdk.presenter.fragments

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.View.OnClickListener
import android.view.View.VISIBLE
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import androidx.core.view.allViews
import androidx.core.view.children
import androidx.fragment.app.Fragment
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.Field
import com.formbuilder.sdk.data.models.FieldType
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.presenter.activities.FormBuilderMainActivityViewModel
import com.formbuilder.sdk.presenter.common.DropDownSelectedListener
import com.formbuilder.sdk.presenter.common.FBButton
import com.formbuilder.sdk.presenter.common.FBButtonListener
import com.formbuilder.sdk.presenter.common.FBConsent
import com.formbuilder.sdk.presenter.common.FBFieldInput
import com.formbuilder.sdk.presenter.common.FBFieldText
import com.formbuilder.sdk.presenter.common.FBView
import com.formbuilder.sdk.presenter.common.SectionSubmittedListener
import com.formbuilder.sdk.presenter.common.views.FBButtonView
import com.formbuilder.sdk.presenter.common.views.FBCheckBoxView
import com.formbuilder.sdk.presenter.common.views.FBConsentView
import com.formbuilder.sdk.presenter.common.views.FBDatePickerView
import com.formbuilder.sdk.presenter.common.views.FBFileSelectorView
import com.formbuilder.sdk.presenter.common.views.FBHorizontalLineView
import com.formbuilder.sdk.presenter.common.views.FBImageView
import com.formbuilder.sdk.presenter.common.views.FBLinkTextView
import com.formbuilder.sdk.presenter.common.views.FBPopupView
import com.formbuilder.sdk.presenter.common.views.FBRadioGroupView
import com.formbuilder.sdk.presenter.common.views.FBSectionView
import com.formbuilder.sdk.presenter.common.views.FBSpinnerView
import com.formbuilder.sdk.presenter.common.views.FBTextInputView
import com.formbuilder.sdk.presenter.common.views.FBTextView
import com.formbuilder.sdk.presenter.models.FBGroup
import com.formbuilder.sdk.presenter.models.SectionCallModel
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.Constants.OPERATOR_EQUAL
import com.formbuilder.sdk.utils.hideKeyboard
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.logger.MESSAGE
import java.io.File


class FormFragment() : Fragment() {

    private val uiHolder by lazy { arguments?.getParcelable<UIHolder>(UI_HOLDER) }
    private val fieldValues = mutableListOf<FBView>()
    private val groups = mutableListOf<FBGroup>()
    private var sectionContainerList = mutableListOf<Int>()
    private var sectionRequestList = mutableListOf<SectionCallModel>()
    private val mViewModel: FormBuilderMainActivityViewModel by viewModel()
    private lateinit var formContainer: LinearLayoutCompat
    private lateinit var topContainer: LinearLayoutCompat
    private lateinit var middleContainer: LinearLayoutCompat
    private lateinit var bottomContainer: LinearLayoutCompat
    private lateinit var filePath: String
    private lateinit var preferences: SharedPreferences

    private val onDropDownSelectedListener: DropDownSelectedListener =
        object : DropDownSelectedListener {
            override fun dropDownSelected(key: String, value: String) {
                groups.forEach {
                    if (it.condition?.operator == OPERATOR_EQUAL) {
                        if (it.condition.fieldKey == key && it.condition.value == value) {
                            for (childView in formContainer.children) {
                                if (childView.tag == it.condition.sectionKey) {
                                    (childView as FBView).isVisible(true)
                                    for (view in childView.allViews)
                                        view.visibility = VISIBLE
                                    fieldValues.add(childView)
                                }
                            }
                        } else if (it.condition.fieldKey == key) {
                            for (childView in formContainer.children) {
                                if (childView.tag == it.condition.sectionKey) {
                                    (childView as FBView).isVisible(false)
                                    for (view in childView.allViews)
                                        view.visibility = GONE
                                    fieldValues.remove(childView)
                                }
                            }
                        }
                    }
                }
            }
        }

    private val onClickListener = object : FBButtonListener {
        override fun onFBButtonClicked(key: String, directionId: String, fieldId: Int) {
            uiHolder?.section?.fields?.forEach {
                if (it.flowFieldId == fieldId) {
                    if (it.type == FieldType.CONSENT.name) {
                        var message = ""
                        it.consentFields?.forEach { f ->
                            if (f.type == FieldType.TEXT.name)
                                message += f.label + "\n\n"
                        }
                        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
                        builder.setMessage(message)
                        builder.setCancelable(true)
                        builder.setNegativeButton(
                            context?.getString(R.string.ok)
                        ) { dialog, _ -> dialog.cancel() }

                        val alertDialog: AlertDialog = builder.create()
                        alertDialog.show()
                        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                            .setTextColor(resources.getColor(R.color.text_color, null))
                        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                            .setTextColor(resources.getColor(R.color.text_color, null))
                    }
                    return
                }
            }
            hideKeyboard()

            if (fieldValues.isNotEmpty()) {
                val answers = mutableListOf<StepField>()
                fieldValues.forEach {
                    when (it) {
                        is FBFieldInput -> {
                            if (it.getVisibility() == VISIBLE){
                                if (!it.checkFieldData(
                                        it.getRegex(),
                                        it.getValue(),
                                        it.getErrorMessage()
                                    )
                                ) {
                                    return
                                } else {
                                    if (it.getVisibility() == VISIBLE)  answers.add(StepField(it.key, it.getValue()))
                                }
                            }
                        }

                        is FBCheckBoxView -> {
                            if (!it.checkFieldData(
                                    it.getIsRequired(),
                                    it.getValue(),
                                    it.getErrorMessage()
                                )
                            ) {
                                return
                            } else {
                                answers.add(StepField(it.key, it.getValue().toString()))
                            }
                        }

                        is FBRadioGroupView -> {
                            if (!it.checkFieldData(
                                    it.getIsRequired(),
                                    it.getValue(),
                                    it.getErrorMessage()
                                )
                            ) {
                                return
                            } else {
                                answers.add(StepField(it.key, it.getValue()))
                            }
                        }

                        is FBConsent ->{
                            if (!it.checkFieldData(
                                    it.getIsRequired(),
                                    it.getValue(),
                                    it.getErrorMessage()
                                )
                            ) {
                                return
                            } else {
                                answers.add(StepField(it.key, it.toString()))
                            }
                        }

                        is FBSpinnerView -> {
                            if (!it.checkFieldData(
                                    it.getIsRequired(),
                                    it.getValue(),
                                    it.getErrorMessage()
                                )
                            ) {
                                return
                            } else {
                                answers.add(StepField(it.key, it.getValue()))
                            }
                        }

//                        is FBFileSelectorView -> {
//                            if (!it.checkFieldData(
//                                    it.getRegex(),
//                                    it.getValue(),
//                                    it.getErrorMessage()
//                                )
//                            ) {
//                                return
//                            } else {
//                                answers.add(StepField(it.key, it.getValue()))
//                            }
//                        }

                    }
                }
                (context as SectionSubmittedListener).onSectionSubmittedWithValidAnswers(
                    uiHolder?.section?.submissionId ?: "",
                    directionId,
                    uiHolder?.section?.directionId ?: "",
                    fromFlowDirectionId = key,
                    answers = answers
                )
            } else {
                (context as SectionSubmittedListener).onSectionSubmittedWithValidAnswers(
                    uiHolder?.section?.submissionId ?: "",
                    directionId,
                    uiHolder?.section?.directionId ?: "",
                    fromFlowDirectionId = key,
                    answers = emptyList()
                )
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        preferences = requireContext().getSharedPreferences(FBAppearance.APPEARANCE_COLORS, Context.MODE_PRIVATE)
        val view = inflater.inflate(R.layout.fragment_form_section, container, false)
        view.findViewById<ScrollView>(R.id.svLayout).setBackgroundColor(preferences.getInt(BACKGROUND_COLOR, ContextCompat.getColor(requireContext(), R.color.background_color)))
        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mViewModel.observeFormBuilderSectionView().observe(viewLifecycleOwner) { holder ->
            holder.sectionFields?.forEach { sectionField ->
                sectionField.fields.forEach { sectionFieldElement ->
                    if (this.sectionContainerList.isNotEmpty()) addViews(sectionFieldElement, getSectionContainer(), sectionFieldElement.hidden ?: true, sectionFieldElement.key ?: "")
                    if (sectionRequestList.isNotEmpty()) getSection()
                }
            }
        }
        renderFields(view)
    }
    override fun onDestroyView() {
        mViewModel.observeFormBuilderSectionView().removeObservers(this)
        super.onDestroyView()
    }
    private fun getSectionContainer(): LinearLayoutCompat{
        val sectionContainer = formContainer.findViewById<LinearLayoutCompat>(sectionContainerList.first())
        sectionContainerList.removeFirst()
        return sectionContainer
    }

    // This is the method which does the magic
    private fun renderFields(view: View) {
        formContainer = view.findViewById(R.id.form_container)
        topContainer = view.findViewById(R.id.top_layout)
        middleContainer = view.findViewById(R.id.middle_layout)
        bottomContainer = view.findViewById(R.id.bottom_layout)

        //We iterate through each field and decide which component it corresponds to.
        //All of these components created by ourselves must follow the same interface, which is FBView
        uiHolder?.section?.fields?.forEach { it ->
            val isVisible = it.hidden ?: true
            val sectionKey = it.key
            addViews(it, formContainer, isVisible, sectionKey ?: "")
        }
        if (sectionRequestList.isNotEmpty()) getSection()
    }

    private fun addViews(
        field: Field,
        formContainer: LinearLayoutCompat,
        isVisible: Boolean = true,
        sectionKey: String = ""
    ) {
//        if(!field.variableType.isNullOrBlank())
//            return
        if (field.type == FieldType.GROUP.name) {
            groups.add(
                FBGroup(
                    field.type,
                    field.condition,
                    field.key
                )
            )
            return
        }

        val formBuilderView: FBView = when (field.type) {
            FieldType.INPUT.name -> {
                if (field.specialType == "FOLDER_PATH") {
                    FBFileSelectorView(requireContext(), action = onFileClick)
                } else {
                    FBTextInputView(requireContext())
                }
            }

            FieldType.IMAGE.name -> {
                FBImageView(requireContext())
            }

            FieldType.UPLOAD_FILE.name -> {
                FBFileSelectorView(requireContext(), action = onFileClick)
            }

            FieldType.POPUP.name -> {
                FBPopupView(requireContext())
            }

            FieldType.SECTION.name -> {
                FBSectionView(requireContext())
            }

            FieldType.DATE.name -> {
                FBDatePickerView(requireContext())
            }

            FieldType.TEXT.name,
            FieldType.HINT.name -> {
                FBTextView(requireContext())
            }

            FieldType.LINK.name -> {
                FBLinkTextView(requireContext(),url = field.condition?.value!!)
            }

            FieldType.AREA.name -> {
                FBTextInputView(requireContext())
            }

            FieldType.FLOW.name -> {
                // Skip FLOW fields that are linked to a CONSENT field (they render inline as a link)
                val isLinkedToConsent = uiHolder?.section?.fields?.any {
                    it.type == FieldType.CONSENT.name && it.flowFieldId == field.fieldId
                } ?: false
                if (isLinkedToConsent) return
                FBButtonView(requireContext())
            }

            FieldType.NEW_LINE.name -> {
                FBTextView(requireContext())
            }

            FieldType.HORIZONTAL_LINE.name -> {
                FBHorizontalLineView(requireContext())
            }

            FieldType.CHECKBOX.name -> {
                FBCheckBoxView(requireContext())
            }

            FieldType.RADIO.name -> {
                FBRadioGroupView(requireContext())
            }

            FieldType.DROPDOWN.name, FieldType.NOMENCLATURE.name -> {
                FBSpinnerView(requireContext())
            }

            FieldType.CONSENT.name,
            FieldType.SUBMIT.name -> {
                FBConsentView(requireContext())
            }

            else -> {
                FBHorizontalLineView(requireContext())
            }
        }

        //we must set a key to each field so we send it back to the api as a map of the key and the value inserted
        when (formBuilderView) {

            is FBLinkTextView -> {
                formBuilderView.apply {
                    setValue(field.label ?: "")
                    setInNewTab(field.inNewTab.toBoolean())
                    isVisible(isVisible)
                    setTag(sectionKey)
                }
            }

            is FBImageView -> {
                formBuilderView.apply {
                    key = field.key?: ""
                    setTag(sectionKey)
                    setAlignment(field.alignment)
                    setWidth(field.size)
                    setImage(field.imageUrl)
                }
            }

            is FBTextInputView -> {
                formBuilderView.apply {
                    key = field.key?: ""
                    setTag(sectionKey)
                    setHint(field.label)
                    if (!field.hideInEndUser.isNullOrBlank()){
                        isVisible(!(field.hideInEndUser.toBoolean()))
                    }
                }
            }

            is FBPopupView -> {
                formBuilderView.apply {
                    key = field.key?: ""
                    setTag(sectionKey)
                    setFieldId(field.fieldId)
                    setValue(field.label ?: "")
                }
            }

            is FBFileSelectorView -> {
                formBuilderView.apply {
                    key = field.key ?: ""
                    setLabelMessage(field.label ?: "My Message")
                    setButtonMessage(field.label ?: "")
                    setErrorMessage(field.validationError ?: "")
                    isVisible(isVisible)
                    setTag(sectionKey)
                }
                if (isVisible) fieldValues.add(formBuilderView)
            }

            is FBSectionView -> {
                formBuilderView.apply {
                    key =  field.key ?: ""
                    isVisible(isVisible)
                    setTag(sectionKey)
                    setViewId(field.fieldId)
                }
                if (isVisible) fieldValues.add(formBuilderView)

            }

            is FBFieldInput -> {
                formBuilderView.apply {
                    key = field.key ?: ""
                    setHint(field.label)
                    setInputType(field.type ?: "")
                    isVisible(isVisible)
                    setTag(sectionKey)
                    setRegex(field.validation ?: "")
                    setErrorMessage(field.validationError ?: "")
                }
                //Then we add this field to the list of the fields, so we can validate all of them and get their values
                fieldValues.add(formBuilderView)
            }

            is FBFieldText -> {
                formBuilderView.apply {
                    setValue(field.label ?: "")
                    isVisible(isVisible)
                    setTag(sectionKey)
                    if (!field.alignment.isNullOrEmpty()){
                        setGravity(field.alignment)
                    }
                    setBold(field.isBold)
                }
            }

            is FBCheckBoxView -> {
                formBuilderView.apply {
                    key = field.key ?: ""
                    setLabel(field.label)
                    setIsRequired(field.required ?: false)
                    setErrorMessage(field.validationError ?: "")
                    isVisible(isVisible)
                    setTag(sectionKey)
                    getCheckBox().setOnCheckedChangeListener { _, _ ->
                        if (getValue()){
                            groups.forEach {
                                for (childView in formContainer.children) {
                                    if (childView.tag == it.condition?.sectionKey) {
                                        (childView as FBView).isVisible(false)
                                        for (view in childView.allViews)
                                            view.visibility = GONE
                                        fieldValues.remove(childView)
                                    }
                                }
                            }
                        }
                        else{
                            groups.forEach {
                                for (childView in formContainer.children) {
                                    if (childView.tag == it.condition?.sectionKey) {
                                        (childView as FBView).isVisible(true)
                                        for (view in childView.allViews)
                                            view.visibility = VISIBLE
                                        fieldValues.add(childView)
                                    }
                                }
                            }
                        }
                    }
                }
                if (isVisible) fieldValues.add(formBuilderView)
            }

            is FBRadioGroupView -> {
                formBuilderView.apply {
                    key = field.key ?: ""
                    setRadioButtons(field.options)
                    isVisible(isVisible)
                    setLabel(field.label ?: "")
                    setErrorMessage(field.validationError ?: "")
                    setTag(sectionKey)
                }
                if (isVisible) fieldValues.add(formBuilderView)
            }

            is FBSpinnerView -> {
                formBuilderView.apply {
                    key = field.key ?: ""
                    setSpinnerOptions(field.label ?: "", field.options)
                    isVisible(isVisible)
                    setDropDownSelectedListener(onDropDownSelectedListener)
                    setErrorMessage(field.validationError ?: "")
                    setTag(sectionKey)
                }
                if (isVisible) fieldValues.add(formBuilderView)
            }

            is FBConsentView -> {
                formBuilderView.apply {
                    key = field.key ?: ""
                    setLabel(field.label)
                    isVisible(isVisible)
                    setErrorMessage(field.validationError ?: "")
                    setTag(sectionKey)
                    setIsRequired(field.required ?: false)

                    // Build consent popup message from consentContent fields with formatting
                    val consentMessage = android.text.SpannableStringBuilder()
                    field.consentFields?.forEach { f ->
                        if (f.type == FieldType.TEXT.name && !f.label.isNullOrEmpty()) {
                            val start = consentMessage.length
                            consentMessage.append(f.label)
                            val end = consentMessage.length

                            if (f.isBold == true) {
                                consentMessage.setSpan(
                                    android.text.style.StyleSpan(android.graphics.Typeface.BOLD),
                                    start, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                )
                            }
                            if (f.isItalic == true) {
                                consentMessage.setSpan(
                                    android.text.style.StyleSpan(android.graphics.Typeface.ITALIC),
                                    start, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                )
                            }
                            if (f.isUnderline == true) {
                                consentMessage.setSpan(
                                    android.text.style.UnderlineSpan(),
                                    start, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                )
                            }
                            if (f.size != null && f.size > 0) {
                                val proportion = f.size / 14f
                                consentMessage.setSpan(
                                    android.text.style.RelativeSizeSpan(proportion),
                                    start, end, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                )
                            }

                            consentMessage.append("\n\n")
                        }
                    }
                    if (consentMessage.isNotEmpty()) {
                        setConsentContent(consentMessage.trimEnd())
                    }

                    // Find linked FLOW field and show its label as inline link
                    if (field.flowFieldId != null) {
                        val linkedFlow = uiHolder?.section?.fields?.find {
                            it.fieldId == field.flowFieldId && it.type == FieldType.FLOW.name
                        }
                        if (linkedFlow != null) {
                            setLinkText(linkedFlow.label)
                        }
                    }
                }
                if (isVisible) fieldValues.add(formBuilderView)
            }

            is FBButton -> {
                formBuilderView.apply {
                    key = field.key ?: ""
                    setValue(field.label)
                    setDirectionId(field.directionId ?: "")
                    setFieldId(field.fieldId)
                    setButtonOnClickListener(onClickListener)
                    isVisible(isVisible)
                    setTag(sectionKey)
                }
            }
        }
        //Our view only as a linear layout to hold the fields and place them one on each line

        if ((formBuilderView is FBTextView || formBuilderView is FBImageView ) &&
            !field.styleClass.isNullOrEmpty()){
            val container = when (field.styleClass){
                "position-top"      -> topContainer
                "position-middle"   -> middleContainer
                "position-bottom"   -> bottomContainer
                else -> formContainer
            }

            container.addView(formBuilderView as View)
        }

        else if (formBuilderView is FBButtonView && !field.notes.isNullOrEmpty()){
            val container = when (field.notes){
                "position-top"      -> topContainer
                "position-middle"   -> middleContainer
                "position-bottom"   -> bottomContainer
                else -> formContainer
            }

            container.addView(formBuilderView as View)
        }
        else{
            formContainer.addView(formBuilderView as View)
        }


        if (field.type == FieldType.SECTION.name) {
            if (uiHolder!!.section!!.submissionId?.isNotEmpty() == true && field.key?.isNotEmpty() == true){
                sectionRequestList.add(SectionCallModel(uiHolder!!.section!!.submissionId!!, field.key))
                sectionContainerList.add(field.fieldId)
            }
        }

        if (field.variableLabel.equals("__postToHostUI") || field.specialType.equals("__postToHostUI")){
            if (!field.defaultValue.isNullOrBlank()){
                ProcessResult.setPostToHostUI(field.defaultValue.toString())
            }
        }
    }

    private fun getSection(){
        with(this.sectionRequestList.first()){
            if (this != null){
                mViewModel.getSection(this.submissionId, this.key)
                sectionRequestList.removeFirst()
            }
        }
    }

    private var resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
           result.data?.data?.let {returnUri ->
               val fileUri = returnUri
               requireContext().contentResolver.query(returnUri, null, null, null, null)
           }?.use { cursor ->
               cursor.moveToFirst()
               val fileName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME))
               cursor.close()
           }
        }
    }

    private val onFileClick = OnClickListener { _ ->
        val mimetypes = arrayOf("application/jpeg", "application/pdf")
        val intent = Intent()
            .setType("*/*")
            .setAction(Intent.ACTION_GET_CONTENT)
            .putExtra(Intent.EXTRA_MIME_TYPES, mimetypes)
        resultLauncher.launch(intent)
    }

    companion object {
        const val UI_HOLDER = "UI_HOLDER"

        fun newInstance(uiHolder: UIHolder?): FormFragment {
            val fragment = FormFragment()
            val bundle = Bundle().apply {
                putParcelable(UI_HOLDER, uiHolder)
            }
            fragment.arguments = bundle
            return fragment
        }
    }

    object ProcessResult {

        private var result: (( String) -> Unit)? = null
        private var closedFormResult: (( String) -> Unit)? = null

        internal fun setPostToHostUI(message: String) {
            result?.invoke(message)
        }

        fun postToHostUI(callback: (String) -> Unit) {
            this.result = callback
        }

        internal fun setClosedForm(message: String) {
            closedFormResult?.invoke(message)
        }

        fun closedForm(callback: (String) -> Unit) {
            this.closedFormResult = callback
        }
    }
}