package com.formbuilder.sdk.data.repository

import com.formbuilder.sdk.data.models.FBDataStatusResponse
import com.formbuilder.sdk.data.models.Section
import com.formbuilder.sdk.data.models.SectionFields
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.data.networking.models.ApiResponse

interface FormBuilderRepository {

    fun startForm(processId: String, callingServiceToken: String? = null): ApiResponse<Section>

    fun getSection(submissionId: String, sectionKey: String): ApiResponse<List<SectionFields>>

    fun getStep(
        submissionId: String?, directionId: String?,
        fromDirectionId: String? = null, fromFlowFieldId: String? = null, stepFields: List<StepField>?,
        activityId: Int? = null
    ): ApiResponse<Section>

    fun getSelfieStatus(
        submissionId: String,
        userHash: String
    ): ApiResponse<FBDataStatusResponse>

    fun getDocDataStatus(
        submissionId: String,
        userHash: String
    ): ApiResponse<FBDataStatusResponse>

    fun getDirection(directionId: String): ApiResponse<Section>
}