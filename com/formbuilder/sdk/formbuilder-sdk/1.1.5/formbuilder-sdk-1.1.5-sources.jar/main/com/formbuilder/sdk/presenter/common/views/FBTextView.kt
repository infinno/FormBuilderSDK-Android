package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance.Companion.APPEARANCE_COLORS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TEXT_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.VIEW_BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.VIEW_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.VIEW_TEXT_SIZE
import com.formbuilder.sdk.presenter.common.FBFieldText

class FBTextView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBFieldText {

    override var key: String = ""
    private val text: TextView

    init {
        val view = inflate(context, R.layout.layout_text, this)
        val preferences = context.getSharedPreferences(APPEARANCE_COLORS, Context.MODE_PRIVATE)
        text = view.findViewById(R.id.layout_text_view)
        text.setTextColor(preferences.getInt(VIEW_TEXT_COLOR, ContextCompat.getColor(context,R.color.text_color)))
        text.setBackgroundColor(preferences.getInt(VIEW_BACKGROUND_COLOR, ContextCompat.getColor(context,R.color.transparent)))

        text.typeface = ResourcesCompat.getFont(context, R.font.a1_sans_regular)

        text.apply {
            val font = preferences.getInt(TEXT_FONT, 0)
            if (font != 0){
                val tf = font.let { ResourcesCompat.getFont(context, it) }
                if (tf != null) {
                    typeface = tf
                }
            }
            if (preferences.getInt(VIEW_TEXT_SIZE, 0) != 0){
                textSize = preferences.getInt(VIEW_TEXT_SIZE, 18).toFloat()
            }
        }

        text.gravity = Gravity.CENTER
        text.elevation = 32f
        // is necessary to avoid having the same component twice on the screen with the same id.
        text.id = generateViewId()
    }

    override fun setValue(value: String?) {
        if (value != null) {
            text.text = value.replace("\\n", "\n")
        }
    }

    override fun isVisible(isVisible: Boolean) {
        text.visibility = if(isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }
    override fun setGravity(gravity: String) {
        val viewAlignment = when (gravity.lowercase()){
            "left" -> Gravity.START
            "center" -> Gravity.CENTER
            "right" -> Gravity.END
            else -> Gravity.CENTER
        }
        text.gravity = viewAlignment
    }

    override fun setBold(isBold: Boolean?) {
        if (isBold != null && isBold){
            text.setTypeface(text.typeface, android.graphics.Typeface.BOLD)
        }
    }

}