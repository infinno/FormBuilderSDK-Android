package com.formbuilder.sdk.data.repository

import com.formbuilder.sdk.data.models.Installment
import com.formbuilder.sdk.data.models.Product
import com.formbuilder.sdk.data.networking.datasource.SmartCheckDataSource
import com.formbuilder.sdk.data.networking.models.ApiResponse

class SmartCheckRepositoryImpl(
    private val smartCheckDataSource: SmartCheckDataSource
): SmartCheckRepository {

    override fun getProducts(productType:String): ApiResponse<List<Product>> =
        smartCheckDataSource.getProducts(productType)

    override fun getInstallmentDetails(amount: Double, periods: Int, productId: Int): ApiResponse<Installment> =
        smartCheckDataSource.getInstallmentDetails(amount, periods, productId)
}