package com.formbuilder.sdk.presenter.common.views

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.widget.DatePicker
import android.widget.FrameLayout
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBFieldInput
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date

class FBDatePickerView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBFieldInput {

    companion object {
        private const val DATE_FORMAT = "yyyy-MM-dd"
    }

    override var key: String = ""
    private val textInput: TextInputEditText
    private val textInputLayout: TextInputLayout
    private var errorMessageValue = ""
    private var regexValue = ""
    private var selectedDate: Date? = null

    init {
        val view = inflate(context, R.layout.layout_date_input, this)
        textInput = view.findViewById(R.id.text_input_edit_text)
        textInputLayout = view.findViewById(R.id.activity_form_builder_text_input_layout)

        //This is necessary to avoid having the same component twice on the screen with the same id.
        textInput.id = generateViewId()
        textInput.setOnClickListener {
            showDatePicker(selectedDate)
        }
    }

    override fun getValue(): String {
        return textInput.text.toString()
    }

    override fun setHint(hint: String?) {
        textInputLayout.hint = hint
    }

    override fun setInputType(inputType: String) {
        //...
    }

    override fun setRegex(regex: String) {
        regexValue = regex
    }

    override fun getRegex(): String =
        regexValue

    override fun setErrorMessage(errorMessage: String) {
        errorMessageValue = errorMessage
    }

    override fun getErrorMessage(): String =
        errorMessageValue

    override fun checkFieldData(regex: String, value: String, error: String): Boolean {
        if (regex.isNotEmpty() && !value.matches(regex.toRegex())) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setMessage(error)
            builder.setCancelable(true)
            builder.setNegativeButton(
                context.getString(R.string.close_btn_label)
            ) { dialog, _ -> dialog.cancel() }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            return false
        }

        return true
    }

    override fun isVisible(isVisible: Boolean) {
        textInputLayout.visibility = if (isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

    private fun showDatePicker(d: Date?) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            return
        }
        val c = Calendar.getInstance()
        c.time = d ?: Date()
        val dialog = DatePickerDialog(
            context,
            { view: DatePicker?, year: Int, monthOfYear: Int, dayOfMonth: Int ->
                val calendar = Calendar.getInstance()
                calendar[Calendar.YEAR] = year
                calendar[Calendar.MONTH] = monthOfYear
                calendar[Calendar.DAY_OF_MONTH] = dayOfMonth
                selectedDate = calendar.time
                textInput.setText(formatDate(selectedDate!!, DATE_FORMAT))
            }, c[Calendar.YEAR], c[Calendar.MONTH], c[Calendar.DAY_OF_MONTH]
        )
        dialog.show()
    }

    private fun formatDate(date: Date, format: String): String? {
        val sdf = SimpleDateFormat(format)
        return sdf.format(date)
    }

}