package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class FBDataStatusResponse (
    @SerializedName("status")
    val status: Int?,
    @SerializedName("code")
    val code: String?,
    @SerializedName("message")
    val message: String?
): Parcelable
