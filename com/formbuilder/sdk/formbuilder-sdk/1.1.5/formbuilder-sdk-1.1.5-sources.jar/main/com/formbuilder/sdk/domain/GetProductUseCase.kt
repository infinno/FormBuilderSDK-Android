package com.formbuilder.sdk.domain

import com.formbuilder.sdk.data.models.Product
import com.formbuilder.sdk.data.models.SettingsProduct
import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.repository.SmartCheckRepository
import com.formbuilder.sdk.utils.helpers.Either

class GetProductUseCase(
    private val repository: SmartCheckRepository,
    private val apiErrorHandler: ApiErrorHandler
) : BaseUseCase<Either<String, List<Product>?>>() {

    companion object {
        const val PARAM_PRODUCTS = "PARAM_PRODUCTS"
        const val PARAM_PRODUCT_TYPE = "PARAM_PRODUCT_TYPE"
    }

    override suspend fun run(withData: Map<String, Any>?): Either<String, List<Product>?> {
        val products = withData?.get(PARAM_PRODUCTS) as List<SettingsProduct>
        val productType = withData.get(PARAM_PRODUCT_TYPE) as String
        val response = repository.getProducts(productType)
        val responseData = response.responseData
        return if (ApiResponse.checkStatus(response.httpCode) == ApiResponse.STATUS_OK && responseData != null) {
            Either.Right(getProducts(responseData, products))
        } else {
            Either.Left(apiErrorHandler.getErrorMessage(response))
        }
    }

    private fun getProducts(
        products: List<Product>,
        productsByStep: List<SettingsProduct>
    ): List<Product> {
        return products.filter { obj2 -> productsByStep.any { obj1 -> obj1.itemValue == obj2.productId } }
    }
}