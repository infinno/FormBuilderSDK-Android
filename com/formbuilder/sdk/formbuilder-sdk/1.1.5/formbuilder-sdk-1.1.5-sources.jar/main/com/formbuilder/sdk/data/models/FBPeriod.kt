package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class FBPeriod(
    @SerializedName("period")
    val period: Int,
    @SerializedName("minPrincipal")
    val minPrincipal: Double,
    @SerializedName("maxPrincipal")
    val maxPrincipal: Double
) : Parcelable