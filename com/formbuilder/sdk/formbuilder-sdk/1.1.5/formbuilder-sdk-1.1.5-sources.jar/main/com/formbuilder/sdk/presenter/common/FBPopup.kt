package com.formbuilder.sdk.presenter.common

interface FBPopup: FBView {
    fun setValue(value: String?)
    fun setFieldId(id: Int)
    fun setButtonPopupOnClickListener(listener: FBPopupListener)
}