package com.formbuilder.sdk.utils

object SDKProperties {
    var cameraResolution: String = "Not selected"
    var appVersion: String = "1.1.4"
    var cameraSizes4_3 = mutableListOf<String>()
    var cameraSizes16_9 = mutableListOf<String>()
    var aspectRatio = 1.33
    var blackLineRatio = 2.5
    var cameraParameters = mutableListOf<String>()
    var swapCamera = mutableListOf<String>()
}