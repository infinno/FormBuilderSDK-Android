package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Installment(
    @SerializedName("totalDueAmount")
    val totalDueAmount: Double,
    @SerializedName("installmentAmount")
    val installmentAmount: Double
) : Parcelable