package com.formbuilder.sdk.presenter.activities

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.domain.GetSectionUseCase
import com.formbuilder.sdk.domain.GetStepUseCase
import com.formbuilder.sdk.presenter.base.BaseViewModel
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.helpers.SingleLiveEvent
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class FormBuilderMainActivityViewModel(
    private val getStepUseCase: GetStepUseCase,
    private val getSectionUseCase: GetSectionUseCase
) : BaseViewModel() {

    private var getStepJob: Job? = null
    private var getSectionJob: Job? = null
    private val mFormBuilderView = MutableLiveData<UIHolder>()
    private val mFormBuilderSectionView = SingleLiveEvent<UIHolder>()
    fun observeFormBuilderView() =
        mFormBuilderView as LiveData<UIHolder>
    fun observeFormBuilderSectionView() =
        mFormBuilderSectionView as LiveData<UIHolder>

    fun getStep(
        submissionId: String, directionId: String,
        fromDirectionId: String = "", fromFlowFieldId: String = "",
        stepFields: List<StepField>, activityId: Int = 0
    ) {
        if (isActiveJob(getStepJob)) return
        getStepJob = viewModelScope.launch {
            mLoadingIndicatorVisible.value = true
            getStepUseCase.executeAsync(
                mapOf(
                    GetStepUseCase.PARAM_SUBMISSION_ID to submissionId,
                    GetStepUseCase.PARAM_DIRECTION_ID to directionId,
                    GetStepUseCase.PARAM_FROM_DIRECTION_ID to fromDirectionId,
                    GetStepUseCase.PARAM_FROM_FLOW_FIELD_ID to fromFlowFieldId,
                    GetStepUseCase.PARAM_STEP_FIELDS to stepFields,
                    GetStepUseCase.PARAM_ACTIVITY_ID to activityId
                )
            ).onLeft { error ->
                launch {
                    mLoadingIndicatorVisible.value = false
                    mErrorChannel.send(error)
                }
            }.onRight { result ->
                mLoadingIndicatorVisible.value = false
                mFormBuilderView.value = result
            }
        }
    }

    fun getSection(submissionId: String, directionId: String) {
        if (isActiveJob(getSectionJob)) return
        getSectionJob = viewModelScope.launch {
            mLoadingIndicatorVisible.value = true
            getSectionUseCase.executeAsync(
                mapOf(
                    GetStepUseCase.PARAM_SUBMISSION_ID to submissionId,
                    GetStepUseCase.PARAM_DIRECTION_ID to directionId
                )
            ).onLeft { error ->
                launch {
                    mLoadingIndicatorVisible.value = false
                    mErrorChannel.send(error)
                }
            }.onRight { result ->
                mLoadingIndicatorVisible.value = false
                mFormBuilderSectionView.postValue(result)
                Log.d("SECTION_CALL_VIEW_RESP", result.toString())
            }
        }
    }
}
