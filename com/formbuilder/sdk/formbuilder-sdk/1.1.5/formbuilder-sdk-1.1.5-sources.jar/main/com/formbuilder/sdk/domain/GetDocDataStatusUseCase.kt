package com.formbuilder.sdk.domain

import com.formbuilder.sdk.data.models.FBDataStatusResponse
import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.repository.FormBuilderRepository
import com.formbuilder.sdk.utils.helpers.Either

class GetDocDataStatusUseCase (
    private val repository: FormBuilderRepository,
    private val apiErrorHandler: ApiErrorHandler
) : BaseUseCase<Either<String, FBDataStatusResponse>>() {

    companion object {
        const val PARAM_SUBMISSION_ID = "PARAM_SUBMISSION_ID"
        const val PARAM_USER_HASH = "PARAM_USER_HASH"
    }

    override suspend fun run(withData: Map<String, Any>?): Either<String, FBDataStatusResponse> {
        val submissionId = withData?.get(PARAM_SUBMISSION_ID) as String
        val userHash = withData[PARAM_USER_HASH] as String
        val response = repository.getDocDataStatus(submissionId, userHash)
        val responseData = response.responseData
        return if (ApiResponse.checkStatus(response.httpCode) == ApiResponse.STATUS_OK && responseData != null) {
            Either.Right(responseData)
        } else {
            Either.Left(apiErrorHandler.getErrorMessage(response))
        }
    }
}