package com.formbuilder.sdk.data.networking.datasource

import com.formbuilder.sdk.data.models.Installment
import com.formbuilder.sdk.data.models.InstallmentDetailsPayload
import com.formbuilder.sdk.data.models.Product
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.networking.services.SmartCheckService

class SmartCheckDataSource : RemoteDataSource() {

    private val service: SmartCheckService by lazy {
        baseRetrofitClient.createService(SmartCheckService::class.java)
    }

    fun getProducts(productType:String): ApiResponse<List<Product>> =
        getResponseBody(service.getProducts(productType))

    fun getInstallmentDetails(
        amount: Double,
        periods: Int,
        productId: Int
    ): ApiResponse<Installment> =
        getResponseBody(
            service.getInstallmentDetails(
                InstallmentDetailsPayload(
                    amount,
                    periods,
                    productId
                )
            )
        )

}