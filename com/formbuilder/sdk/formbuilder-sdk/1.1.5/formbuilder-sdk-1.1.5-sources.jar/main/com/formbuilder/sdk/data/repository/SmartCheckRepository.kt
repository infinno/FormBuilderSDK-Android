package com.formbuilder.sdk.data.repository

import com.formbuilder.sdk.data.models.Installment
import com.formbuilder.sdk.data.models.Product
import com.formbuilder.sdk.data.networking.models.ApiResponse

interface SmartCheckRepository {

    fun getProducts(productType:String): ApiResponse<List<Product>>

    fun getInstallmentDetails(amount: Double, periods: Int, productId: Int): ApiResponse<Installment>
}