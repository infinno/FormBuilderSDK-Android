package com.formbuilder.sdk.presenter.common

interface FBFieldInput: FBView {
    fun getValue(): String
    fun setHint(hint: String?)
    fun setInputType(inputType: String)
    fun setRegex(regex: String)
    fun getRegex(): String
    fun setErrorMessage(errorMessage: String)
    fun getErrorMessage(): String
    fun checkFieldData(regex: String, value:String, error: String): Boolean
    fun getVisibility(): Int
}