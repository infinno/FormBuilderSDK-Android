package com.formbuilder.sdk.presenter.base

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.ReceiveChannel

abstract class BaseViewModel : ViewModel() {

    protected val mErrorChannel = Channel<String>()
    fun observeErrorChannel(): ReceiveChannel<String> = mErrorChannel

    protected val mLoadingIndicatorVisible = MutableLiveData<Boolean>()
    fun observeLoading() = mLoadingIndicatorVisible as LiveData<Boolean>

    protected fun isActiveJob(job: Job?): Boolean {
        return job?.isActive == true && !job.isCompleted
    }
}