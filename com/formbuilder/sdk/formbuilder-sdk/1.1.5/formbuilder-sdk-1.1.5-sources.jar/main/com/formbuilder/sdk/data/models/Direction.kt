package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Direction(
    @SerializedName("id")
    val id: Int? = 0,
    @SerializedName("process")
    val process: String? = null,
    @SerializedName("directionId")
    val directionId: String? = null,
    @SerializedName("label")
    val label: String? = null,
    @SerializedName("groups")
    val groups: String? = null,
    @SerializedName("name")
    val name: String? = null,
    @SerializedName("type")
    val type: String? = null,
    @SerializedName("immutable")
    val immutable: Boolean? = null,
    @SerializedName("noSubmit")
    val noSubmit: Boolean? = null,
    @SerializedName("toDirectionId")
    val toDirectionId: String? = null,
): Parcelable
