package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance
import com.formbuilder.sdk.presenter.common.FBPopup
import com.formbuilder.sdk.presenter.common.FBPopupListener

class FBPopupView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBPopup {

    override var key: String = ""
    private val button: AppCompatButton
    private var buttonDirectionId: String = ""
    private var fieldId = 0

    init {
        val preferences = context.getSharedPreferences(FBAppearance.APPEARANCE_COLORS, Context.MODE_PRIVATE)
        val view = inflate(context, R.layout.layout_popup_button, this)
        button = view.findViewById(R.id.layout_popup_button)
        button.setTextColor(preferences.getInt(FBAppearance.BUTTON_TEXT_COLOR, ContextCompat.getColor(context, R.color.text_color)))
        DrawableCompat.setTint(
            DrawableCompat.wrap(button.background),
            preferences.getInt(FBAppearance.BUTTON_BACKGROUND_COLOR, ContextCompat.getColor(context, R.color.a1_color))
        )

        // is necessary to avoid having the same component twice on the screen with the same id.
        button.id = generateViewId()
        key = button.id.toString()
    }
    override fun setValue(value: String?) {
        button.text = value
    }

    override fun setFieldId(id: Int) {
        fieldId = id
    }

    override fun setButtonPopupOnClickListener(listener: FBPopupListener) {
        TODO("Not yet implemented")
    }


    override fun isVisible(isVisible: Boolean) {
        button.visibility = if (isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

}