package com.formbuilder.sdk.utils.managers

import android.Manifest
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class PermissionsManager {

    companion object {
        const val REQUEST_READ_WRITE_STORAGE = Manifest.permission.WRITE_EXTERNAL_STORAGE
        const val REQUEST_CAMERA_USE = Manifest.permission.CAMERA
        const val REQUEST_CODE_CAMERA_USE = 1
    }

    fun checkCameraPermission(
        fragment: Fragment,
        alsoRequest: Boolean = false
    ): Boolean {

        return checkPermissionFor(
            fragment = fragment,
            permissions = arrayOf(REQUEST_CAMERA_USE),
            requestCode = REQUEST_CODE_CAMERA_USE,
            alsoRequest = alsoRequest
        )[0]
    }

    private fun checkPermissionFor(
        fragment: Fragment,
        permissions: Array<String>,
        requestCode: Int? = null,
        alsoRequest: Boolean = false
    ): Array<Boolean> {

        val permissionsGrantedArray = mutableListOf<Boolean>()

        if (!permissions.isNullOrEmpty()) {

            for (permission in permissions) {

                val permissionsGranted = (ContextCompat.checkSelfPermission(
                    fragment.requireContext(),
                    permission
                ) == PackageManager.PERMISSION_GRANTED)

                if (permissionsGranted) {
                    permissionsGrantedArray.add(true)
                } else {
                    if (alsoRequest && requestCode == -1) {
                    } else {
                        permissionsGrantedArray.add(false)
                    }
                }
            }

            if (alsoRequest) {
                ActivityCompat.requestPermissions(
                    fragment.requireActivity(),
                    permissions,
                    requestCode ?: -1
                )
            }

        } else {

        }

        return permissionsGrantedArray.toTypedArray()
    }

}