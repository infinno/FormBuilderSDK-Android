package com.formbuilder.sdk.presenter.activities

import android.Manifest
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityOptionsCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.formbuilder.sdk.R
import com.formbuilder.sdk.app.FormBuilderSDK
import com.formbuilder.sdk.data.models.FBAppearance
import com.formbuilder.sdk.data.models.FBAppearance.Companion.APPEARANCE_COLORS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_CORNER_RADIUS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_TEXT_SIZE
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_TEXT_SIZE
import com.formbuilder.sdk.data.models.FBAppearance.Companion.LINEAR_PROGRESS_INDICATOR_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.LINEAR_PROGRESS_TRACK_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.PROGRESS_BAR_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.SHOW_CANCEL_BUTTON
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TEXT_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TOAST_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TOAST_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TOAST_TEXT_SIZE
import com.formbuilder.sdk.data.models.FBAppearance.Companion.VIEW_BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.VIEW_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.VIEW_TEXT_SIZE
import com.formbuilder.sdk.data.models.SectionType
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.databinding.StartActivityFormBuilderBinding
import com.formbuilder.sdk.presenter.common.SectionSubmittedListener
import com.formbuilder.sdk.presenter.fragments.FBCameraFragment
import com.formbuilder.sdk.presenter.fragments.FBCreditCalculatorFragment
import com.formbuilder.sdk.presenter.fragments.FBDocDataFragment
import com.formbuilder.sdk.presenter.fragments.FormFragment
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.Constants
import com.formbuilder.sdk.utils.EdgeToEdgeHelper
import com.formbuilder.sdk.utils.EdgeToEdgeHelper.applyStatusBarForSystemTheme
import com.formbuilder.sdk.utils.managers.KoinInitializer
import com.formbuilder.sdk.utils.managers.PermissionsManager
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.koin.androidx.viewmodel.ext.android.viewModel


class StartFormBuilderActivity : AppCompatActivity(), SectionSubmittedListener {

    private lateinit var mRequestPermission: ActivityResultLauncher<String>

    companion object {
        const val UI_HOLDER = "UI_HOLDER"
    }
    private lateinit var uiHolder: UIHolder
    private lateinit var binding: StartActivityFormBuilderBinding
    private lateinit var preferences: SharedPreferences
    private val mViewModel: StartFormBuilderViewModel by viewModel()
    private val allAnswers = mutableListOf<StepField>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        KoinInitializer.initializeKoin(this@StartFormBuilderActivity)

        binding = StartActivityFormBuilderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        EdgeToEdgeHelper.applyTopInsets(this.window, binding.root)
        window?.applyStatusBarForSystemTheme(resources.configuration)
        preferences = this.getSharedPreferences(APPEARANCE_COLORS, Context.MODE_PRIVATE)
        if (!intent.getStringExtra("baseURL").isNullOrEmpty())
            Constants.BASE_URL  = intent.getStringExtra("baseURL").toString()
        //checkAppearance()
        mRequestPermission =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { permission ->
                if (isCameraPermissionGranted()) {
                    onCameraPermissionGranted()
                } else {
                    onCameraPermissionDenied()
                }
            }

        mViewModel.observeGetStepSectionView().observe(this){
            navigateForward(it)
        }

        mViewModel.observeGetDirectionView().observe(this){
            uiHolder = it
            requestCameraPermission()
        }

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = resources.getColor(R.color.background_color)

        mViewModel.observeLoading().observe(this) {
            binding.progressBar.visibility = if(it) VISIBLE else GONE
        }

        mViewModel.observeFormBuilderView().observe(this) {
            uiHolder = it
            requestCameraPermission()
        }

        lifecycleScope.launchWhenStarted {
            while (true) {
                val message = mViewModel.observeErrorChannel().receive()
                Toast.makeText(this@StartFormBuilderActivity, "Error - $message", Toast.LENGTH_LONG)
                    .show()
            }
        }

        if (!intent.getStringExtra("processID").isNullOrEmpty())
            getUiModel()
        else if (!intent.getStringExtra("stepID").isNullOrEmpty())
            getStep()

        Log.i("WEBSOCKET", "FBStartActivity onCreate")
//        binding.btnOpenProcess.setOnClickListener {
//            getUiModel()
//        }
//
//        binding.btnOpenStep.setOnClickListener {
//            getStep()
//        }
    }

    override fun onStart() {
        super.onStart()
        checkAppearance()
        Log.i("WEBSOCKET", "FBStartActivity onStart")
    }

    fun checkAppearance(){
        val sharedPref = getSharedPreferences(APPEARANCE_COLORS,Context.MODE_PRIVATE) ?: return
        sharedPref.edit().clear().apply()
        val appearance = IntentCompat.getParcelableExtra(intent, "appearance", FBAppearance::class.java)
        val showCancelButton = intent.getBooleanExtra("showCancelButton", false)
        with(sharedPref.edit()) {
            putBoolean(SHOW_CANCEL_BUTTON, showCancelButton)
            apply()
        }
        if (appearance != null){
            with (sharedPref.edit()) {
                if (appearance.textFont != 0){
                    putInt(TEXT_FONT, appearance.textFont)
                }
                if (appearance.buttonFont != 0){
                    putInt(BUTTON_FONT, appearance.buttonFont)
                }
                if (appearance.inputFont != 0){
                    putInt(INPUT_FONT, appearance.inputFont)
                }
                if (appearance.toastFont != 0){
                    putInt(TOAST_FONT, appearance.toastFont)
                }
                if (appearance.toastTextColor != 0){
                    putInt(TOAST_TEXT_COLOR, appearance.toastTextColor)
                }
                if (appearance.toastTextSize != 0){
                    putInt(TOAST_TEXT_SIZE, appearance.toastTextSize)
                }
                if (appearance.viewTextSize != 0){
                    putInt(VIEW_TEXT_SIZE, appearance.viewTextSize)
                }
                if (appearance.inputTextSize != 0){
                    putInt(INPUT_TEXT_SIZE, appearance.inputTextSize)
                }
                if (appearance.buttonTextSize != 0){
                    putInt(BUTTON_TEXT_SIZE, appearance.buttonTextSize)
                }
                if (appearance.buttonCornerRadius != null){
                    putString(BUTTON_CORNER_RADIUS, appearance.buttonCornerRadius.toString())
                }
                if (appearance.backgroundColor != 0){
                    putInt(BACKGROUND_COLOR, appearance.backgroundColor)
                    binding.activityFormBuilderMainLayout.setBackgroundColor(appearance.backgroundColor)
                }
                if (appearance.textColor != 0)
                    putInt(TEXT_COLOR, appearance.textColor)
                if (appearance.viewTextColor != 0)
                    putInt(VIEW_TEXT_COLOR, appearance.viewTextColor)
                if (appearance.viewBackgroundColor != 0)
                    putInt(VIEW_BACKGROUND_COLOR, appearance.viewBackgroundColor)
                if (appearance.inputTextColor != 0)
                    putInt(INPUT_TEXT_COLOR, appearance.inputTextColor)
                if (appearance.inputBackgroundColor != 0)
                    putInt(INPUT_BACKGROUND_COLOR, appearance.inputBackgroundColor)
                if (appearance.buttonTextColor != 0)
                    putInt(BUTTON_TEXT_COLOR, appearance.buttonTextColor)
                if (appearance.buttonBackgroundColor != 0)
                    putInt(BUTTON_BACKGROUND_COLOR, appearance.buttonBackgroundColor)
                if (appearance.progressBarColor != 0){
                    putInt(PROGRESS_BAR_COLOR, appearance.progressBarColor)
                    binding.progressBar.indeterminateDrawable.colorFilter = PorterDuffColorFilter(appearance.progressBarColor, PorterDuff.Mode.SRC_IN)
                }
                if (appearance.linearProgressIndicatorColor != 0)
                    putInt(LINEAR_PROGRESS_INDICATOR_COLOR, appearance.linearProgressIndicatorColor)
                if (appearance.linearProgressTrackColor != 0)
                    putInt(LINEAR_PROGRESS_TRACK_COLOR, appearance.linearProgressTrackColor)
                apply()
            }
        }
    }

    private fun requestCameraPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!isCameraPermissionGranted()) {
                mRequestPermission.launch(PermissionsManager.REQUEST_CAMERA_USE)
            } else {
                onCameraPermissionGranted()
            }
        } else {
            if (isCameraPermissionGranted()) {
                onCameraPermissionGranted()
            } else {
                requestPermissions()
            }
        }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (isCameraPermissionGranted()) {
                onCameraPermissionGranted()
            }
        } else {
            mRequestPermission.launch(PermissionsManager.REQUEST_CAMERA_USE)
        }
    }

    private fun isCameraPermissionGranted(): Boolean {
        return (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }

    private fun onCameraPermissionDenied() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!shouldShowRequestPermissionRationale(Manifest.permission.CAMERA)){
                Toast.makeText(this, "Camera Permission Denied, enable from app settings", Toast.LENGTH_LONG).show()
                return
            }
            else{
                Toast.makeText(this, "Camera Permission Denied", Toast.LENGTH_LONG).show()
                mViewModel.getStep(
                    uiHolder.section?.submissionId ?: "",
                    uiHolder.section?.settings?.noCameraAccessDirectionStepId ?: "",
                    uiHolder.section?.settings?.noCameraAccessDirectionStepId ?: "",
                    stepFields = emptyList()
                )
            }
        }
        else{
            Toast.makeText(this, "Camera Permission Denied", Toast.LENGTH_LONG).show()
            mViewModel.getStep(
                uiHolder.section?.submissionId ?: "",
                uiHolder.section?.settings?.noCameraAccessDirectionStepId ?: "",
                uiHolder.section?.settings?.noCameraAccessDirectionStepId ?: "",
                stepFields = emptyList()
            )
        }


    }

    private fun onCameraPermissionGranted() {
        val intent = Intent(this, FormBuilderMainActivity::class.java)
        GlobalScope.launch {
            delay(500)
            intent.putExtra(UI_HOLDER, uiHolder)
            startActivity(intent)
            finish()
        }
//        intent.putExtra(UI_HOLDER, uiHolder)
//        startActivity(intent)
//        finish()
    }

    private fun getUiModel(){
        val processId = intent.getStringExtra("processID")!!
        val serviceToken = intent.getStringExtra("callingServiceToken")
        mViewModel.startForm(processId, if (serviceToken.isNullOrEmpty()) "" else serviceToken)
    }

    private fun getStep(){
        val stepId = intent.getStringExtra("stepID")!!
        mViewModel.getDirection(stepId)
    }

    private fun addFragmentToActivity(fragment: Fragment) {
        val fm = supportFragmentManager
        val tr = fm.beginTransaction()
        tr.add(R.id.activity_main_fragment_container, fragment)
        tr.commit()
    }

    override fun onSectionSubmittedWithValidAnswers(
        submissionId: String,
        directionId: String,
        fromDirectionId: String,
        fromFlowDirectionId: String,
        answers: List<StepField>,
        activityId: Int?
    ) {
        answers.forEach { newAnswer ->
            allAnswers.removeAll {
                it.key == newAnswer.key
            }
        }
        allAnswers.addAll(answers)

        //if last step, then submit all answers
        mViewModel.getStep(
            submissionId,
            directionId,
            fromDirectionId = fromDirectionId,
            fromFlowFieldId = fromFlowDirectionId,
            stepFields = answers
        )
    }

    override fun onBackPressed() {
        val count = supportFragmentManager.backStackEntryCount

        if (count == 0) {
            if (binding.activityMainFragmentContainer.childCount == 0)
                super.onBackPressed()
            else
                binding.activityMainFragmentContainer.removeAllViews()
        } else {
            supportFragmentManager.popBackStack()
        }
    }

    fun navigateForward(uiHolder: UIHolder) {
        val fragment = getFragment(uiHolder)
        if (fragment is FBDocDataFragment){
            binding.activityMainFragmentContainer.removeAllViews()
            requestCameraPermission()
        }
        else{
            addFragmentToActivity(fragment)
        }

    }

    private fun getFragment(uiHolder: UIHolder?): Fragment {
        return when (uiHolder?.section?.type) {
            SectionType.FORM.name,
            SectionType.FLOW.name -> FormFragment.newInstance(uiHolder)
            SectionType.SELFIE.name -> FBCameraFragment.newInstance(uiHolder)
            SectionType.KYC_ID.name,
            SectionType.DOC_DATA.name -> FBDocDataFragment.newInstance(uiHolder)
            SectionType.CREDIT_CALCULATOR.name -> FBCreditCalculatorFragment.newInstance(uiHolder)
            else -> {
                FormFragment.newInstance(uiHolder)
            }
        }
    }
}