package com.formbuilder.sdk.app

import android.app.Application
import com.formbuilder.sdk.utils.appModule
import com.formbuilder.sdk.utils.dataModule
import com.formbuilder.sdk.utils.viewModelsModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.GlobalContext
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin

class FormBuilderSDK : Application() {

    override fun onCreate() {
        super.onCreate()
        initKoin()
    }

    private fun initKoin() {
        if (GlobalContext.getOrNull() != null) {
            // Koin is already started
            stopKoin()
        }
        startKoin {
            androidContext(this@FormBuilderSDK)
            modules(listOf(appModule, viewModelsModule, dataModule))
        }
    }
}