package com.formbuilder.sdk.data.networking.client

import com.formbuilder.sdk.data.networking.models.ApiResponse
import org.koin.core.component.KoinComponent

class ApiErrorHandler : KoinComponent {

    fun <T> getErrorMessage(response: ApiResponse<T>): String {
        val errorMessage = response.error?.errorMsg
        return when {
            !errorMessage.isNullOrEmpty() -> errorMessage
            else -> fallbackErrorMessageOnEmptyCode(response)
        }

    }

    private fun <T> fallbackErrorMessageOnEmptyCode(response: ApiResponse<T>): String {
        val errorCode = response.error?.code

        return when {
            !errorCode.isNullOrEmpty() -> errorCode
            else -> "Unknown error"
        }
    }
}


