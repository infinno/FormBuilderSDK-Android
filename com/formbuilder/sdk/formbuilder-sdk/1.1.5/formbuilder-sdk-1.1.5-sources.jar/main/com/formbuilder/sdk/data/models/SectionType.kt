package com.formbuilder.sdk.data.models

enum class SectionType {
    FORM,
    FLOW,
    SELFIE,
    DOC_DATA,
    CREDIT_CALCULATOR,
    KYC_ID
}