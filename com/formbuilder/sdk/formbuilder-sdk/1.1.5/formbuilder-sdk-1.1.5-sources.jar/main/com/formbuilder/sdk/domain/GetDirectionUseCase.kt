package com.formbuilder.sdk.domain

import com.formbuilder.sdk.data.models.Field
import com.formbuilder.sdk.data.models.Section
import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.repository.FormBuilderRepository
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.helpers.Either

class GetDirectionUseCase(
    private val repository: FormBuilderRepository,
    private val apiErrorHandler: ApiErrorHandler
) : BaseUseCase<Either<String, UIHolder>>(){

    private var sectionMap: MutableMap<String, List<Field>> = mutableMapOf()

    companion object {
        const val PARAM_DIRECTION_ID = "PARAM_DIRECTION_ID"
    }

    override suspend fun run(withData: Map<String, Any>?): Either<String, UIHolder> {
        val directionId =  withData?.get(PARAM_DIRECTION_ID) as String
        val response = repository.getDirection(directionId)
        val responseData = response.responseData
        return if (ApiResponse.checkStatus(response.httpCode) == ApiResponse.STATUS_OK && responseData != null) {
            val uiHolder = createUIHolder(section = responseData, sectionMap = sectionMap)
            Either.Right(uiHolder)
        } else {
            Either.Left(apiErrorHandler.getErrorMessage(response))
        }
    }

    private fun createUIHolder(
        section: Section?,
        sectionMap: MutableMap<String, List<Field>>
    ): UIHolder {
        val uiHolder = UIHolder()
        uiHolder.section = section
        uiHolder.sectionMap = sectionMap
        return uiHolder
    }
}