package com.formbuilder.sdk.data.networking.client

//import android.content.Context
//import android.util.Log
//import com.formbuilder.sdk.utils.managers.WebSocketManager.Companion.TAG
//import org.webrtc.*
//import org.webrtc.PeerConnection.RTCConfiguration
//
//
//class RTCClient(
//    context: Context, observer: PeerConnection.Observer
//) {
//
//    companion object {
//        private const val LOCAL_TRACK_ID = "ARDAMSv0"
//    }
//
//    private var lastChosenCamera = ""
//    private val rootEglBase: EglBase = EglBase.create()
//
//    init {
//        initPeerConnectionFactory(context)
//    }
//
//    private val urls = listOf(
//        "stun:stun.l.google.com:19302",
//        "stun:stun1.l.google.com:19302",
//        "stun:stun2.l.google.com:19302",
//        "stun:stun3.l.google.com:19302",
//        "stun:stun4.l.google.com:19302"
//    )
//
//    private val iceServer = listOf(
//        PeerConnection.IceServer.builder(urls).createIceServer(),
//        PeerConnection.IceServer.builder("turn:turn.daskal.eu:443").setUsername("svilen").setPassword("svilen").createIceServer()
//    )
//
//    private val rtcConfig: RTCConfiguration by lazy {
//        RTCConfiguration(iceServer).apply {
//            tcpCandidatePolicy = PeerConnection.TcpCandidatePolicy.DISABLED
//            bundlePolicy = PeerConnection.BundlePolicy.MAXBUNDLE
//            rtcpMuxPolicy = PeerConnection.RtcpMuxPolicy.REQUIRE
//            continualGatheringPolicy =
//                PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY
//            keyType = PeerConnection.KeyType.ECDSA
//            enableCpuOveruseDetection = false
//        }
//    }
//
//    private val peerConnectionFactory by lazy { buildPeerConnectionFactory() }
//    private val videoCapturer by lazy { getVideoCapturer(context) }
//    private val localVideoSource by lazy { peerConnectionFactory.createVideoSource(false) }
//    private val peerConnection by lazy { buildPeerConnection(observer) }
//    private val constraints = MediaConstraints().apply {
//        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveVideo", "true"))
//        mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio", "false"))
//    }
//
//    private fun initPeerConnectionFactory(context: Context) {
//        val options = PeerConnectionFactory.InitializationOptions.builder(context)
//            .setEnableInternalTracer(true).setFieldTrials("WebRTC-H264HighProfile/Enabled/")
//            .createInitializationOptions()
//        PeerConnectionFactory.initialize(options)
//    }
//
//    private fun buildPeerConnectionFactory(): PeerConnectionFactory {
//        return PeerConnectionFactory.builder()
//            .setVideoDecoderFactory(DefaultVideoDecoderFactory(rootEglBase.eglBaseContext))
//            .setVideoEncoderFactory(
//                DefaultVideoEncoderFactory(
//                    rootEglBase.eglBaseContext, true, true
//                )
//            ).setOptions(PeerConnectionFactory.Options().apply {
//                disableNetworkMonitor = true
//                networkIgnoreMask = 0
//
//            }).createPeerConnectionFactory()
//    }
//
//    private fun buildPeerConnection(observer: PeerConnection.Observer) =
//        peerConnectionFactory.createPeerConnection(
//            rtcConfig, observer
//        )
//
//    private fun getVideoCapturer(context: Context) = createVideoCapturer(context)
//
//    private fun createVideoCapturer(context: Context) =
//        if (Camera2Enumerator.isSupported(context)) {
//            createCameraCapturer(Camera2Enumerator(context))
//        } else {
//            createCameraCapturer(Camera1Enumerator(false))
//        }
//
//
//    private fun createCameraCapturer(enumerator: CameraEnumerator): VideoCapturer? {
//        val deviceNames = enumerator.deviceNames
//        // First, try to find front facing camera
//        for (deviceName in deviceNames) {
//            if (enumerator.isFrontFacing(deviceName)) {
//                val videoCapturer: VideoCapturer? = enumerator.createCapturer(deviceName, null)
//                if (videoCapturer != null) {
//                    return videoCapturer
//                }
//            }
//        }
//
//        // Front facing camera not found, try something else
//        for (deviceName in deviceNames) {
//            if (!enumerator.isFrontFacing(deviceName)) {
//                val videoCapturer = enumerator.createCapturer(deviceName, null)
//                if (videoCapturer != null) {
//                    return videoCapturer
//                }
//            }
//        }
//        return null
//    }
//
//    fun initSurfaceView(view: SurfaceViewRenderer?) = view?.run {
//        init(rootEglBase.eglBaseContext, null)
//    }
//
//    fun startLocalVideoCapture(localVideoOutput: SurfaceViewRenderer?, width: Int, height: Int) {
//        val surfaceTextureHelper =
//            SurfaceTextureHelper.create(Thread.currentThread().name, rootEglBase.eglBaseContext)
//        localVideoOutput?.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
//        localVideoOutput?.setEnableHardwareScaler(true)
//        localVideoOutput?.setMirror(true)
//        localVideoOutput?.disableFpsReduction()
//        localVideoSource.adaptOutputFormat(1920,1440,30)
//        videoCapturer?.initialize(
//            surfaceTextureHelper, localVideoOutput?.context, localVideoSource.capturerObserver
//        )
//        videoCapturer?.startCapture(1920,1440,30)
//        val localVideoTrack =
//            peerConnectionFactory.createVideoTrack(LOCAL_TRACK_ID, localVideoSource)
//        localVideoTrack.addSink(localVideoOutput)
//        peerConnection?.addTrack(localVideoTrack)
//    }
//
//    private fun PeerConnection.call(sdpObserver: SdpObserver) {
//        createOffer(object : SdpObserver by sdpObserver {
//            override fun onCreateSuccess(desc: SessionDescription?) {
//
//                setLocalDescription(object : SdpObserver {
//                    override fun onSetFailure(p0: String?) {
//                        Log.d(TAG, "onSetFailure")
//                    }
//
//                    override fun onSetSuccess() {
//                    }
//
//                    override fun onCreateSuccess(p0: SessionDescription?) {
//
//                    }
//
//                    override fun onCreateFailure(p0: String?) {
//                        Log.d(TAG, "onSetSuccess")
//                    }
//                }, desc)
//                sdpObserver.onCreateSuccess(desc)
//            }
//        }, constraints)
//    }
//
//    fun call(sdpObserver: SdpObserver) = peerConnection?.call(sdpObserver)
//
//    fun addIceCandidate(iceCandidate: IceCandidate?) {
//        peerConnection?.addIceCandidate(iceCandidate)
//    }
//
//    fun onRemoteSessionReceived(sessionDescription: SessionDescription?) {
//        peerConnection?.setRemoteDescription(object : SdpObserver {
//            override fun onSetFailure(p0: String?) {
//                Log.d(TAG, "onSetFailure()")
//            }
//
//            override fun onSetSuccess() {
//                Log.d(TAG, "onSetSuccess()")
//            }
//
//            override fun onCreateSuccess(p0: SessionDescription?) {
//                Log.d(TAG, "onCreateSuccess()")
//            }
//
//            override fun onCreateFailure(p0: String?) {
//                Log.d("", "onCreateFailure()")
//            }
//        }, sessionDescription)
//    }
//
//    fun switchCamera(chosenCamera: String) {
//        if (videoCapturer != null) {
//            if (videoCapturer is CameraVideoCapturer && lastChosenCamera != chosenCamera) {
//                lastChosenCamera = chosenCamera
//                val cameraVideoCapturer = videoCapturer as CameraVideoCapturer
//                cameraVideoCapturer.switchCamera(null, chosenCamera)
//            } else {
//                // Will not switch camera, video capturer is not a camera
//            }
//        }
//    }
//
//    fun stopVideo(){
//        videoCapturer?.stopCapture()
//    }
//
//    fun startVideo(lastChosenCamera: String){
//        (videoCapturer as CameraVideoCapturer).switchCamera(null, lastChosenCamera)
//        videoCapturer?.startCapture(1920,1440,30)
//    }
//
//    fun stop() {
//        if (videoCapturer != null) {
//            videoCapturer?.stopCapture()
//            videoCapturer?.dispose()
//        }
//        if (peerConnection != null) {
//            peerConnection?.close()
//        }
//    }
//}