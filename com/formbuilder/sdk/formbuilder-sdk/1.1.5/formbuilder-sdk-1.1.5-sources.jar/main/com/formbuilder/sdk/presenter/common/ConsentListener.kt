package com.formbuilder.sdk.presenter.common

interface ConsentListener {
    fun viewConsent(key: String)
}