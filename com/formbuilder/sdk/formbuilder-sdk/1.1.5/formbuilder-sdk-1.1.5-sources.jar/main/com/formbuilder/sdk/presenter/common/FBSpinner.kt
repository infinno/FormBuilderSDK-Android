package com.formbuilder.sdk.presenter.common

import com.formbuilder.sdk.data.models.FBOption

interface FBSpinner: FBView {
    fun getValue(): String
    fun setSpinnerOptions(label: String, options: List<FBOption>?)
    fun setIsRequired(isRequired: Boolean)
    fun getIsRequired(): Boolean
    fun setErrorMessage(errorMessage: String)
    fun getErrorMessage(): String
    fun checkFieldData(isRequired: Boolean, value:String, error: String): Boolean
    fun setDropDownSelectedListener(dropDownSelectedListener: DropDownSelectedListener)
}