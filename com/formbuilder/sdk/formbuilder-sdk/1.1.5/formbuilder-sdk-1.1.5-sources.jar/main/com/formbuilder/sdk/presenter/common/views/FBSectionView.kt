package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.appcompat.widget.LinearLayoutCompat
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBSectionInput

class FBSectionView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBSectionInput {

    override var key: String = ""
    private var view: LinearLayoutCompat

    init {
        val parent = inflate(context, R.layout.layout_section, this)
        view = parent.findViewById(R.id.container)
    }

    override fun isVisible(isVisible: Boolean) {
        view.visibility = if(isVisible) VISIBLE else GONE
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

    override fun getContainer() = view

    fun setViewId(viewId: Int){
        view.id = viewId
    }
    fun getViewId() = view.id
}