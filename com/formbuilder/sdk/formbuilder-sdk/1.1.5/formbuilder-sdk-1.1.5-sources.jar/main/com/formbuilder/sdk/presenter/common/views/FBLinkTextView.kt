package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.net.Uri
import android.util.AttributeSet
import android.widget.FrameLayout
import android.widget.TextView
import androidx.fragment.app.FragmentActivity
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBFieldText

class FBLinkTextView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0,
    url: String
) : FrameLayout(context, attrSet, defStyleAttr), FBFieldText {

    override var key: String = ""
    private val text: TextView
    private var newTab: Boolean = false
    private val url = url

    init {
        val view = inflate(context, R.layout.layout_link_text, this)
        text = view.findViewById(R.id.layout_text_view)

        // is necessary to avoid having the same component twice on the screen with the same id.
        text.id = generateViewId()
        text.isClickable = true
        text.paintFlags = Paint.UNDERLINE_TEXT_FLAG
        setUrl(url)
    }

    override fun setValue(value: String?) {
        text.text = value
    }

    override fun setBold(isBold: Boolean?) {
    }

    private fun setUrl(url: String) {
        var u = url
        if (!u.startsWith("https://") && !u.startsWith("http://"))
            u = "https://$u"
        val finalUrl = u
        text.setOnClickListener {

            if (!newTab){
                val activity = context as? FragmentActivity ?: return@setOnClickListener
                FBWebViewDialogFragment.newInstance(finalUrl)
                    .show(activity.supportFragmentManager, "fb_webview")
            }else{
                val webIntent = Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse(u)
                )
                context.startActivity(webIntent)
            }
        }
    }

    override fun isVisible(isVisible: Boolean) {
        text.visibility = if(isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }
    fun setInNewTab(inNewTab: Boolean){
        newTab = inNewTab
    }

}