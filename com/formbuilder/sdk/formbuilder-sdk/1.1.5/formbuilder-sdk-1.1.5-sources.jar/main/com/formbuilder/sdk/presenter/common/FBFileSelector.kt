package com.formbuilder.sdk.presenter.common

interface FBFileSelector: FBView {

    fun setLabelMessage(labelMessage: String)
    fun setButtonMessage(buttonMessage: String)
    fun setSelectedFileName(selectedFileName: String)
    fun setErrorMessage(errorMessage: String)
    fun getErrorMessage(): String
    fun checkFieldData(regex: String, value:String, error: String): Boolean

}