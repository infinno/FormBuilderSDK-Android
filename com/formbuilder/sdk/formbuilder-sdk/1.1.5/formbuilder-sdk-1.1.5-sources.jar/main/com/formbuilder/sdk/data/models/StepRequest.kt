package com.formbuilder.sdk.data.models

import com.google.gson.annotations.SerializedName

data class StepRequest(
    @SerializedName("submissionId")
    val submissionId: String?,
    @SerializedName("directionId")
    val directionId: String?,
    @SerializedName("fromDirectionId")
    val fromDirectionId: String? = null,
    @SerializedName("fromFlowFieldId")
    val fromFlowFieldId: String? = null,
    @SerializedName("fields")
    val stepFields: List<StepField>?,
    @SerializedName("activityId")
    val activityId: Int? = null
)