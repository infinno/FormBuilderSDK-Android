package com.formbuilder.sdk.utils

import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.client.HttpClient
import com.formbuilder.sdk.data.networking.client.RetrofitClient
import com.formbuilder.sdk.data.networking.datasource.FormBuilderDataSource
import com.formbuilder.sdk.data.networking.datasource.SmartCheckDataSource
import com.formbuilder.sdk.data.repository.FormBuilderRepository
import com.formbuilder.sdk.data.repository.FormBuilderRepositoryImpl
import com.formbuilder.sdk.data.repository.SmartCheckRepository
import com.formbuilder.sdk.data.repository.SmartCheckRepositoryImpl
import com.formbuilder.sdk.domain.*
import com.formbuilder.sdk.presenter.activities.FormBuilderMainActivityViewModel
import com.formbuilder.sdk.presenter.activities.StartFormBuilderViewModel
import com.formbuilder.sdk.presenter.fragments.FBCameraViewModel
import com.formbuilder.sdk.presenter.fragments.FBCreditCalculatorViewModel
import com.formbuilder.sdk.presenter.fragments.FBDocDataViewModel
import com.formbuilder.sdk.utils.managers.PermissionsManager
import com.formbuilder.sdk.utils.managers.WebSocketManager
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.dsl.module

val appModule = module {
    factory { HttpClient(androidContext()) }
    factory { (url: String, userHash: String) -> WebSocketManager(url, userHash) }
    factory { (url: String) -> RetrofitClient(url, get()) }
    single { PermissionsManager() }
    single { ApiErrorHandler() }
}

val viewModelsModule = module {
    viewModel { StartFormBuilderViewModel(get(), get(), get()) }
    viewModel { FormBuilderMainActivityViewModel(get(), get()) }
    viewModel { FBCameraViewModel(get(), get()) }
    viewModel { FBDocDataViewModel(get(), get()) }
    viewModel { FBCreditCalculatorViewModel(get(), get()) }
}

val dataModule = module {
    // Use cases
    factory { StartFormUseCase(get(), get()) }
    factory { GetSelfieStatusUseCase(get(), get()) }
    factory { GetStepUseCase(get(), get()) }
    factory { GetSectionUseCase(get(), get()) }
    factory { GetDocDataStatusUseCase(get(), get()) }
    factory { GetProductUseCase(get(), get()) }
    factory { GetInstallmentDetailsUseCase(get(), get()) }
    factory { GetDirectionUseCase(get(), get()) }

    //Repositories
    single<FormBuilderRepository> { FormBuilderRepositoryImpl(get()) }
    single<SmartCheckRepository> { SmartCheckRepositoryImpl(get()) }

    //Data stores
    single { FormBuilderDataSource() }
    single { SmartCheckDataSource() }
}
