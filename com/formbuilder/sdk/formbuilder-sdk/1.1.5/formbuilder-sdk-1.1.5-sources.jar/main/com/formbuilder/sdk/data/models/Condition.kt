package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Condition(
    @SerializedName("fieldKey")
    val fieldKey: String?,
    @SerializedName("operator")
    val operator: String?,
    @SerializedName("hide")
    val hide: Boolean,
    @SerializedName("sectionKey")
    val sectionKey: String?,
    @SerializedName("value")
    val value: String? = null
): Parcelable