package com.formbuilder.sdk.data.models

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class FBAppearance(
    val buttonFont: Int = 0,
    val textFont: Int = 0,
    val inputFont: Int = 0,
    val toastFont: Int = 0,
    val toastTextColor: Int = 0,

    val toastTextSize: Int = 0,
    val viewTextSize: Int = 0,
    val inputTextSize: Int = 0,
    val buttonTextSize: Int = 0,

    val buttonCornerRadius: Float? = null,
    val textColor: Int = 0,
    val backgroundColor: Int = 0,
    val viewTextColor: Int = 0,
    val viewBackgroundColor: Int = 0,
    val inputTextColor: Int = 0,
    val inputBackgroundColor: Int = 0,
    val buttonTextColor: Int = 0,
    val buttonBackgroundColor: Int = 0,
    val progressBarColor: Int = 0,
    val linearProgressIndicatorColor: Int = 0,
    val linearProgressTrackColor: Int = 0
): Parcelable {
    companion object {
        const val APPEARANCE_COLORS = "FBAppearance"
        const val TEXT_FONT = "font"
        const val INPUT_FONT = "inputFont"
        const val BUTTON_FONT = "buttonFont"
        const val TOAST_FONT = "toastFont"
        const val TOAST_TEXT_COLOR = "toastTextColor"
        const val BUTTON_CORNER_RADIUS = "buttonCornerRadius"
        const val TOAST_TEXT_SIZE = "toastTextSize"
        const val VIEW_TEXT_SIZE = "viewTextSize"
        const val INPUT_TEXT_SIZE = "inputTextSize"
        const val BUTTON_TEXT_SIZE = "buttonTextSize"

        const val TEXT_COLOR = "textColor"
        const val BACKGROUND_COLOR = "backgroundColor"
        const val VIEW_TEXT_COLOR = "viewTextColor"
        const val VIEW_BACKGROUND_COLOR = "viewBackgroundColor"

        const val INPUT_TEXT_COLOR = "inputTextColor"
        const val INPUT_BACKGROUND_COLOR = "inputBackgroundColor"
        const val BUTTON_TEXT_COLOR = "buttonTextColor"
        const val BUTTON_BACKGROUND_COLOR = "buttonBackgroundColor"
        const val PROGRESS_BAR_COLOR = "progressBarColor"
        const val LINEAR_PROGRESS_INDICATOR_COLOR = "linearProgressIndicatorColor"
        const val LINEAR_PROGRESS_TRACK_COLOR = "linearProgressTrackColor"
        const val SHOW_CANCEL_BUTTON = "cancelButton"

        const val PROCESS_SETTINGS = "processSettings"
        const val DEFAULT_PROCESS_ID = "defaultProcessID"
        const val PROCESS_ID = "processID"
        const val DEFAULT_STEP_ID = "defaultStepID"
        const val STEP_ID = "stepID"
    }
}