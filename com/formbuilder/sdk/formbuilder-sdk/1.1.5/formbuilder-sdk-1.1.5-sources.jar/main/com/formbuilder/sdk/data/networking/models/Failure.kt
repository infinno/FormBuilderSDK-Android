package com.formbuilder.sdk.data.networking.models

import com.google.gson.annotations.SerializedName

data class Failure(
    @SerializedName("Name")
    var name: String,
    @SerializedName("Reason")
    var reason: String,
    @SerializedName("Code")
    var code: String?
)