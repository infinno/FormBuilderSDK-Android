package com.formbuilder.sdk.presenter.models

import android.os.Parcelable
import com.formbuilder.sdk.data.models.Field
import com.formbuilder.sdk.data.models.Section
import com.formbuilder.sdk.data.models.SectionFields
import kotlinx.parcelize.Parcelize

@Parcelize
data class UIHolder(
    var section: Section? = null,
    var sectionFields: List<SectionFields>? = null,
    var sectionMap: MutableMap<String, List<Field>>? = null
): Parcelable