package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.graphics.drawable.DrawableCompat
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance.Companion.APPEARANCE_COLORS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_CORNER_RADIUS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_TEXT_SIZE
import com.formbuilder.sdk.presenter.common.FBButton
import com.formbuilder.sdk.presenter.common.FBButtonListener
import com.formbuilder.sdk.utils.setRoundnessDp

class FBButtonView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBButton {

    override var key: String = ""
    private val button: AppCompatButton
    private var buttonDirectionId: String = ""
    private var fieldId = 0

    init {
        val preferences = context.getSharedPreferences(APPEARANCE_COLORS, Context.MODE_PRIVATE)
        val view = inflate(context, R.layout.layout_button, this)
        button = view.findViewById(R.id.layout_button_button)
        button.setTextColor(preferences.getInt(BUTTON_TEXT_COLOR, ContextCompat.getColor(context,R.color.white)))
        DrawableCompat.setTint(
            DrawableCompat.wrap(button.background),
            preferences.getInt(BUTTON_BACKGROUND_COLOR, ContextCompat.getColor(context,R.color.a1_color))
        )

        button.typeface = ResourcesCompat.getFont(context, R.font.a1_serif_regular)
        button.apply {
            val font = preferences.getInt(BUTTON_FONT, 0)
            if (font != 0){
                val tf = font.let { ResourcesCompat.getFont(context, it) }
                if (tf != null) {
                    typeface = tf
                }
            }

            if (preferences.getInt(BUTTON_TEXT_SIZE, 0) != 0){
                textSize = preferences.getInt(BUTTON_TEXT_SIZE, 18).toFloat()
            }
        }

        val buttonRadius = preferences.getString(BUTTON_CORNER_RADIUS, null)?.toFloatOrNull()
        if (buttonRadius != null){
            button.setRoundnessDp(buttonRadius)
        }


        // is necessary to avoid having the same component twice on the screen with the same id.
        button.id = generateViewId()
        key = button.id.toString()
    }

    override fun setDirectionId(directionId: String) {
        buttonDirectionId = directionId
    }

    override fun setValue(value: String?) {
        button.text = value
    }

    override fun setFieldId(id: Int) {
        fieldId = id
    }

    override fun setButtonOnClickListener(listener: FBButtonListener) {
        button.setOnClickListener {
            listener.onFBButtonClicked(
                key = key,
                directionId = buttonDirectionId,
                fieldId = fieldId
            )
        }
    }

    override fun isVisible(isVisible: Boolean) {
        button.visibility = if (isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

    override fun setGravity(gravity: String) {

    }
}