package com.formbuilder.sdk.data.networking.services

import com.formbuilder.sdk.data.models.FBDataStatusResponse
import com.formbuilder.sdk.data.models.Section
import com.formbuilder.sdk.data.models.SectionFields
import com.formbuilder.sdk.data.models.StartFormRequest
import com.formbuilder.sdk.data.models.StepRequest
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface FormBuilderService {

    @POST(START_FORM_PATH)
    fun startForm(@Body startFormRequest: StartFormRequest): Call<Section>

    @GET(GET_SECTION_PATH)
    fun getSection(
        @Path(SUBMISSION_ID) submissionId: String,
        @Path(SECTION_KEY) sectionKey: String
    ): Call<List<SectionFields>>

    @POST(STEP_PATH)
    fun getStep(
        @Body stepRequest: StepRequest
    ): Call<Section>

    @GET(GET_SELFIE_STATUS_PATH)
    fun getSelfieStatus(
        @Path(SUBMISSION_ID) submissionId: String,
        @Path(USER_HASH) userHash: String
    ): Call<FBDataStatusResponse>

    @GET(GET_DOC_DATA_STATUS_PATH)
    fun getDocDataStatus(
        @Path(SUBMISSION_ID) submissionId: String,
        @Path(USER_HASH) userHash: String
    ): Call<FBDataStatusResponse>

    @GET(GET_DIRECTION_PATH)
    fun getDirection(
        @Path(DIRECTION_ID) directionId: String
    ): Call<Section>


    companion object {
        const val SUBMISSION_ID = "submissionID"
        const val DIRECTION_ID = "directionID"
        const val USER_HASH = "userHash"
        const val SECTION_KEY = "sectionKey"
        const val START_FORM_PATH = "submission"
        const val GET_SECTION_PATH = "step/{$SUBMISSION_ID}/{$SECTION_KEY}"
        const val STEP_PATH = "step"
        const val GET_SELFIE_STATUS_PATH = "step/selfie-status/{$SUBMISSION_ID}/{$USER_HASH}"
        const val GET_DOC_DATA_STATUS_PATH = "step/v3/status/kyc/{$SUBMISSION_ID}/{$USER_HASH}"
        const val GET_DIRECTION_PATH = "step/direction/{$DIRECTION_ID}/current"
    }
}