package com.formbuilder.sdk.data.networking.client

import android.content.Context
import com.formbuilder.sdk.R
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.io.InputStream
import java.security.KeyStore
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory
import javax.net.ssl.X509TrustManager


class HttpClient(context: Context) {
    val mContext = context

    private val okHttpBuilder: OkHttpClient.Builder by lazy {
        OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).writeTimeout(60, TimeUnit.SECONDS)
    }

    fun get(): OkHttpClient {
//        // Load the certificates from res/raw
//        val certificateFactory = CertificateFactory.getInstance("X.509")
//        val keyStore = KeyStore.getInstance(KeyStore.getDefaultType()).apply {
//            load(null) // Initialize an empty KeyStore
//        }
//
//        // Load the first certificate
//
//        val cert1InputStream: InputStream = mContext.resources.openRawResource(R.raw.smartitbg)
//        val cert1: Certificate = certificateFactory.generateCertificate(cert1InputStream)
//        cert1InputStream.close()
//        keyStore.setCertificateEntry("cert1", cert1)
//
//        // Load the second certificate
//        val cert2InputStream: InputStream = mContext.resources.openRawResource(R.raw.easycredit)
//        val cert2: Certificate = certificateFactory.generateCertificate(cert2InputStream)
//        cert2InputStream.close()
//        keyStore.setCertificateEntry("cert2", cert2)
//
//        // Create a TrustManagerFactory and SSLContext
//        val trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
//        trustManagerFactory.init(keyStore)
//
//        val sslContext = SSLContext.getInstance("TLS").apply {
//            init(null, trustManagerFactory.trustManagers, null)
//        }
//
//        // Build the OkHttpClient with custom SSL settings
//        val trustManager = trustManagerFactory.trustManagers[0] as X509TrustManager

        return okHttpBuilder.addInterceptor(getLoggingInterceptor())
            .addInterceptor(HeaderInterceptor()).build()
    }

    private fun getLoggingInterceptor(): HttpLoggingInterceptor =
        HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY)
}
