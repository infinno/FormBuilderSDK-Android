package com.formbuilder.sdk.utils.helpers.multimedia;

import android.content.Context;
import android.graphics.ImageFormat;
import android.hardware.Camera;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import com.formbuilder.sdk.utils.SDKProperties;
import com.formbuilder.sdk.utils.managers.WebSocketManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CameraPreview extends SurfaceView implements SurfaceHolder.Callback
{
    public int supportedWidth = 2048;
    public int supportedHeight = 1536;

    public int supportedWidth16 = 1280;
    public int supportedHeight16 = 720;
    private List<String> supportedCameraSizes4_3 = new ArrayList<>();
    private List<String> supportedCameraSizes16_9 = new ArrayList<>();
    private List<String> unsupportedCameraSizes = new ArrayList<>(Arrays.asList("1920x1440"));
    Camera camera;
    SurfaceHolder surfaceHolder;
    VideoEncoder encoder;
    Context context;
    boolean isBackFacing;
    WebSocketManager webSocketManager;

    private int cameraId = 0;

    public CameraPreview(Context context) {
        super(context);
        this.context = context;
        //setFields();
    }

    public CameraPreview(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.context = context;
        //setFields();
    }

    public CameraPreview(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        this.context = context;
        //setFields();
    }

    public int getSupportedWidth() {
        return supportedWidth;
    }

    public int getSupportedHeight() {
        return supportedHeight;
    }

    private void setFields() {
        Log.d("MANUFACTURER", Build.MANUFACTURER);
        Log.d("MODEL", Build.MODEL);
        Log.d("HARDWARE", Build.HARDWARE);

        camera = Camera.open(cameraId);
        Camera.Parameters parameters = camera.getParameters();

        for (Camera.Size size : parameters.getSupportedPictureSizes()) {
            Log.d("CAMERA SIZES", size.width + "x" + size.height);
            double ratio = Math.floor(((double)size.width/(double) size.height) * 100) / 100.0;
            if (ratio == 1.33){
                Log.d("CAMERA SIZES 4:3", size.width + "x" + size.height);
                supportedCameraSizes4_3.add(size.width + "x" + size.height + " / ");
            }
            else if (ratio ==1.77){
                Log.d("CAMERA SIZES 16:9", size.width + "x" + size.height);
                supportedCameraSizes16_9.add(size.width + "x" + size.height + " / ");
            }

            if (1280 <= size.width && size.width < 2048) {
                if (ratio == 1.33 && !unsupportedCameraSizes.contains(size.width + "x" + size.height)){
                    if (supportedWidth > size.width || supportedHeight > size.height){
                        supportedWidth = size.width;
                        supportedHeight = size.height;
                        Log.d("SELECTED CAMERA SIZE", supportedWidth + "x" + supportedHeight);
                    }
                }
                if (ratio == 1.77 && !unsupportedCameraSizes.contains(size.width + "x" + size.height)){
                    if (supportedWidth16 < size.width || supportedHeight16 < size.height){
                        supportedWidth16 = size.width;
                        supportedHeight16 = size.height;
                        Log.d("SELECTED CAMERA SIZE 16", supportedWidth16 + "x" + supportedHeight16);
                    }
                }
            }
        }

        boolean isUnsupported = Build.MANUFACTURER.equalsIgnoreCase("HUAWEI") || Build.MANUFACTURER.equalsIgnoreCase("Google") || Build.MANUFACTURER.equalsIgnoreCase("HONOR");

        if (supportedWidth == 2048){
            SDKProperties.INSTANCE.getCameraParameters().add("No 4:3 resolution found - setting 16:9");
            supportedWidth = supportedWidth16;
            supportedHeight = supportedHeight16;
        }

        if (isUnsupported && !unsupportedCameraSizes.contains("1280x960")){
            SDKProperties.INSTANCE.getCameraParameters().add("Unsupported device found - " + Build.MANUFACTURER + " " + Build.MODEL);
            supportedWidth = 1280;
            supportedHeight = 960;
        }

        boolean isLowSpecDevice = Build.MANUFACTURER.equalsIgnoreCase("HMD Global") && (Build.MODEL.equalsIgnoreCase("Nokia G20") || Build.MODEL.equalsIgnoreCase("Nokia G10"))
                ||
                (Build.MANUFACTURER.equalsIgnoreCase("Cat") &&
                        Build.MODEL.equalsIgnoreCase("S42"));
        if (isLowSpecDevice) {
            supportedWidth = 1280;
            supportedHeight = 720;
            SDKProperties.INSTANCE.getCameraParameters().add("Low spec device - forced resolution 1280x720");
        }

        double finalRatio = Math.floor(((double)supportedWidth/(double) supportedHeight) * 100) / 100.0;
        if (finalRatio == 1.33){
            SDKProperties.INSTANCE.setAspectRatio(1.33);
            SDKProperties.INSTANCE.setBlackLineRatio(2.5);
        }else if (finalRatio == 1.77) {
            SDKProperties.INSTANCE.setAspectRatio(1.77);
            SDKProperties.INSTANCE.setBlackLineRatio(1.5);
        }

        Log.d("FINAl CAMERA SIZE", supportedWidth + "x" + supportedHeight);
        SDKProperties.INSTANCE.setCameraSizes4_3(supportedCameraSizes4_3);
        SDKProperties.INSTANCE.setCameraSizes16_9(supportedCameraSizes16_9);
        SDKProperties.INSTANCE.setCameraResolution(supportedWidth + "x" + supportedHeight);

        sendDebugInfo(Build.MANUFACTURER + "/Model: " + Build.MODEL + "/Android version: " + Build.VERSION.SDK_INT + "/SDK version: " + SDKProperties.INSTANCE.getAppVersion() +
                "/Camera resolution: " + SDKProperties.INSTANCE.getCameraResolution() + "/Camera facing: " + (isBackFacing ? "Back" : "Front") + "/Supported 4:3 resolutions: " + SDKProperties.INSTANCE.getCameraSizes4_3() + "/Supported 16:9 resolutions: " + SDKProperties.INSTANCE.getCameraSizes16_9() + "/Log: " + SDKProperties.INSTANCE.getCameraParameters());

        surfaceHolder = getHolder();
        surfaceHolder.addCallback(this);
    }

    void refreshCamera(Boolean sendDebug)
    {
        boolean exceptionCaught = false;
        if (camera != null){
            try {
                camera.setPreviewCallback(new Camera.PreviewCallback() {
                    @Override
                    public void onPreviewFrame(byte[] bytes, Camera camera) {
                        bytes = YV12toYUV420PackedSemiPlanar(bytes);
                        if(isBackFacing){
                            bytes = rotateYUV420Degree90(bytes,supportedWidth,supportedHeight);
                        }else {
                            bytes = rotateYUV420Degree270(bytes,supportedWidth,supportedHeight);
                        }
                        if(encoder!=null){
                            encoder.offerEncoder(bytes);
                        }
                    }
                });
                Camera.Parameters parameters = camera.getParameters();
                parameters.setPreviewFormat(ImageFormat.YV12);
                parameters.setPreviewSize(supportedWidth, supportedHeight);
                if (parameters.getSupportedFocusModes().contains(
                        Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) {
                    parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO);
                }
                try {
                    SDKProperties.INSTANCE.getCameraParameters().add("Before set parameters " + supportedWidth + "x" + supportedHeight);
                    camera.setParameters(parameters);
                    SDKProperties.INSTANCE.getCameraParameters().add("After set parameters " + supportedWidth + "x" + supportedHeight);
                    if (sendDebug){
                        sendDebugInfo("/Log: " + SDKProperties.INSTANCE.getCameraParameters());
                    }
                }catch (RuntimeException r){
                    SDKProperties.INSTANCE.getCameraParameters().add("EXCEPTION " + supportedWidth + "x" + supportedHeight);
                    sendDebugInfo("/Log: " + SDKProperties.INSTANCE.getCameraParameters());
                    unsupportedCameraSizes.add(supportedWidth + "x" + supportedHeight);
                    supportedWidth = 2048;
                    supportedHeight = 1536;
                    supportedWidth16 = 1280;
                    supportedHeight16 = 720;
                    supportedCameraSizes4_3 = new ArrayList<>();
                    supportedCameraSizes16_9 = new ArrayList<>();
                    camera.release();
                    setFields();
                    exceptionCaught = true;
                }

                if (!exceptionCaught){
                    camera.setDisplayOrientation(90);
                    camera.setPreviewDisplay(surfaceHolder);
                    camera.startPreview();
                }

            } catch (IOException e) {
                SDKProperties.INSTANCE.getCameraParameters().add("IOException " + supportedWidth + "x" + supportedHeight);
                sendDebugInfo("IOException " + supportedWidth + "x" + supportedHeight);
                Log.e(CameraPreview.class.getName(), "Error setting camera preview: " + e.getMessage());
            }
        }
    }

    public void releaseCamera() {
        if (camera != null) {
            camera.release();
            camera = null;
            Log.d("CAMERA", "Camera released");
        }
    }

    public void surfaceCreated(SurfaceHolder holder)
    {
        //refreshCamera();
    }

    public void surfaceDestroyed(SurfaceHolder holder)
    {}

    public void surfaceChanged(SurfaceHolder holder, int format, int w, int h)
    {
        // If your preview can change or rotate, take care of those events here.
        // Make sure to stop the preview before resizing or reformatting it.
        if (surfaceHolder.getSurface() == null){
            // preview surface does not exist
            return;
        }
        try {
            camera.stopPreview();
        } catch (Exception e) {
            // ignore: tried to stop a non-existent preview
        }
        // _startPoint preview with new settings
        refreshCamera(false);
    }

    public void swapCamera(Boolean isBackFacing)
    {
        if(camera == null || this.isBackFacing != isBackFacing){
            this.isBackFacing = isBackFacing;
            int cameraCount = Camera.getNumberOfCameras();
            int selectedCamera = 0;
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            stop();
            Log.d("SWAP_CAMERA", "camera count " + cameraCount);
            SDKProperties.INSTANCE.getSwapCamera().add("Camera count: " + cameraCount);
            if (isBackFacing){
                for (int i = 0; i < cameraCount; i++) {
                    Camera.getCameraInfo(i, cameraInfo);
                    Log.d("SWAP_CAMERA", "camera front/back: " + (cameraInfo.facing == 0 ? "FACING_BACK" : "FACING_FRONT" ) + " camera id " + i);
                    //SDKProperties.INSTANCE.getSwapCamera().add("Camera facing: " + (cameraInfo.facing == 0 ? "FACING_BACK" : "FACING_FRONT" )+ " camera id " + i);
                    boolean isTargetCamera = (isBackFacing && cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK);

                    if (isTargetCamera) {
                        selectedCamera = i;
                        SDKProperties.INSTANCE.getSwapCamera().add("Selected camera: " + (isBackFacing ? "FACING_BACK" : "FACING_FRONT") + " with camera id " + i);
                        Log.d("SWAP_CAMERA", "swapCamera: Selected " + (isBackFacing ? "FACING_BACK" : "FACING_FRONT") + " with camera id " + i);
                        break;
                    }
                }
            }
            else {
                selectedCamera = getBestFrontCameraId();
            }
            try
            {
                cameraId = selectedCamera;
                setFields();
                SDKProperties.INSTANCE.getSwapCamera().add("Camera opened");
            }catch (RuntimeException e)
            {
                SDKProperties.INSTANCE.getSwapCamera().add("EXCEPTION SWAP CAMERA - " + e.getLocalizedMessage());
                sendDebugInfo("EXCEPTION SWAP CAMERA - " + e.getLocalizedMessage());
                Log.e(CameraPreview.class.getName(),"Camera failed to open: " + e.getLocalizedMessage());
            }
            sendDebugInfo(SDKProperties.INSTANCE.getSwapCamera().toString());
            refreshCamera(true);
        }
    }

    public void setEncoder(VideoEncoder encoder) {
        this.encoder = encoder;
    }

    private static byte[] rotateYUV420Degree90(byte[] data, int imageWidth, int imageHeight)
    {
        byte [] yuv = new byte[imageWidth*imageHeight*3/2];
        // Rotate the Y luma
        int i = 0;
        for(int x = 0;x < imageWidth;x++)
        {
            for(int y = imageHeight-1;y >= 0;y--)
            {
                yuv[i] = data[y*imageWidth+x];
                i++;
            }
        }
        // Rotate the U and V color components
        i = imageWidth*imageHeight*3/2-1;
        for(int x = imageWidth-1;x > 0;x=x-2)
        {
            for(int y = 0;y < imageHeight/2;y++)
            {
                yuv[i] = data[(imageWidth*imageHeight)+(y*imageWidth)+x];
                i--;
                yuv[i] = data[(imageWidth*imageHeight)+(y*imageWidth)+(x-1)];
                i--;
            }
        }
        return yuv;
    }

    private static byte[] rotateYUV420Degree270(byte[] data, int imageWidth, int imageHeight)
    {
        byte [] yuv = new byte[imageWidth*imageHeight*3/2];
        // Rotate the Y luma
        int i = 0;
        for(int x = imageWidth-1;x >= 0 ;x--)
        {
            for(int y = imageHeight-1;y >= 0;y--)
            {
                yuv[i] = data[y*imageWidth+x];
                i++;
            }
        }
        // Rotate the U and V color components
        i = imageWidth*imageHeight*3/2-1;
        for(int x = 0; x< imageWidth;x=x+2)
        {
            for(int y = 0;y < imageHeight/2;y++)
            {
                yuv[i] = data[(imageWidth*imageHeight)+(y*imageWidth)+(x+1)];
                i--;
                yuv[i] = data[(imageWidth*imageHeight)+(y*imageWidth)+x];
                i--;

            }
        }
        return yuv;
    }


    public byte[] YV12toYUV420PackedSemiPlanar(final byte[] input) {
        /*
         * COLOR_TI_FormatYUV420PackedSemiPlanar is NV12
         * We convert by putting the corresponding U and V bytes together (interleaved).
         */
        byte[] output = new byte[input.length];
        int vidPixelCount = supportedHeight*supportedWidth;
        int vidPixelQuarterCount = vidPixelCount/4;

        System.arraycopy(input, 0, output, 0, vidPixelCount);
        // Y

        for (int i = 0; i < vidPixelQuarterCount; i++) {
            output[vidPixelCount  + i*2] = input[vidPixelCount + i + vidPixelQuarterCount]; // Cb (U)
            output[vidPixelCount + i*2 + 1] = input[vidPixelCount + i]; // Cr (V)
        }
        return output;
    }

    public void restart() {
        isBackFacing = !isBackFacing;
        //swapCamera();
    }

    public void stop() {
        if (camera != null) {
            camera.setPreviewCallback(null);
            camera.stopPreview();
            camera.release();
            camera = null;
        }
        supportedWidth = 2048;
        supportedHeight = 1536;
        supportedWidth16 = 1280;
        supportedHeight16 = 720;
        supportedCameraSizes4_3 = new ArrayList<>();
        supportedCameraSizes16_9 = new ArrayList<>();
        unsupportedCameraSizes = new ArrayList<>(Arrays.asList("1920x1440"));
        SDKProperties.INSTANCE.setCameraSizes4_3(new ArrayList<>());
        SDKProperties.INSTANCE.setCameraSizes16_9(new ArrayList<>());
        SDKProperties.INSTANCE.setCameraParameters(new ArrayList<>());
        SDKProperties.INSTANCE.setSwapCamera(new ArrayList<>());
    }

    public void setWebSocketManager(WebSocketManager manager){
        this.webSocketManager = manager;
    }

    private void sendDebugInfo(String message){
        if (webSocketManager != null){
            webSocketManager.sendDeviceInfo(message);
        }
    }

    private int getBestFrontCameraId() {
        int numCameras = Camera.getNumberOfCameras();
        int bestCameraId = -1;
        float bestFocalLength = Float.MAX_VALUE; // Choose the camera with the longest focal length (avoiding ultra-wide)

        for (int i = 0; i < numCameras; i++) {
            Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
            Camera.getCameraInfo(i, cameraInfo);

            Log.d("SWAP_CAMERA", "Camera: " + (cameraInfo.facing == 0 ? "FACING_BACK" : "FACING_FRONT" ) + " camera id " + i);
            SDKProperties.INSTANCE.getSwapCamera().add("Camera: " + (cameraInfo.facing == 0 ? "FACING_BACK" : "FACING_FRONT" ) + " camera id " + i);

            if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                Camera camera = null;
                try {
                    camera = Camera.open(i);
                    Camera.Parameters params = camera.getParameters();
                    float focalLength = params.getFocalLength(); // Some cameras report focal length values

                    if (focalLength < bestFocalLength) {
                        bestFocalLength = focalLength;
                        bestCameraId = i;

                    } else if (bestCameraId == -1) {
                        // If no focal length data, just pick the first one
                        bestCameraId = i;
                    }
                } catch (Exception e) {
                    e.printStackTrace(); // Handle camera opening error
                    sendDebugInfo("EXCEPTION FRONT CAMERA - " + e.getLocalizedMessage());
                } finally {
                    if (camera != null) {
                        camera.release();
                    }
                }
            }
        }
        Log.d("SWAP_CAMERA", String.valueOf(bestCameraId));
        SDKProperties.INSTANCE.getSwapCamera().add("Selected camera id: " + bestCameraId);
        return bestCameraId;
    }
}
