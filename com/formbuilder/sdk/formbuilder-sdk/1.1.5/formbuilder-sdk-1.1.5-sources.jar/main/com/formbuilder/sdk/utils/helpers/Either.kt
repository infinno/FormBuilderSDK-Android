package com.formbuilder.sdk.utils.helpers

/**
 * Represents a value of one of two possible types (a disjoint union).
 * Instances of [Either] are either an instance of [Left] or [Right].
 * FP Convention dictates that [Left] is used for "failure"
 * and [Right] is used for "success".
 *
 * @see Left
 * @see Right
 */
sealed class Either<out L, out R> {
    class Left<out L>(val left: L) : Either<L, Nothing>()
    class Right<out R>(val right: R) : Either<Nothing, R>()

    fun onLeft(block: (L) -> Unit): Either<L, R> {
        if (this is Left)
            block(left)
        return this
    }

    fun onRight(block: (R) -> Unit): Either<L, R> {
        if (this is Right)
            block(right)
        return this
    }
}