package com.formbuilder.sdk.utils.managers

import android.content.Context
import com.formbuilder.sdk.utils.appModule
import com.formbuilder.sdk.utils.dataModule
import com.formbuilder.sdk.utils.viewModelsModule
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.GlobalContext
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin

object KoinInitializer {
    fun initializeIfNeeded(context: Context) {
        if (GlobalContext.getOrNull() == null) {
            startKoin(context)
        }
    }

    fun initializeKoin(context: Context){
        if (GlobalContext.getOrNull() != null) {
            // Koin is already started
            stopKoin()
        }
        startKoin(context)
    }

    private fun startKoin(context: Context){
        startKoin {
            androidContext(context)
            modules(listOf(appModule, viewModelsModule, dataModule))
        }
    }
}