package com.formbuilder.sdk.utils

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Build
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.widget.AppCompatButton
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment

fun View?.removeSelf() {
    this ?: return
    val parentView = parent as? ViewGroup ?: return
    parentView.removeView(this)
}

fun Fragment.hideKeyboard(): Boolean {
    return (context?.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager)
        .hideSoftInputFromWindow((activity?.currentFocus ?: View(context)).windowToken, 0)
}

fun AppCompatButton.setRoundnessDp(radiusDp: Float) {
    val radiusPx = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP,
        radiusDp,
        resources.displayMetrics
    )

    val bg = background?.mutate() ?: return

    val unwrapped: Drawable = DrawableCompat.unwrap(bg)

    when (unwrapped) {
        is StateListDrawable -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                for (i in 0 until unwrapped.stateCount) {
                    val child: Drawable = unwrapped.getStateDrawable(i)!!.mutate()
                    (child as? GradientDrawable)?.cornerRadius = radiusPx
                }
                background = unwrapped
            } else {
                background = buildRedRoundedSelector(radiusPx)
            }
        }

        is GradientDrawable -> {
            unwrapped.cornerRadius = radiusPx
            background = unwrapped
        }

        else -> {
            background = buildRedRoundedSelector(radiusPx)
        }
    }
}


private fun buildRedRoundedSelector(radiusPx: Float): StateListDrawable {
    val red = Color.parseColor("#FE382D")
    val strokeWidthPx = 1

    fun makeDrawable(solid: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx
            setStroke(strokeWidthPx, red)

            if (solid) {
                setColor(red)
            } else {
                colors = intArrayOf(red, red)
                orientation = GradientDrawable.Orientation.BOTTOM_TOP // angle -90
            }
        }
    }

    return StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_pressed), makeDrawable(solid = false))
        addState(intArrayOf(android.R.attr.state_focused), makeDrawable(solid = true))
        addState(intArrayOf(), makeDrawable(solid = false))
    }
}