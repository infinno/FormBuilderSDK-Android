package com.formbuilder.sdk.domain

import com.formbuilder.sdk.data.models.Installment
import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.repository.SmartCheckRepository
import com.formbuilder.sdk.utils.helpers.Either

class GetInstallmentDetailsUseCase (
    private val repository: SmartCheckRepository,
    private val apiErrorHandler: ApiErrorHandler
) : BaseUseCase<Either<String, Installment>>() {

    companion object {
        const val PARAM_AMOUNT = "PARAM_AMOUNT"
        const val PARAM_PERIODS = "PARAM_PERIODS"
        const val PRODUCT_ID = "PRODUCT_ID"
    }

    override suspend fun run(withData: Map<String, Any>?): Either<String, Installment> {
        val amount = withData?.get(PARAM_AMOUNT) as Double
        val periods = withData[PARAM_PERIODS] as Int
        val productId = withData[PRODUCT_ID] as Int
        val response = repository.getInstallmentDetails(amount, periods, productId)
        val responseData = response.responseData
        return if (ApiResponse.checkStatus(response.httpCode) == ApiResponse.STATUS_OK && responseData != null) {
            Either.Right(responseData)
        } else {
            Either.Left(apiErrorHandler.getErrorMessage(response))
        }
    }
}