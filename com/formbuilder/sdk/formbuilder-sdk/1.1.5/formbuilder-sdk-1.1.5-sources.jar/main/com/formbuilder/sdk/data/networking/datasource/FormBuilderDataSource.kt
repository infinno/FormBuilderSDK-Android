package com.formbuilder.sdk.data.networking.datasource

import com.formbuilder.sdk.data.models.FBDataStatusResponse
import com.formbuilder.sdk.data.models.Section
import com.formbuilder.sdk.data.models.SectionFields
import com.formbuilder.sdk.data.models.StartFormRequest
import com.formbuilder.sdk.data.models.StepRequest
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.networking.services.FormBuilderService

class FormBuilderDataSource: RemoteDataSource() {

    private val service: FormBuilderService by lazy {
        baseRetrofitClient.createService(FormBuilderService::class.java)
    }

    fun startForm(startFormRequest: StartFormRequest): ApiResponse<Section> =
        getResponseBody(service.startForm(startFormRequest))

    fun getSection(submissionId: String, sectionId: String): ApiResponse<List<SectionFields>> =
        getResponseBody(service.getSection(submissionId, sectionId))

    fun getStep(stepRequest: StepRequest): ApiResponse<Section> =
        getResponseBody(service.getStep(stepRequest))

    fun getSelfieStatus(submissionId: String, userHash: String): ApiResponse<FBDataStatusResponse> =
        getResponseBody(service.getSelfieStatus(submissionId, userHash))

    fun getDocDataStatus(submissionId: String, userHash: String): ApiResponse<FBDataStatusResponse> =
        getResponseBody(service.getDocDataStatus(submissionId, userHash))

    fun getDirection(directionId: String): ApiResponse<Section> =
        getResponseBody(service.getDirection(directionId))
}