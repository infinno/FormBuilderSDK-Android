package com.formbuilder.sdk.presenter.common

import androidx.appcompat.widget.LinearLayoutCompat

interface FBSectionInput: FBView {
    fun getContainer(): LinearLayoutCompat
}