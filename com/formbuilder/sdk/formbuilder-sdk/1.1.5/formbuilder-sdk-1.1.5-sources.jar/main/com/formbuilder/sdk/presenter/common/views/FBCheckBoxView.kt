package com.formbuilder.sdk.presenter.common.views

import android.app.AlertDialog
import android.content.Context
import android.util.AttributeSet
import android.widget.CheckBox
import android.widget.FrameLayout
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBCheckbox


class FBCheckBoxView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBCheckbox {

    override var key: String = ""
    private val checkBox: CheckBox
    private var errorMessageValue = ""
    private var isFieldRequired = false

    init {
        val view = inflate(context, R.layout.layout_checkbox, this)
        checkBox = view.findViewById(R.id.layout_checkbox)

        //This is necessary to avoid having the same component twice on the screen with the same id.
        checkBox.id = generateViewId()
    }

    override fun getValue(): Boolean {
        return checkBox.isChecked
    }

    override fun setLabel(label: String?) {
        checkBox.text = label
    }

    override fun setIsRequired(isRequired: Boolean) {
        isFieldRequired = isRequired
    }

    override fun getIsRequired(): Boolean =
        isFieldRequired

    override fun setErrorMessage(errorMessage: String) {
        errorMessageValue = errorMessage
    }

    override fun getErrorMessage(): String =
        errorMessageValue

    override fun checkFieldData(isRequired: Boolean, value: Boolean, error: String): Boolean {
        if (isRequired && !value) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setMessage(error)
            builder.setCancelable(true)
            builder.setNegativeButton(
                context.getString(R.string.close_btn_label)
            ) { dialog, _ -> dialog.cancel() }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            return false
        }

        return true
    }

    override fun isVisible(isVisible: Boolean) {
        checkBox.visibility = if(isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

    fun getCheckBox() = checkBox

}