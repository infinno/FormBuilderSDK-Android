package com.formbuilder.sdk.utils.helpers.multimedia;

import java.io.Closeable;
import java.io.IOException;
import java.io.OutputStream;

public class FrameHandler implements Closeable {
    private OutputStream os;
    private Thread bufferThread;
    private boolean isRunning=true;


    public FrameHandler(OutputStream os){
        this.os = os;
    }

    //With Odd Timestamp
    public synchronized void addVideoFrame(byte[] frame) throws IOException {
        os.write(frame);
    }

    @Override
    public void close() throws IOException {
        isRunning = false;
        if(bufferThread != null){
            bufferThread.interrupt();
        }
    }
}
