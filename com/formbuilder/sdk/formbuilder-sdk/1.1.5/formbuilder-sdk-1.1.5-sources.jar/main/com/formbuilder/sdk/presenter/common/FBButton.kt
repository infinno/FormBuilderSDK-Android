package com.formbuilder.sdk.presenter.common


interface FBButton: FBView {
    fun setDirectionId(directionId: String)
    fun setValue(value: String?)
    fun setFieldId(id: Int)
    fun setButtonOnClickListener(listener: FBButtonListener)
}