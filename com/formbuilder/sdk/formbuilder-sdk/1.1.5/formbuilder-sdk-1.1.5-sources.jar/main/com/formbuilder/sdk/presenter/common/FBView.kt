package com.formbuilder.sdk.presenter.common

interface FBView {
    var key: String
    fun isVisible(isVisible: Boolean)
    fun setTag(sectionKey: String)
    fun setGravity(gravity: String) { }
}