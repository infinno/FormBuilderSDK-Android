package com.formbuilder.sdk.data.networking.services

import com.formbuilder.sdk.data.models.Installment
import com.formbuilder.sdk.data.models.InstallmentDetailsPayload
import com.formbuilder.sdk.data.models.Product
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Query

interface SmartCheckService {

    @GET(GET_PRODUCTS)
    fun getProducts(
        @Query(PRODUCT_TYPE) productType:String
    ): Call<List<Product>>

    @POST(GET_INSTALLMENT_DETAILS)
    fun getInstallmentDetails(@Body installmentDetailsPayload: InstallmentDetailsPayload): Call<Installment>

    companion object {
        const val PRODUCT_TYPE = "productType"
        const val GET_PRODUCTS = "custom/credit/products/"
        const val GET_INSTALLMENT_DETAILS = "custom/credit/installmentDetails"
    }
}