package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Section(
    @SerializedName("type")
    val type: String?,
    @SerializedName("submissionId")
    val submissionId: String?,
    @SerializedName("directionId")
    val directionId: String?,
    @SerializedName("fields")
    val fields: List<Field>,
    @SerializedName("settings")
    val settings: FBSettings?
): Parcelable