package com.formbuilder.sdk.presenter.common.views

import android.app.AlertDialog
import android.content.Context
import android.util.AttributeSet
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.view.get
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBOption
import com.formbuilder.sdk.presenter.common.FBRadioGroup

class FBRadioGroupView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBRadioGroup {

    override var key: String = ""

    private var optionsList: List<FBOption>? = null
    private val radioGroup: RadioGroup
    private var errorMessageValue = ""
    private var isFieldRequired = false
    private var value: String = ""
    private var radioGroupLabel: TextView

    private val onCheckedChangeListener =
        RadioGroup.OnCheckedChangeListener { radioGroup, id ->
            if (id == radioGroup.checkedRadioButtonId) {
                val radioButton = radioGroup[id]
                value = optionsList?.get(radioButton.id).toString()
            }
        }

    init {
        val view = inflate(context, R.layout.layout_radio_group, this)
        radioGroup = view.findViewById(R.id.layout_radio_group)
        radioGroup.setOnCheckedChangeListener(onCheckedChangeListener)
        radioGroupLabel = view.findViewById(R.id.radio_group_label)
        //This is necessary to avoid having the same component twice on the screen with the same id.
        radioGroup.id = generateViewId()
    }

    override fun getValue(): String =
        value

    override fun setRadioButtons(options: List<FBOption>?) {
        optionsList = options
        options?.forEachIndexed { index, option ->
            val radioButton = RadioButton(context)
            radioButton.layoutParams = LinearLayoutCompat.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            radioButton.id = index
            radioButton.text = option.label
            radioGroup.addView(radioButton)
        }
    }

    override fun setIsRequired(isRequired: Boolean) {
        isFieldRequired = isRequired
    }

    override fun getIsRequired(): Boolean =
        isFieldRequired

    override fun setErrorMessage(errorMessage: String) {
        errorMessageValue = errorMessage
    }

    override fun getErrorMessage(): String =
        errorMessageValue

    override fun checkFieldData(isRequired: Boolean, value: String, error: String): Boolean {
        if (isRequired && value.isEmpty()) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setMessage(error)
            builder.setCancelable(true)
            builder.setNegativeButton(
                context.getString(R.string.close_btn_label)
            ) { dialog, _ -> dialog.cancel() }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            return false
        }

        return true
    }

    override fun setLabel(value: String) {
        radioGroupLabel.text = value
    }

    override fun isVisible(isVisible: Boolean) {
        radioGroup.visibility = if (isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }
}