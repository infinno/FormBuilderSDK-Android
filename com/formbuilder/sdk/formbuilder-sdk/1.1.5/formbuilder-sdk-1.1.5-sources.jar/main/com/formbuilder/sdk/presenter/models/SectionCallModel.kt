package com.formbuilder.sdk.presenter.models

data class SectionCallModel(
    var submissionId: String,
    var key: String
)
