package com.formbuilder.sdk.presenter.models

import android.os.Parcelable
import com.formbuilder.sdk.data.models.Condition
import kotlinx.parcelize.Parcelize

@Parcelize
data class FBGroup(
    val type: String?,
    val condition: Condition? = null,
    val key: String?
): Parcelable