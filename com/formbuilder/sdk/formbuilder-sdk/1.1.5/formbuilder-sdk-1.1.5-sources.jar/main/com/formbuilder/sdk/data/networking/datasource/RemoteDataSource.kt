package com.formbuilder.sdk.data.networking.datasource

import com.formbuilder.sdk.data.networking.client.RetrofitClient
import com.formbuilder.sdk.data.networking.models.ApiError
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.utils.Constants.BASE_URL
import com.formbuilder.sdk.utils.Constants.HTTP_NOT_FOUND
import com.formbuilder.sdk.utils.Constants.SMART_CHECK_BASE_URL
import com.google.gson.Gson
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
import org.koin.core.parameter.parametersOf
import retrofit2.Call
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.net.ssl.SSLPeerUnverifiedException

abstract class RemoteDataSource : KoinComponent {

    protected val baseRetrofitClient: RetrofitClient by inject { parametersOf(BASE_URL) }
    protected val smartCheckRetrofitClient: RetrofitClient by inject { parametersOf(SMART_CHECK_BASE_URL) }

    fun <T> getResponseBody(call: Call<T>): ApiResponse<T> {
        val baseApiResponse = ApiResponse<T>()
        try {

            val response = call.execute()
            baseApiResponse.httpCode = response.code()

            when (ApiResponse.checkStatus(response.code())) {
                ApiResponse.STATUS_OK -> {
                    baseApiResponse.responseStatus = ApiResponse.STATUS_OK
                    baseApiResponse.responseData = response.body()
                }
                ApiResponse.STATUS_ERROR -> {
                    val gson = Gson()
                    baseApiResponse.error = gson.fromJson(
                        response.errorBody()?.charStream(),
                        ApiError::class.java
                    )
                    if (baseApiResponse.httpCode == HTTP_NOT_FOUND) {
                        return baseApiResponse
                    }

                    baseApiResponse.responseStatus = ApiResponse.STATUS_ERROR
                }
                ApiResponse.STATUS_FAILED -> {
                    baseApiResponse.responseStatus = ApiResponse.STATUS_FAILED
                }
            }
        } catch (networkError: Throwable) {
            when (networkError) {
                is ConnectException -> {}
                is UnknownHostException -> {} // No impl needed
                is SocketTimeoutException -> {}
                is SSLPeerUnverifiedException -> {}
            }
        }
        return baseApiResponse
    }
}