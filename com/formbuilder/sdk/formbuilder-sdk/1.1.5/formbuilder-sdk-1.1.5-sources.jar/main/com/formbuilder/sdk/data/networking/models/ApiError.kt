package com.formbuilder.sdk.data.networking.models

import com.google.gson.annotations.SerializedName

/**
 *
 * Example error response:
 * ```json
 *
 *{
 *  "Message": "One or more validation failures have occurred.",
 *  "Failures": [
 *      {
 *          "Name": "PhoneNumber",
 *          "Reason": "The phone number must start with 0 followed by 8 or 9.",
 *          "Code": "401"
 *      }
 *  ]
 *}
 * ```
 *
 * @param failures - holds any kind of data that would be mapped from the response.
 *
 */

data class ApiError(
    @SerializedName("message")
    var errorMsg: String,
    @SerializedName("code")
    var code: String
)