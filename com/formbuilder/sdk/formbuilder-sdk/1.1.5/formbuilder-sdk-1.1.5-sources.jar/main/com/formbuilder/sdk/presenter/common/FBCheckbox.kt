package com.formbuilder.sdk.presenter.common

interface FBCheckbox : FBView {
    fun getValue(): Boolean
    fun setLabel(label: String?)
    fun setIsRequired(isRequired: Boolean)
    fun getIsRequired(): Boolean
    fun setErrorMessage(errorMessage: String)
    fun getErrorMessage(): String
    fun checkFieldData(isRequired: Boolean, value:Boolean, error: String): Boolean
}