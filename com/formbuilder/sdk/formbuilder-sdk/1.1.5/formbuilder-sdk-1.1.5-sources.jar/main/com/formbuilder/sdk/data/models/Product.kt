package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Product(
   @SerializedName("productId")
   val productId: String,
   @SerializedName("productName")
   val productName: String,
   @SerializedName("annualInterestRate")
   val annualInterestRate: Double?,
   @SerializedName("annualExpenseRate")
   val annualExpenseRate: Int?,
   @SerializedName("minPrincipal")
   val minPrincipal: Int?,
   @SerializedName("maxPrincipal")
   val maxPrincipal: Int?,
   @SerializedName("step")
   val step: Int,
   @SerializedName("productPeriodicity")
   val productPeriodicity: String,
   @SerializedName("productType")
   val productType: String,
   @SerializedName("periods")
   val periods: List<FBPeriod>
): Parcelable