package com.formbuilder.sdk.data.models

enum class FieldType {
    INPUT,
    TEXT,
    HINT,
    AREA,
    FLOW,
    NEW_LINE,
    HORIZONTAL_LINE,
    CHECKBOX,
    RADIO,
    DROPDOWN,
    SECTION,
    GROUP,
    CONSENT,
    SUBMIT,
    NOMENCLATURE,
    LINK,
    DATE,
    UPLOAD_FILE,
    POPUP,
    IMAGE
}