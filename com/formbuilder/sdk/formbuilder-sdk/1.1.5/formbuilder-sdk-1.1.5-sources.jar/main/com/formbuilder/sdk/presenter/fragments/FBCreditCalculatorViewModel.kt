package com.formbuilder.sdk.presenter.fragments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.formbuilder.sdk.data.models.Installment
import com.formbuilder.sdk.data.models.Product
import com.formbuilder.sdk.data.models.SettingsProduct
import com.formbuilder.sdk.domain.GetInstallmentDetailsUseCase
import com.formbuilder.sdk.domain.GetProductUseCase
import com.formbuilder.sdk.presenter.base.BaseViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class FBCreditCalculatorViewModel(
    private val getProductUseCase: GetProductUseCase,
    private val getInstallmentDetailsUseCase: GetInstallmentDetailsUseCase
) : BaseViewModel() {

    private var mGetProductJob: Job? = null
    private var mGetInstallmentDetailsJob: Job? = null

    private val mGetProduct = MutableLiveData<List<Product>>()
    fun observeProduct() =
        mGetProduct as LiveData<List<Product>>

    private val mGetInstallmentDetails = MutableLiveData<Installment>()
    fun observeInstallmentDetails() =
        mGetInstallmentDetails as LiveData<Installment>

    fun getProduct(products: List<SettingsProduct>, productType: String) {
        if (isActiveJob(mGetProductJob)) return

        mGetProductJob = viewModelScope.launch {
            mLoadingIndicatorVisible.value = true
            getProductUseCase.executeAsync(
                mapOf(
                    GetProductUseCase.PARAM_PRODUCTS to products,
                    GetProductUseCase.PARAM_PRODUCT_TYPE to productType
                )
            ).onLeft { error ->
                    launch {
                        mErrorChannel.send(error)
                    }
                }
                .onRight { result ->
                    mGetProduct.value = result
                }
            mLoadingIndicatorVisible.value = false
        }

    }

    fun getInstallmentLoanDetails(amount: Double, periods: Int, productId: Int) {
        if (isActiveJob(mGetInstallmentDetailsJob)) return

        mGetInstallmentDetailsJob = viewModelScope.launch {
            mLoadingIndicatorVisible.value = true
            getInstallmentDetailsUseCase.executeAsync(
                mapOf(GetInstallmentDetailsUseCase.PARAM_AMOUNT to amount, GetInstallmentDetailsUseCase.PARAM_PERIODS to periods, GetInstallmentDetailsUseCase.PRODUCT_ID to productId)
            ).onLeft { error ->
                launch {
                    mErrorChannel.send(error)
                }
            }
                .onRight { result ->
                    mGetInstallmentDetails.value = result
                }
            mLoadingIndicatorVisible.value = false
        }
    }
}