package com.formbuilder.sdk.presenter.common

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.formbuilder.sdk.data.models.SectionType
import com.formbuilder.sdk.presenter.fragments.FBCameraFragment
import com.formbuilder.sdk.presenter.fragments.FBCreditCalculatorFragment
import com.formbuilder.sdk.presenter.fragments.FBDocDataFragment
import com.formbuilder.sdk.presenter.fragments.FormFragment
import com.formbuilder.sdk.presenter.models.UIHolder

class PagerAdapter(fragmentManager: FragmentManager, private var uiHolder: UIHolder?) :
    FragmentStatePagerAdapter(fragmentManager, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {

    fun updateUIHolder(newHolder: UIHolder?) {
        uiHolder = newHolder
        notifyDataSetChanged()
    }

    override fun getItemPosition(obj: Any): Int = POSITION_NONE

    override fun getItem(position: Int): Fragment {
        return when (uiHolder?.section?.type) {
            SectionType.FORM.name,
            SectionType.FLOW.name -> FormFragment.newInstance(uiHolder)
            SectionType.SELFIE.name -> FBCameraFragment.newInstance(uiHolder)
            SectionType.KYC_ID.name,
            SectionType.DOC_DATA.name -> FBDocDataFragment.newInstance(uiHolder)
            SectionType.CREDIT_CALCULATOR.name -> FBCreditCalculatorFragment.newInstance(uiHolder)
            else -> {
                FormFragment.newInstance(uiHolder)
            }
        }
    }

    override fun getCount(): Int = 1
}