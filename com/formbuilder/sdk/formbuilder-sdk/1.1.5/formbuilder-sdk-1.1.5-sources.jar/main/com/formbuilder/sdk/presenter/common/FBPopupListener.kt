package com.formbuilder.sdk.presenter.common

interface FBPopupListener: FBView {
    fun onFBPopupClicked(key: String, directionId: String, fieldId: Int)
}