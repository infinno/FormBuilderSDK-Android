package com.formbuilder.sdk.presenter.common

interface FBButtonListener {
    fun onFBButtonClicked(key: String, directionId: String, fieldId: Int)
}