package com.formbuilder.sdk.presenter.fragments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.formbuilder.sdk.data.models.FBDataStatusResponse
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.domain.GetDocDataStatusUseCase
import com.formbuilder.sdk.domain.GetStepUseCase
import com.formbuilder.sdk.presenter.base.BaseViewModel
import com.formbuilder.sdk.presenter.models.UIHolder
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class FBDocDataViewModel(
    private val getStepUseCase: GetStepUseCase,
    private val getDocDataStatusUseCase: GetDocDataStatusUseCase
) : BaseViewModel() {

    private var mGetDocDataStatusJob: Job? = null
    private var getStepJob: Job? = null
    private val mGetStepSectionView = MutableLiveData<UIHolder>()
    fun observeGetStepSectionView() =
        mGetStepSectionView as LiveData<UIHolder>

    private val mGetDocDataStatus = MutableLiveData<FBDataStatusResponse>()
    fun observeDocDataStatus() =
        mGetDocDataStatus as LiveData<FBDataStatusResponse>

    fun getDocDataStatus(submissionId: String, userHash: String) {
        if (isActiveJob(mGetDocDataStatusJob)) return
        mLoadingIndicatorVisible.value = true
        mGetDocDataStatusJob = viewModelScope.launch {
            getDocDataStatusUseCase.executeAsync(
                mapOf(
                    GetDocDataStatusUseCase.PARAM_SUBMISSION_ID to submissionId,
                    GetDocDataStatusUseCase.PARAM_USER_HASH to userHash
                )
            )
                .onLeft { error ->
                    launch {
                        mErrorChannel.send(error)
                        mLoadingIndicatorVisible.value = false
                    }
                }
                .onRight { result ->
                    mGetDocDataStatus.postValue(result)
                    mLoadingIndicatorVisible.value = false
                }
        }
    }

    fun getStep(
        submissionId: String, directionId: String,
        fromDirectionId: String = "", fromFlowFieldId: String = "",
        stepFields: List<StepField>, activityId: Int = 0
    ) {
        if (isActiveJob(getStepJob)) return

        getStepJob = viewModelScope.launch {
            mLoadingIndicatorVisible.value = true
            getStepUseCase.executeAsync(
                mapOf(
                    GetStepUseCase.PARAM_SUBMISSION_ID to submissionId,
                    GetStepUseCase.PARAM_DIRECTION_ID to directionId,
                    GetStepUseCase.PARAM_FROM_DIRECTION_ID to fromDirectionId,
                    GetStepUseCase.PARAM_FROM_FLOW_FIELD_ID to fromFlowFieldId,
                    GetStepUseCase.PARAM_STEP_FIELDS to stepFields,
                    GetStepUseCase.PARAM_ACTIVITY_ID to activityId
                )
            ).onLeft { error ->
                launch {
                    mErrorChannel.send(error)
                    mLoadingIndicatorVisible.value = false
                }
            }.onRight { result ->
                mGetStepSectionView.value = result
                mLoadingIndicatorVisible.value = false
            }
        }
    }

    fun cancelCoroutines() {
        viewModelScope.cancel()
    }

}