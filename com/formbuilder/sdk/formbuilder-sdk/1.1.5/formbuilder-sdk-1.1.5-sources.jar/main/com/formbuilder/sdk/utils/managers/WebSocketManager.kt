package com.formbuilder.sdk.utils.managers

import android.util.Log
import com.formbuilder.sdk.data.networking.client.HttpClient
import com.formbuilder.sdk.utils.Constants.DEBUG
import com.formbuilder.sdk.utils.Constants.SOCKET_CANDIDATE
import com.formbuilder.sdk.utils.Constants.SOCKET_COMMAND_CMD
import com.formbuilder.sdk.utils.Constants.SOCKET_FROM
import com.formbuilder.sdk.utils.Constants.SOCKET_FROM_MOBILE
import com.formbuilder.sdk.utils.Constants.SOCKET_HANDSHAKE
import com.formbuilder.sdk.utils.Constants.SOCKET_TECH_CHECK
import com.google.gson.Gson
import kotlinx.coroutines.runBlocking
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import org.json.JSONObject
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject
//import org.webrtc.IceCandidate
//import org.webrtc.SessionDescription
import java.util.*


class WebSocketManager(private val url: String, private val userHash: String) : KoinComponent {

    companion object {
        val TAG = WebSocketManager::class.java.simpleName
        private const val MAX_NUM = 30  // Maximum number of reconnections
        private const val MILLIS = 1000  // Reconnection interval, milliseconds
    }
    private lateinit var request: Request
    private var messageListener: MessageListener? = null
    private var mWebSocket: WebSocket? = null
    private var isConnect = false
    private var connectNum = 0
    private val client: HttpClient by inject()

    private val webSocketListener: WebSocketListener = object : WebSocketListener() {
        override fun onOpen(
            webSocket: WebSocket,
            response: Response
        ) {
            super.onOpen(webSocket, response)
            Log.i("WEBSOCKET", "onOpen")
            Log.d(TAG, "open:$response")
            isConnect = response.code == 101
            if (!isConnect) {
//                reconnect()
            } else {
                Log.i(TAG, "connect success.")
                messageListener?.onConnectSuccess()
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            super.onMessage(webSocket, text)
            val obj = JSONObject(text)
            when (obj.optString(SOCKET_COMMAND_CMD)) {
                SOCKET_CANDIDATE -> {
//                    Log.d(TAG, "Server response candidate:$obj")
//                    val iceCandidate = JSONObject(obj.optString("candidate"))
//                    messageListener?.onIceCandidateReceived(
//                        IceCandidate(obj.optString("sdpMid"), obj.optInt("sdpLineIndex"), iceCandidate.optString("candidate"))
//                    )
                }
                SOCKET_HANDSHAKE -> {
//                    Log.d(TAG, "Server response handshake:$obj")
//                    messageListener?.onAnswerReceived(
//                        SessionDescription(SessionDescription.Type.ANSWER, obj.optString("sdp"))
//                    )
                }
                else -> {
                    messageListener?.onMessage(text)
                }
            }
        }

        override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
            super.onMessage(webSocket, bytes)
            messageListener?.onMessage(bytes.base64())
        }

        override fun onClosing(
            webSocket: WebSocket,
            code: Int,
            reason: String
        ) {
            super.onClosing(webSocket, code, reason)
            Log.i("WEBSOCKET", "onClosing " + "reason " + reason + " code " + code)
            isConnect = false
            messageListener?.onClose(code)
        }

        override fun onClosed(
            webSocket: WebSocket,
            code: Int,
            reason: String
        ) {
            super.onClosed(webSocket, code, reason)
            Log.i("WEBSOCKET", "onClosed " + reason)
            isConnect = false
            messageListener?.onClose(code)
        }

        override fun onFailure(
            webSocket: WebSocket,
            t: Throwable,
            response: Response?
        ) {
            super.onFailure(webSocket, t, response)
            if (response != null) {
                Log.i(
                    TAG,
                    "connect failed：" + response.message
                )
            }
            Log.i(
                TAG,
                "connect failed throwable：" + t.message
            )
            messageListener?.onConnectFailed()
            //isConnect = false
        }
    }

    /**
     * connect
     */
    fun connect() {
        if (isConnect()) {
            Log.i(TAG, "web socket connected")
            return
        }
        request = Request.Builder().url(url).build()
        mWebSocket = client.get().newWebSocket(request, webSocketListener)
    }

    /**
     * Reconnection
     */
    fun reconnect() {
//        Log.i("WEBSOCKET_RECONNECTED",isConnect.toString())
//        while (!isConnect()){
//            try {
//                Thread.sleep(MILLIS.toLong())
//                connect()
//                Log.i("WEBSOCKET","Reconnect called")
//            } catch (e: InterruptedException) {
//                e.printStackTrace()
//            }
//        }

        if (connectNum <= MAX_NUM) {
            try {
                Thread.sleep(MILLIS.toLong())
                connect()
                connectNum++
                Log.i("WEBSOCKET","Reconnect called " + connectNum)
            } catch (e: InterruptedException) {
                e.printStackTrace()
            }
        } else {
            Log.i(
                TAG,
                "reconnect over $MAX_NUM,please check url or network"
            )
        }
    }

    /**
     * Whether to connect
     */
    fun isConnect(): Boolean {
        return isConnect
    }

    /**
     * send messages
     *
     * @param text string
     * @return boolean
     */
    fun sendMessage(cmd: String) {
        if (!isConnect()) {
            return
        } else {
            val obj = JSONObject()
            obj.put(SOCKET_COMMAND_CMD, cmd)
            obj.put(SOCKET_FROM, userHash)
            obj.put(SOCKET_TECH_CHECK, false)
            obj.put(SOCKET_FROM_MOBILE, false)
            obj.put("callee", userHash)
            Log.d(TAG, "Send message $obj")
            mWebSocket?.send(obj.toString())
        }
    }

    fun sendDeviceInfo(deviceInfo: String) {
        if (!isConnect()) {
            return
        } else {
            val obj = JSONObject()
            obj.put(SOCKET_COMMAND_CMD, "debug")
            obj.put(SOCKET_FROM, userHash)
            obj.put(DEBUG, deviceInfo)
            Log.d(TAG, "Send message $obj")
            mWebSocket?.send(obj.toString())
        }
    }

    fun sendMessageAsBinary(cmd: String) {
        if (!isConnect()) {
            return
        } else {
            val obj = JSONObject()
            obj.put(SOCKET_COMMAND_CMD, cmd)
            obj.put(SOCKET_FROM, userHash)
            obj.put(SOCKET_TECH_CHECK, false)
            obj.put(SOCKET_FROM_MOBILE, false)
            obj.put("callee", userHash)
            Log.d(TAG, "Send message $obj")
            val byteString: ByteString = (obj.toString().toByteArray()).toByteString()
            mWebSocket?.send(byteString)
        }
    }

    fun sendBinaryMessage(byteArray: ByteArray){
        if (!isConnect()){
            return
        }else{
            mWebSocket?.send(byteArray.toByteString())
        }

    }

    fun sendMessage(dataObject: Any?) = runBlocking {
        val iceCandidate = Gson().toJson(dataObject)
        val dataObjectJsonObject = JSONObject(iceCandidate)
        val candidateObj = JSONObject()
        candidateObj.put("candidate",dataObjectJsonObject.optString("sdp"))
        candidateObj.put("sdpMLineIndex",dataObjectJsonObject.optString("sdpMLineIndex"))
        candidateObj.put("sdpMid",dataObjectJsonObject.optString("sdpMid"))
        val obj = JSONObject()
        obj.put("cmd", "candidate")
        obj.put("callee", userHash)
        obj.put("candidate", candidateObj)
        obj.put("from", userHash)
        obj.put("media", "video")
        Log.d(TAG, "Send icecandidate $obj")
        mWebSocket?.send(obj.toString())
    }

    fun sendPeerAnswer() {
        if (!isConnect()) {
            return
        } else {
            val obj = JSONObject()
            obj.put(SOCKET_COMMAND_CMD, "changeMedia")
            obj.put("callee", userHash)
            obj.put("from", userHash)
            obj.put("media", "video")
            Log.d(TAG, "Send peer answer$obj")
            mWebSocket?.send(obj.toString())
        }
    }

    fun sendHandshakeSdp(dataObject: Any?) {
        val obj = Gson().toJson(dataObject)
        val dataObjectJsonObject = JSONObject(obj)
        val jsonObject = JSONObject()
        jsonObject.put("sdp", dataObjectJsonObject.optString("description"))
        jsonObject.put("cmd", "handshake")
        jsonObject.put("callee", userHash)
        jsonObject.put("from", userHash)
        jsonObject.put("outgoing", "true")
        jsonObject.put("media", "video")
        Log.d(TAG, "Send handshake message $jsonObject")
        mWebSocket?.send(jsonObject.toString())
    }

    /**
     * Close connection
     */
    fun close() {
        if (isConnect()) {
            isConnect = false
            mWebSocket?.cancel()
            mWebSocket?.close(1001, "The client actively closes the connection ")
            mWebSocket = null
            messageListener = null
        }
    }

    fun setMessageListener(_messageLister: MessageListener) {
        this.messageListener = _messageLister
    }
}