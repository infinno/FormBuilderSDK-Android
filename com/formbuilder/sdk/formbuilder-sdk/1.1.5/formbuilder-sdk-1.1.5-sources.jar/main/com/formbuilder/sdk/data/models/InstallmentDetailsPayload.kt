package com.formbuilder.sdk.data.models

import com.google.gson.annotations.SerializedName

data class InstallmentDetailsPayload(
    @SerializedName("amount")
    val amount: Double,
    @SerializedName("periods")
    val periods: Int,
    @SerializedName("productId")
    val productId: Int
)