package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class Field(
    @SerializedName("value")
    val value: String? = null,
    @SerializedName("type")
    val type: String? = null,
    @SerializedName("key")
    val key: String? = null,
    @SerializedName("label")
    val label: String? = null,
    @SerializedName("hidden")
    val hidden: Boolean? = null,
    @SerializedName("options")
    val options: List<FBOption>? = null,
    @SerializedName("directionId")
    val directionId: String? = null,
    @SerializedName("directionLabel")
    val directionLabel: String? = null,
    @SerializedName("lng")
    val lng: String? = null,
    @SerializedName("sectionKey")
    val sectionKey: String? = null,
    @SerializedName("required")
    val required: Boolean? = null,
    @SerializedName("validation")
    val validation: String? = null,
    @SerializedName("validationError")
    val validationError: String? = null,
    @SerializedName("styleClass")
    val styleClass: String? = null,
    @SerializedName("variableType")
    val variableType: String? = null,
    @SerializedName("fromFieldId")
    val fromFieldId: String? = null,
    @SerializedName("useInBackofficeUi")
    val useInBackofficeUi: String? = null,
    @SerializedName("flowDirectionId")
    val flowDirectionId: String? = null,
    @SerializedName("direction")
    val direction: Direction? = null,
    @SerializedName("sectionFieldId")
    val sectionFieldId: String? = null,
    @SerializedName("variableLabel")
    val variableLabel: String? = null,
    @SerializedName("condition")
    val condition: Condition? = null,
    @SerializedName("allowClosingSection")
    val allowClosingSection: String? = null,
    @SerializedName("allowAddingMultipleTimes")
    val allowAddingMultipleTimes: String? = null,
    @SerializedName("showFirstSection")
    val showFirstSection: String? = null,
    @SerializedName("sectionIndex")
    val sectionIndex: String? = null,
    @SerializedName("specialType")
    val specialType: String? = null,
    @SerializedName("inNewTab")
    val inNewTab: String? = null,
    @SerializedName("flowDirectionType")
    val flowDirectionType: String? = null,
    @SerializedName("validUntil")
    val validUntil: String? = null,
    @SerializedName("consentVersion")
    val consentVersion: String? = null,
    @SerializedName("operator")
    val operator: List<String>? = null,
    @SerializedName("fieldKey")
    val fieldKey: String? = null,
    @SerializedName("flowFieldId")
    val flowFieldId: Int? = null,
    @SerializedName("fieldId")
    val fieldId: Int = 0,
    @SerializedName("consentContent")
    val consentFields: List<Field>? = listOf(),
    @SerializedName("notes")
    val notes: String? = null,
    @SerializedName("imageUrl")
    val imageUrl: String? = null,
    @SerializedName("size")
    val size: Int? = null,
    @SerializedName("allignment")
    val alignment: String? = null,
    @SerializedName("bold")
    val isBold: Boolean? = null,
    @SerializedName("underline")
    val isUnderline: Boolean? = null,
    @SerializedName("italic")
    val isItalic: Boolean? = null,
    @SerializedName("hideInEndUserFrontend")
    val hideInEndUser: String? = null,
    @SerializedName("defaultValue")
    val defaultValue: String? = null
) : Parcelable