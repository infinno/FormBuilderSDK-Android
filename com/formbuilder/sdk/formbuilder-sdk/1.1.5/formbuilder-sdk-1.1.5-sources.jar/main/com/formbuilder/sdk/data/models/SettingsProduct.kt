package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class SettingsProduct(
    @SerializedName("itemValue")
    val itemValue: String,
    @SerializedName("name")
    val name: String
) : Parcelable