package com.formbuilder.sdk.utils.managers

//import org.webrtc.IceCandidate
//import org.webrtc.SessionDescription

interface MessageListener {
    fun onConnectSuccess () // successfully connected
    fun onConnectFailed () // connection failed
    fun onClose (code: Int) // close
    fun onMessage(text: String)
//    fun onIceCandidateReceived(iceCandidate: IceCandidate)
//    fun onAnswerReceived(description: SessionDescription)
}