package com.formbuilder.sdk.utils.helpers

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.View.GONE
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.FragmentManager
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance.Companion.APPEARANCE_COLORS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.BUTTON_BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.TEXT_COLOR
import com.formbuilder.sdk.databinding.BottomSheetDialogBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment


class RoundedBottomSheet(private val topText: String,private val bottomText: String? = "",private val buttonText: String): BottomSheetDialogFragment() {

    private var mListener: ClickListener? = null
    private lateinit var _binding: BottomSheetDialogBinding

    override fun getTheme(): Int = R.style.BottomSheetDialog
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog = BottomSheetDialog(requireContext(), theme)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = BottomSheetDialogBinding.inflate(inflater, container, false)
        return _binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val preferences = requireContext().getSharedPreferences(APPEARANCE_COLORS, Context.MODE_PRIVATE)
        setTopText(topText)
        setBottomText(bottomText)
        setButtonText(buttonText)
        _binding.roundedDialogButton.setOnClickListener{
            mListener?.onClick()
        }
        _binding.topTextView.setBackgroundColor(preferences.getInt(BACKGROUND_COLOR, ContextCompat.getColor(requireContext(),R.color.transparent)))
        _binding.bottomTextView.setBackgroundColor(preferences.getInt(BACKGROUND_COLOR, ContextCompat.getColor(requireContext(),R.color.transparent)))
        _binding.topTextView.setTextColor(preferences.getInt(TEXT_COLOR, ContextCompat.getColor(requireContext(),R.color.text_color)))
        _binding.bottomTextView.setTextColor(preferences.getInt(TEXT_COLOR, ContextCompat.getColor(requireContext(),R.color.text_color)))
        DrawableCompat.setTint(
            DrawableCompat.wrap(_binding.roundedDialogButton.background),
            preferences.getInt(BUTTON_BACKGROUND_COLOR, ContextCompat.getColor(requireContext(),R.color.a1_color))
        )
    }

    private fun setTopText(text: String){
        _binding.topTextView.text = text
    }
    private fun setBottomText(text: String?){
        if (text.isNullOrBlank()){
            _binding.bottomTextView.visibility = GONE
        } else
            _binding.bottomTextView.text = text
    }
    private fun setButtonText(text: String){
        _binding.roundedDialogButton.text = text
    }

    fun setButtonListener(listener: ClickListener){
        mListener = listener
    }

    fun show(fragmentManager: FragmentManager){
        super.show(fragmentManager, RoundedBottomSheet::class.java.simpleName)
    }
    interface ClickListener {
        fun onClick()
    }
}

