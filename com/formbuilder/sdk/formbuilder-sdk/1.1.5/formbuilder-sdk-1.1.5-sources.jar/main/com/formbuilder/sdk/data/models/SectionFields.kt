package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class SectionFields(
    @SerializedName("fields")
    val fields: List<Field>
): Parcelable