package com.formbuilder.sdk.presenter.common.views

import android.app.AlertDialog
import android.content.Context
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.TextView
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBConsent

class FBConsentView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBConsent {

    override var key: String = ""
    private val checkBox: CheckBox
    private val link: TextView
    private var errorMessageValue = ""
    private var isFieldRequired = false
    private var consentMessage: CharSequence? = null

    init {
        val view = inflate(context, R.layout.layout_consent, this)
        checkBox = view.findViewById(R.id.layout_consent_checkbox)
        link = view.findViewById(R.id.layout_consent_link)
        //This is necessary to avoid having the same component twice on the screen with the same id.
        checkBox.id = generateViewId()
        link.id = generateViewId()
    }

    override fun getValue(): Boolean {
        return checkBox.isChecked
    }

    override fun setLabel(label: String?) {
        this.checkBox.text = label
    }

    fun setConsentContent(message: CharSequence) {
        consentMessage = message
    }

    fun setLinkText(text: String?) {
        if (!text.isNullOrEmpty()) {
            link.text = text
            link.paintFlags = link.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            link.visibility = View.VISIBLE
            link.setOnClickListener {
                showConsentPopup()
            }
        }
    }

    private fun showConsentPopup() {
        val message = consentMessage ?: return
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        builder.setMessage(message)
        builder.setCancelable(true)
        builder.setNegativeButton(
            context.getString(R.string.ok)
        ) { dialog, _ -> dialog.cancel() }

        val alertDialog: AlertDialog = builder.create()
        alertDialog.show()
        alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
            ?.setTextColor(resources.getColor(R.color.text_color, null))
        alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            ?.setTextColor(resources.getColor(R.color.text_color, null))
    }

    override fun setIsRequired(isRequired: Boolean) {
        isFieldRequired = isRequired
    }

    override fun getIsRequired(): Boolean =
        isFieldRequired

    override fun setErrorMessage(errorMessage: String) {
        errorMessageValue = errorMessage
    }

    override fun getErrorMessage(): String =
        errorMessageValue

    override fun checkFieldData(isRequired: Boolean, value: Boolean, error: String): Boolean {
        if (isRequired && !value) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setMessage(error)
            builder.setCancelable(true)
            builder.setNegativeButton(
                context.getString(R.string.close_btn_label)
            ) { dialog, _ -> dialog.cancel() }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                ?.setTextColor(resources.getColor(R.color.text_color, null))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                ?.setTextColor(resources.getColor(R.color.text_color, null))
            return false
        }

        return true
    }

    override fun isVisible(isVisible: Boolean) {
        visibility = if (isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

}