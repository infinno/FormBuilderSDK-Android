package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.FrameLayout
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBView

class FBHorizontalLineView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBView {

    private val horizontalLineView: View
    override var key: String = ""

    init {
        val view = inflate(context, R.layout.layout_horizontal_view, this)
        horizontalLineView = view.findViewById(R.id.layout_horizontal_view)

        // is necessary to avoid having the same component twice on the screen with the same id.
        horizontalLineView.id = generateViewId()
    }

    override fun isVisible(isVisible: Boolean) {
        horizontalLineView.visibility = if(isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }
}