package com.formbuilder.sdk.utils.managers
import android.os.Handler
import android.util.Log
import com.formbuilder.sdk.utils.helpers.multimedia.VideoEncoder
import okhttp3.internal.notify
import java.io.IOException
import java.io.OutputStream
import java.nio.ByteBuffer
class NetworkOutputStream(private val webSocketManager: WebSocketManager) : OutputStream() {
    enum class NetworkStreamState {
        OPEN,
        CLOSED
    }
    private var buffer = ByteArray(MAX_BUFFER_SIZE)
    private var bufferIndex = 0
    private var sequenceNumber = 0
    private var state = NetworkStreamState.OPEN
    private val taskHandler: Handler = Handler()
    private val repetitiveTaskRunnable: Runnable = Runnable {
        run {
            flush()
            taskHandler.postDelayed(repetitiveTaskRunnable, 34);
        }
    }
    init {
        taskHandler.postDelayed(repetitiveTaskRunnable, 34);
    }
    @Synchronized
    @Throws(IOException::class)
    override fun write(i: Int) {
        if (state == NetworkStreamState.CLOSED) {
            throw IOException("connection closed")
        }
        if (buffer.size >= BUFFER_THRESHOLD) {
            notify()
        }
        if (bufferIndex + 1 >= MAX_BUFFER_SIZE) {
            flush()
        }
        bufferIndex = bufferIndex + 1
        if (bufferIndex < buffer.size){
            buffer[bufferIndex++] = i.toByte()
        }
        else{
            //bufferIndex = 0
            //buffer = ByteArray(MAX_BUFFER_SIZE)
            flush()
            Log.i("FLUSH", "FLUSH CALLED")
        }

    }
    @Synchronized
    @Throws(IOException::class)
    override fun write(b: ByteArray, off: Int, len: Int) {
        if (state == NetworkStreamState.CLOSED) {
            throw IOException("connection closed")
        }
        if (buffer.size >= BUFFER_THRESHOLD) {
            notify()
        }
        if (bufferIndex + len >= MAX_BUFFER_SIZE) {
            flush()
        }
        for (i in off until off + len) {
            bufferIndex = bufferIndex + 1
            if (bufferIndex < buffer.size){
                buffer[bufferIndex] = b[i]
            }
            else{
                //bufferIndex = 0
                //buffer = ByteArray(MAX_BUFFER_SIZE)
                flush()
                Log.i("FLUSH", "FLUSH CALLED")
            }
        }
    }
    override fun flush() {
        var byteBuffer: ByteBuffer
        synchronized(this) {
            byteBuffer = ByteBuffer.allocate(bufferIndex + Integer.SIZE / 8)
            byteBuffer.putInt(sequenceNumber++)
            byteBuffer.put(buffer, 0, bufferIndex)
            bufferIndex = 0
            if (byteBuffer.array().size > 10){
                webSocketManager.sendBinaryMessage(byteBuffer.array())
                Log.i("WEBSOCKET", "sendBinaryMessage " + byteBuffer.array().size)
            }
        }
    }
    @Throws(IOException::class)
    override fun close() {
        super.close()
        state = NetworkStreamState.CLOSED
        taskHandler.removeCallbacks(repetitiveTaskRunnable);
    }
    companion object {
        const val BUFFER_THRESHOLD = VideoEncoder.VIDEO_BITRATE / (8 * 4)
        const val MAX_BUFFER_SIZE = BUFFER_THRESHOLD * 16
    }
}