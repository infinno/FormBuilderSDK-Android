package com.formbuilder.sdk.data.repository

import com.formbuilder.sdk.data.models.*
import com.formbuilder.sdk.data.networking.datasource.FormBuilderDataSource
import com.formbuilder.sdk.data.networking.models.ApiResponse

class FormBuilderRepositoryImpl(
    private val formBuilderDataSource: FormBuilderDataSource
) : FormBuilderRepository {

    override fun startForm(processId: String, callingServiceToken: String?): ApiResponse<Section> {
        val request = if (callingServiceToken!!.isEmpty()) StartFormRequest(processId) else StartFormRequest(processId, callingServiceToken)
        return formBuilderDataSource.startForm(request)
    }

    override fun getSection(submissionId: String, sectionKey: String): ApiResponse<List<SectionFields>> =
        formBuilderDataSource.getSection(submissionId, sectionKey)

    override fun getStep(
        submissionId: String?,
        directionId: String?,
        fromDirectionId: String?,
        fromFlowFieldId: String?,
        stepFields: List<StepField>?,
        activityId: Int?
    ): ApiResponse<Section> {
        val request = StepRequest(submissionId, directionId, fromDirectionId, fromFlowFieldId, stepFields, activityId)

        return formBuilderDataSource.getStep(request)
    }

    override fun getSelfieStatus(submissionId: String, userHash: String): ApiResponse<FBDataStatusResponse> =
        formBuilderDataSource.getSelfieStatus(submissionId, userHash)

    override fun getDocDataStatus(
        submissionId: String,
        userHash: String
    ): ApiResponse<FBDataStatusResponse> =
       formBuilderDataSource.getDocDataStatus(submissionId, userHash)

    override fun getDirection(directionId: String): ApiResponse<Section> {
       return formBuilderDataSource.getDirection(directionId)
    }
}