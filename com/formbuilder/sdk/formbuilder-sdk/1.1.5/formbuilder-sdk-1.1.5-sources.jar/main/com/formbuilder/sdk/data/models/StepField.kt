package com.formbuilder.sdk.data.models

import com.google.gson.annotations.SerializedName

data class StepField(
    @SerializedName("key")
    val key: String,
    @SerializedName("value")
    val value: String,
    @SerializedName("sectionKey")
    val sectionKey: String? = null,
    @SerializedName("sectionIndex")
    val sectionIndex: Int? = null
)