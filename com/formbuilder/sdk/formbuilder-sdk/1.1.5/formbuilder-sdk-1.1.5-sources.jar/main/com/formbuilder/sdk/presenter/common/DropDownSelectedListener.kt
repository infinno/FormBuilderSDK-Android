package com.formbuilder.sdk.presenter.common

interface DropDownSelectedListener {
    fun dropDownSelected(key: String, value: String)
}