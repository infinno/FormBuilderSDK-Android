package com.formbuilder.sdk.presenter.common.views

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ImageButton
import androidx.fragment.app.DialogFragment
import com.formbuilder.sdk.R

class FBWebViewDialogFragment : DialogFragment() {

    companion object {
        private const val ARG_URL = "arg_url"

        fun newInstance(url: String): FBWebViewDialogFragment {
            return FBWebViewDialogFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_URL, url)
                }
            }
        }
    }

    override fun getTheme(): Int = android.R.style.Theme_Light_NoTitleBar

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view = inflater.inflate(R.layout.dialog_webview, container, false)

        val webView = view.findViewById<WebView>(R.id.webview)
        val btnClose = view.findViewById<ImageButton>(R.id.btn_close_webview)

        webView.webViewClient = WebViewClient()
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        arguments?.getString(ARG_URL)?.let { url ->
            val secureUrl = url.replace("http://", "https://")
            webView.loadUrl(secureUrl)
        }

        btnClose.setOnClickListener { dismiss() }

        return view
    }
}
