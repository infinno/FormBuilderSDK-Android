package com.formbuilder.sdk.domain

import com.formbuilder.sdk.data.models.Field
import com.formbuilder.sdk.data.models.SectionFields
import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.repository.FormBuilderRepository
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.helpers.Either

class GetSectionUseCase(
    private val repository: FormBuilderRepository,
    private val apiErrorHandler: ApiErrorHandler
) : BaseUseCase<Either<String, UIHolder>>() {

    private var sectionMap: MutableMap<String, List<Field>> = mutableMapOf()

    companion object {
        const val PARAM_SUBMISSION_ID = "PARAM_SUBMISSION_ID"
        const val PARAM_DIRECTION_ID = "PARAM_SECTION_ID"
    }

    override suspend fun run(withData: Map<String, Any>?): Either<String, UIHolder> {
        val submissionId = withData?.get(PARAM_SUBMISSION_ID) as? String
        val directionId = withData?.get(PARAM_DIRECTION_ID) as? String
        val response = repository.getSection(
            submissionId ?: "",
            directionId ?: ""
        )
        val responseData = response.responseData
        val uiHolder = createUIHolder(section = responseData, sectionMap = sectionMap)

        return if (ApiResponse.checkStatus(response.httpCode) == ApiResponse.STATUS_OK && responseData != null) {
            Either.Right(uiHolder)
        } else {
            Either.Left(apiErrorHandler.getErrorMessage(response))
        }
    }

    private fun createUIHolder(
        section: List<SectionFields>?,
        sectionMap: MutableMap<String, List<Field>>
    ): UIHolder {
        val uiHolder = UIHolder()
        uiHolder.sectionFields = section
        uiHolder.sectionMap = sectionMap
        return uiHolder
    }
}