package com.formbuilder.sdk.utils

import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.view.View
import android.view.Window
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.formbuilder.sdk.R

object EdgeToEdgeHelper {
    // Full: top + bottom (system bars + keyboard)
    fun applyFullInsets(window: Window, rootView: View, configuration: Configuration? = null) {
        applyInsets(window, rootView, configuration, topEnabled = true, bottomEnabled = true)
    }

    // Top-only (status bar / cutout)
    fun applyTopInsets(window: Window, rootView: View, configuration: Configuration? = null) {
        applyInsets(window, rootView, configuration, topEnabled = true, bottomEnabled = false)
    }

    // Bottom-only (nav bar / keyboard)
    fun applyBottomInsets(window: Window, rootView: View, configuration: Configuration? = null) {
        applyInsets(window, rootView, configuration, topEnabled = false, bottomEnabled = true)
    }

    fun applyStatusBarColor(rootView: View, statusBar: View, color: Int){
//        if (Build.VERSION.SDK_INT >= 35) {
//            ViewCompat.setOnApplyWindowInsetsListener(rootView) { v: View, insets: WindowInsetsCompat ->
//                val statusBarHeight = insets.getInsets(
//                    WindowInsetsCompat.Type.statusBars()
//                ).top
//
//                val lp = statusBar.layoutParams
//                lp.height = statusBarHeight
//                statusBar.layoutParams = lp
//                insets
//            }
//            statusBar.setBackgroundColor(color)
//        }
    }

    fun setStatusBarTextDark(window: Window, dark: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller?.isAppearanceLightStatusBars = dark
    }

    fun Window.applyStatusBarForSystemTheme(configuration: Configuration) {
        if (Build.VERSION.SDK_INT < 23) return
        val isNight = (configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        val controller = WindowCompat.getInsetsController(this, decorView)
        controller?.isAppearanceLightStatusBars = !isNight
    }

    // Core logic
    private fun applyInsets(window: Window, rootView: View, configuration: Configuration?, topEnabled: Boolean, bottomEnabled: Boolean) {
        if (Build.VERSION.SDK_INT >= 35) {

            if (configuration != null){
                window.applyStatusBarForSystemTheme(configuration)
            }

            WindowCompat.setDecorFitsSystemWindows(window, false)

            // If you want custom bar colors, uncomment:
             window.statusBarColor = ContextCompat.getColor(rootView.context, R.color.black)
             //window.navigationBarColor = Color.TRANSPARENT

            ViewCompat.setOnApplyWindowInsetsListener(rootView) { view, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                val ime = insets.getInsets(WindowInsetsCompat.Type.ime())

                val bottomInset = maxOf(systemBars.bottom, ime.bottom)

                val topPadding = if (topEnabled) systemBars.top else 0
                val bottomPadding = if (bottomEnabled) bottomInset else 0

                view.setPadding(
                    systemBars.left,
                    topPadding,
                    systemBars.right,
                    bottomPadding
                )

                insets
            }
        }
    }
}