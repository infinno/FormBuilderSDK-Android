package com.formbuilder.sdk.presenter.common.views

import android.app.AlertDialog
import android.content.Context
import android.util.AttributeSet
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBFileSelector


class FBFileSelectorView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0,
    action: OnClickListener
) : FrameLayout(context, attrSet, defStyleAttr), FBFileSelector {

    private val mAction = action
    override var key: String = ""
    private val fileSelectorLabel: TextView
    private val selectedFileLabel: TextView
    private val fileSelectorButton: Button
    private val fileSelectorLayout: LinearLayoutCompat
    private var errorMessageValue = ""

    init {
        val view = inflate(context, R.layout.layout_file_input, this)
        fileSelectorLabel = view.findViewById(R.id.file_selector_label)
        selectedFileLabel = view.findViewById(R.id.selected_file_label)
        fileSelectorButton = view.findViewById(R.id.file_selector_button)
        fileSelectorLayout = view.findViewById(R.id.file_selector_layout)

        //This is necessary to avoid having the same component twice on the screen with the same id.
        fileSelectorButton.id = generateViewId()
        fileSelectorButton.setOnClickListener(mAction)
    }

    override fun setLabelMessage(labelMessage: String) {
        fileSelectorLabel.text = labelMessage
    }

    override fun setButtonMessage(buttonMessage: String) {
        fileSelectorButton.text = buttonMessage
    }

    override fun setSelectedFileName(selectedFileName: String) {
        selectedFileLabel.text = selectedFileName
    }

    override fun setErrorMessage(errorMessage: String) {
        errorMessageValue = errorMessage
    }

    override fun getErrorMessage(): String =
        errorMessageValue

    override fun checkFieldData(regex: String, value: String, error: String): Boolean {
        if (regex.isNotEmpty() && !value.matches(regex.toRegex())) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setMessage(error)
            builder.setCancelable(true)
            builder.setNegativeButton(
                context.getString(R.string.close_btn_label)
            ) { dialog, _ -> dialog.cancel() }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            return false
        }

        return true
    }

    override fun isVisible(isVisible: Boolean) {
        fileSelectorLayout.visibility = if (isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }
}