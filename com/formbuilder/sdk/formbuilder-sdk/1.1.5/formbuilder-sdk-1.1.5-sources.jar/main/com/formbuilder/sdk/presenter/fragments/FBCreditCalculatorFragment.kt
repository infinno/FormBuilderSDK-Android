package com.formbuilder.sdk.presenter.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.Product
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.databinding.FragmentFbCreditCalculatorBinding
import com.formbuilder.sdk.presenter.activities.FormBuilderMainActivity
import com.formbuilder.sdk.presenter.common.SectionSubmittedListener
import com.formbuilder.sdk.presenter.models.UIHolder
import org.koin.androidx.viewmodel.ext.android.viewModel
import kotlin.math.roundToInt


class FBCreditCalculatorFragment : Fragment() {

    private lateinit var mSuitablePeriods: MutableMap<Int, MutableList<Product>>
    private var mProducts: List<Product> = mutableListOf()
    private var installmentCountTextFormat = "%s"
    private val uiHolder by lazy { arguments?.getParcelable<UIHolder>(UI_HOLDER) }
    private var _binding: FragmentFbCreditCalculatorBinding? = null
    private val binding get() = _binding

    private var mCurrentSelectedInstallmentPeriod = -1
    private var mCurrentSelectedAmount = -1.0
    private val mViewModel: FBCreditCalculatorViewModel by viewModel()
    private var seekBarMinInstallmentPeriod = 1
    private var seekBarMaxInstallmentPeriod = 24
    private var minAmount: Double = 100.0
    private var maxAmount: Double = 5000.0
    private var seekBarAmountStep = 100
    private var currentTotalDueAmount = 0.0
    private var currentInstallmentAmount = 0.0
    private var selectedDate: String = ""

    private val onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
            (binding?.fbCreditCalculatorSpinner?.selectedView as TextView).setTextColor(
                requireContext().resources.getColor(R.color.fb_blue, null)
            )  //<----
            //TODO: Add real selected date
            selectedDate = "12-02-2022"
        }

        override fun onNothingSelected(p0: AdapterView<*>?) {
            //No impl needed
        }
    }

    private val seekBarAmountListener = object :
        SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(
            seekBar: SeekBar?,
            progress: Int,
            fromUser: Boolean
        ) {
            mCurrentSelectedAmount = minAmount + (progress * seekBarAmountStep)

            val map = getSuitablePeriods(mCurrentSelectedAmount.roundToInt())
            val sKeys = map.keys.sorted().toList()
            if(sKeys.isEmpty())return
            val min = sKeys.first().toInt()
            val max = sKeys.last().toInt()
            updateInstallmentSeekBarValue(
                min,
                min,
                max
            )

            binding?.fbCreditCalculatorAmountSeekBar?.setSeekBarTitle(
                String.format(
                    getString(R.string.seek_bar_amount_title),
                    mCurrentSelectedAmount
                )
            )

        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {}

        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private val seekBarInstallmentListener = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(
            seekBar: SeekBar?,
            progress: Int,
            fromUser: Boolean
        ) {

            mCurrentSelectedInstallmentPeriod =  seekBarMinInstallmentPeriod + (progress * 1);
            binding?.fbCreditCalculatorInstallmentSeekBar?.setSeekBarTitle(
                String.format(
//                    getString(R.string.seek_bar_installment_title),
                    installmentCountTextFormat,
                    mCurrentSelectedInstallmentPeriod
                )
            )

            val productId = mSuitablePeriods.get(mCurrentSelectedInstallmentPeriod)?.get(0)?.productId?.toInt() ?: -1
            mViewModel.getInstallmentLoanDetails(
                mCurrentSelectedAmount,
                mCurrentSelectedInstallmentPeriod,
                productId
            )
        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launchWhenStarted {
            while (true) {
                val message = mViewModel.observeErrorChannel().receive()
                Toast.makeText(requireContext(), "Error - $message", Toast.LENGTH_LONG)
                    .show()
            }
        }

        mViewModel.observeProduct().observe(this) { products ->
            mProducts = products
            if (products.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "There are no active credit products. Please, contact the admin.",
                    Toast.LENGTH_LONG
                )
                    .show()
                return@observe
            }


            var minSum: Double? = null
            var maxSum: Double? = null

            for (product in products) {
                for (period in product.periods) {
                    if (minSum == null || period.minPrincipal < minSum) {
                        minSum = period.minPrincipal
                    }
                    if (maxSum == null || period.maxPrincipal > maxSum) {
                        maxSum = period.maxPrincipal
                    }
                }
            }

            if (minSum == null || maxSum == null) {
                Toast.makeText(
                    requireContext(),
                    "Looks like the amount couldn't be extracted, please contact the admin.",
                    Toast.LENGTH_LONG
                )
                    .show()
                return@observe
            }
            minAmount = minSum
            maxAmount = maxSum
            mCurrentSelectedAmount = minAmount

            updateAmountSeekBarValue(mCurrentSelectedAmount.roundToInt(), minAmount, maxAmount)


        }

        mViewModel.observeLoading().observe(this) {
            (activity as FormBuilderMainActivity).handleProgressBarVisibility(it)
        }

        mViewModel.observeInstallmentDetails().observe(this) {
            currentInstallmentAmount = it.installmentAmount
            currentTotalDueAmount = it.totalDueAmount
            lifecycleScope.launchWhenStarted {
                binding?.fbCreditCalculatorInstallmentValueTextView?.text = String.format(
                    getString(R.string.seek_bar_amount_title),
                    it.installmentAmount.toString()
                )
                binding?.fbCreditCalculatorAmountToReturnValueTextView?.text = String.format(
                    getString(R.string.seek_bar_amount_title),
                    it.totalDueAmount.toString()
                )
            }
        }


        uiHolder?.section?.settings?.products?.let { mViewModel.getProduct(it,
            uiHolder?.section?.settings?.creditProductType.toString()) }

        setViews()
    }

    fun getSuitablePeriods(sum: Int): Map<Int, List<Product>> {
        val suitablePeriods = mutableMapOf<Int, MutableList<Product>>()

        for (p in mProducts) {
            for (prd in p.periods) {
                if (prd.minPrincipal <= sum && sum <= prd.maxPrincipal) {
                    val period: Int = prd.period

                    if (!suitablePeriods.containsKey(period)) {
                        suitablePeriods[period] = mutableListOf()
                    }
                    suitablePeriods[period]?.add(p)
                }
            }
        }
        mSuitablePeriods = suitablePeriods
        return suitablePeriods
    }

    private fun setViews() {
        lifecycleScope.launchWhenStarted {
            uiHolder?.section?.fields?.forEach {
                when (it.specialType ?: "") {
                    "AMOUNT" -> {}
                    "PERIODS" -> installmentCountTextFormat = "%s ${it.label}"
                    "PERIODS_SINGULAR" -> binding?.fbCreditCalculatorInstallmentTextView?.text =
                        it.label
                    "PERIODS_PLURAL" -> {}
                    "CHOOSE_PRODUCT" -> {}
                    "TOTAL_SUM" -> {}

                    "TOTAL_AMOUNT_SETTING" -> binding?.fbCreditCalculatorAmountToReturnTextView?.text =
                        it.label
                    "INSTALLMENT_AMOUNT" -> {}

                    "PRODUCT_ID" -> {}
                    "INSTALLMENT_DATE" -> {}
                    "FIRST_INSTALLMENT_SETTING" -> binding?.fbCreditCalculatorFirstDateTextView?.text =
                        it.label

                    "DATE_FORMAT" -> {}
                    "SUM_FORMAT" -> {}//TODO
                }
            }
//            uiHolder?.section?.settings?.
            setSpinnerOptions(listOf("12-12-2023", "30-11-2023", "12-01-2024"))
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFbCreditCalculatorBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding?.fbCreditCalculatorContinueButton?.setOnClickListener {
            val answers: MutableList<StepField> = mutableListOf()
            uiHolder?.section?.fields?.forEach {
                when (it.label) {
                    "Amount" -> {
                        answers.add(StepField(it.key ?: "", mCurrentSelectedAmount.toString()))
                    }

                    "Periods" -> {
                           answers.add(
                               StepField(
                                   it.key ?: "",
                                   mCurrentSelectedInstallmentPeriod.toString()
                               )
                           )
                    }

                    "Total due amount" -> {
                        answers.add(StepField(it.key ?: "", currentTotalDueAmount.toString()))
                    }

                    "Installment amount" -> {
                        answers.add(StepField(it.key ?: "", currentInstallmentAmount.toString()))
                    }

                    "Product ID" -> {
                        uiHolder?.section?.settings?.products?.get(0)?.itemValue?.let { it1 ->
                            answers.add(
                                StepField(
                                    it.key ?: "",
                                    it1
                                )
                            )
                        }

                    }

                    "First installment date" -> {
                        answers.add(StepField(it.key ?: "", selectedDate))
                    }
                }
            }
            (context as SectionSubmittedListener).onSectionSubmittedWithValidAnswers(
                uiHolder?.section?.submissionId ?: "",
                uiHolder?.section?.settings?.calculatorSubmitDirectionStepId ?: "",
                uiHolder?.section?.settings?.calculatorSubmitDirectionStepId ?: "",
                "",
                answers = answers
            )
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun setSpinnerOptions(dates: List<String>) {
        val optionsList: MutableList<String> = mutableListOf()
        dates.forEach { optionsList.add(it) }

        val adapter: ArrayAdapter<String> = ArrayAdapter<String>(
            requireContext(),
            android.R.layout.simple_spinner_item, optionsList
        )

        binding?.fbCreditCalculatorSpinner?.adapter = adapter
        binding?.fbCreditCalculatorSpinner?.onItemSelectedListener = onItemSelectedListener
    }

    private fun updateInstallmentSeekBarValue(
        currentSelectedPeriod: Int,
        minInstallment: Int,
        maxInstallment: Int
    ) {
        binding?.fbCreditCalculatorInstallmentSeekBar?.let {
            it.setSeekBarTitle(
                String.format(
//                    getString(R.string.seek_bar_installment_title),
                    installmentCountTextFormat,
                    currentSelectedPeriod
                )
            )
            it.setSeekBarValues(
                minInstallment,
                maxInstallment,
                1
            )

            it.setSeekBarProgress(
                currentSelectedPeriod,
                minInstallment,
                1
            )
            it.seekBarView.setOnSeekBarChangeListener(seekBarInstallmentListener)

            val productId = mSuitablePeriods.get(minInstallment)?.get(0)?.productId?.toInt() ?: -1
            mViewModel.getInstallmentLoanDetails(minAmount, minInstallment, productId)
        }
    }

    private fun updateAmountSeekBarValue(
        currentSelectedAmount: Int,
        minAmount: Double,
        maxAmount: Double
    ) {
        binding?.fbCreditCalculatorAmountSeekBar?.let {
            it.setSeekBarTitle(
                String.format(
                    getString(R.string.seek_bar_amount_title),
                    currentSelectedAmount
                )
            )

            it.setSeekBarValues(
                minAmount.roundToInt(),
                maxAmount.roundToInt(),
                seekBarAmountStep
            )
            it.setSeekBarProgress(currentSelectedAmount, minAmount.roundToInt(), seekBarAmountStep)
            it.seekBarView.setOnSeekBarChangeListener(seekBarAmountListener)

            val map = getSuitablePeriods(currentSelectedAmount)
            val sKeys = map.keys.sorted().toList()

            val min = sKeys.first().toInt()
            val max = sKeys.last().toInt()



            seekBarMinInstallmentPeriod = min
            seekBarMaxInstallmentPeriod = max
            updateInstallmentSeekBarValue(
                min,
                min,
                max
            )
        }
    }

    companion object {
        const val UI_HOLDER = "UI_HOLDER"

        fun newInstance(uiHolder: UIHolder?): FBCreditCalculatorFragment {
            val fragment = FBCreditCalculatorFragment()
            val bundle = Bundle().apply {
                putParcelable(UI_HOLDER, uiHolder)
            }
            fragment.arguments = bundle
            return fragment
        }
    }
}