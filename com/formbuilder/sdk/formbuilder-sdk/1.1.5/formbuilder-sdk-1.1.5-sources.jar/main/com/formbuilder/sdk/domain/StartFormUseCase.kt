package com.formbuilder.sdk.domain

import com.formbuilder.sdk.data.models.Field
import com.formbuilder.sdk.data.models.Section
import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.repository.FormBuilderRepository
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.helpers.Either

class StartFormUseCase(
    private val repository: FormBuilderRepository,
    private val apiErrorHandler: ApiErrorHandler
) : BaseUseCase<Either<String, UIHolder>>() {

    private var sectionMap: MutableMap<String, List<Field>> = mutableMapOf()

    companion object {
        const val PARAM_PROCESS_ID = "PARAM_PROCESS_ID"
        const val PARAM_CALLING_SERVICE_TOKEN = "PARAM_CALLING_SERVICE_TOKEN"
    }

    override suspend fun run(withData: Map<String, Any>?): Either<String, UIHolder> {
        val processId = withData?.get(PARAM_PROCESS_ID) as String
        var callingServiceToken: String? = withData.get(PARAM_CALLING_SERVICE_TOKEN) as String
        val response = repository.startForm(processId, callingServiceToken)
        val responseData = response.responseData

//        var sectionResponse: ApiResponse<Section>? = null
//        responseData?.fields?.forEach {
//            if (it.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(responseData.submissionId ?: "", it.key ?: "")
//                sectionMap[it.key ?: ""] = sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { sectionField ->
//            if (sectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        sectionField.key ?: ""
//                    )
//                sectionMap[sectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { secondSectionField ->
//            if (secondSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        secondSectionField.key ?: ""
//                    )
//                sectionMap[secondSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { thirdSectionField ->
//            if (thirdSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        thirdSectionField.key ?: ""
//                    )
//                sectionMap[thirdSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { fourthSectionField ->
//            if (fourthSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        fourthSectionField.key ?: ""
//                    )
//                sectionMap[fourthSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { fifthSectionField ->
//            if (fifthSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        fifthSectionField.key ?: ""
//                    )
//                sectionMap[fifthSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields
//                        ?: listOf()
//            }
//        }

        val uiHolder = createUIHolder(section = responseData, sectionMap = sectionMap)

        return if (ApiResponse.checkStatus(response.httpCode) == ApiResponse.STATUS_OK && responseData != null) {
            Either.Right(uiHolder)
        } else {
            Either.Left(apiErrorHandler.getErrorMessage(response))
        }
    }

    private fun createUIHolder(
        section: Section?,
        sectionMap: MutableMap<String, List<Field>>
    ): UIHolder {
        val uiHolder = UIHolder()
        uiHolder.section = section
        uiHolder.sectionMap = sectionMap
        return uiHolder
    }

}