package com.formbuilder.sdk.presenter.common

interface FBFieldText: FBView {
    fun setValue(value: String?)
    fun setBold(isBold: Boolean?)
}