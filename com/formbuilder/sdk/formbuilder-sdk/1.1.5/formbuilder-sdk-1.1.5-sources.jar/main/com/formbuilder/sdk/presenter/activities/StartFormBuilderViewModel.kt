package com.formbuilder.sdk.presenter.activities

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.domain.GetDirectionUseCase
import com.formbuilder.sdk.domain.GetStepUseCase
import com.formbuilder.sdk.domain.StartFormUseCase
import com.formbuilder.sdk.presenter.base.BaseViewModel
import com.formbuilder.sdk.presenter.models.UIHolder
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class StartFormBuilderViewModel(
    private val getStepUseCase: GetStepUseCase,
    private val startFormUseCase: StartFormUseCase,
    private val getDirectionUseCase: GetDirectionUseCase
) : BaseViewModel() {
    private var mStartFormJob: Job? = null
    private var getStepJob: Job? = null
    private var getDirectionJob: Job? = null

    private val mFormBuilderView = MutableLiveData<UIHolder>()
    private val mGetStepSectionView = MutableLiveData<UIHolder>()
    private val mGetDirectionView = MutableLiveData<UIHolder>()
    fun observeGetStepSectionView() =
        mGetStepSectionView as LiveData<UIHolder>

    fun observeFormBuilderView() =
        mFormBuilderView as LiveData<UIHolder>

    fun observeGetDirectionView() =
        mGetDirectionView as LiveData<UIHolder>

    fun startForm(processId: String, callingServiceToken: String) {
        if (isActiveJob(mStartFormJob)) return
        mLoadingIndicatorVisible.value = true
        mStartFormJob = viewModelScope.launch {

            startFormUseCase.executeAsync(
                mapOf(
                    StartFormUseCase.PARAM_PROCESS_ID to processId,
                    StartFormUseCase.PARAM_CALLING_SERVICE_TOKEN to callingServiceToken)
            )
                .onLeft { error ->
                    launch {
                        mLoadingIndicatorVisible.value = false
                        mErrorChannel.send(error)
                    }
                }
                .onRight { result ->
                    mLoadingIndicatorVisible.value = false
                    mFormBuilderView.value = result
                }
        }
    }

    fun getStep(
        submissionId: String, directionId: String,
        fromDirectionId: String = "", fromFlowFieldId: String = "",
        stepFields: List<StepField>, activityId: Int = 0
    ) {
        if (isActiveJob(getStepJob)) return
        mLoadingIndicatorVisible.value = true
        getStepJob = viewModelScope.launch {

            getStepUseCase.executeAsync(
                mapOf(
                    GetStepUseCase.PARAM_SUBMISSION_ID to submissionId,
                    GetStepUseCase.PARAM_DIRECTION_ID to directionId,
                    GetStepUseCase.PARAM_FROM_DIRECTION_ID to fromDirectionId,
                    GetStepUseCase.PARAM_FROM_FLOW_FIELD_ID to fromFlowFieldId,
                    GetStepUseCase.PARAM_STEP_FIELDS to stepFields,
                    GetStepUseCase.PARAM_ACTIVITY_ID to activityId
                )
            ).onLeft { error ->
                launch {
                    mErrorChannel.send(error)
                    mLoadingIndicatorVisible.value = false
                }
            }.onRight { result ->
                mGetStepSectionView.value = result
                mLoadingIndicatorVisible.value = false
            }
        }
    }

    fun getDirection(directionId: String) {
        if (isActiveJob(getDirectionJob)) return
        mLoadingIndicatorVisible.value = true
        getDirectionJob = viewModelScope.launch {

            getDirectionUseCase.executeAsync(
                mapOf(GetDirectionUseCase.PARAM_DIRECTION_ID to directionId))
                .onLeft { error ->
                    launch {
                        mLoadingIndicatorVisible.value = false
                        mErrorChannel.send(error)
                    }
                }
                .onRight { result ->
                    mLoadingIndicatorVisible.value = false
                    mGetDirectionView.value = result
                }
        }
    }
}