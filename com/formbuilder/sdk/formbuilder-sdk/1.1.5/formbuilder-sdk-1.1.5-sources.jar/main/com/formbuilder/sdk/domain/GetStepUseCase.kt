package com.formbuilder.sdk.domain

import com.formbuilder.sdk.data.models.Field
import com.formbuilder.sdk.data.models.FieldType
import com.formbuilder.sdk.data.models.Section
import com.formbuilder.sdk.data.models.StepField
import com.formbuilder.sdk.data.networking.client.ApiErrorHandler
import com.formbuilder.sdk.data.networking.models.ApiResponse
import com.formbuilder.sdk.data.repository.FormBuilderRepository
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.helpers.Either

class GetStepUseCase(
    private val repository: FormBuilderRepository,
    private val apiErrorHandler: ApiErrorHandler
) : BaseUseCase<Either<String, UIHolder>>() {

    private var sectionMap: MutableMap<String, List<Field>> = mutableMapOf()

    companion object {
        const val PARAM_SUBMISSION_ID = "PARAM_SUBMISSION_ID"
        const val PARAM_DIRECTION_ID = "PARAM_SECTION_ID"
        const val PARAM_FROM_DIRECTION_ID = "PARAM_FROM_DIRECTION_ID"
        const val PARAM_FROM_FLOW_FIELD_ID = "PARAM_FROM_FLOW_FIELD_ID"
        const val PARAM_STEP_FIELDS = "PARAM_STEP_FIELDS"
        const val PARAM_ACTIVITY_ID = "PARAM_ACTIVITY_ID"
    }

    override suspend fun run(withData: Map<String, Any>?): Either<String, UIHolder> {
        val submissionId = withData?.get(PARAM_SUBMISSION_ID) as? String
        val directionId = withData?.get(PARAM_DIRECTION_ID) as? String
        val fromDirectionId = withData?.get(PARAM_FROM_DIRECTION_ID) as? String
        val fromFlowFieldId = withData?.get(PARAM_FROM_FLOW_FIELD_ID) as? String
        val stepFields: List<StepField>? = withData?.get(PARAM_STEP_FIELDS) as? List<StepField>
        val activityId = withData?.get(PARAM_ACTIVITY_ID) as? Int
        val response = repository.getStep(
            submissionId,
            directionId,
            fromDirectionId,
            fromFlowFieldId,
            stepFields,
            activityId
        )
        val responseData = response.responseData
        var sectionResponse: ApiResponse<Section>? = null
//        responseData?.fields?.forEach {
//            if (it.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(responseData.submissionId ?: "", it.key ?: "")
//                sectionMap[it.key ?: ""] = sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { sectionField ->
//            if (sectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        sectionField.key ?: ""
//                    )
//                sectionMap[sectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { secondSectionField ->
//            if (secondSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        secondSectionField.key ?: ""
//                    )
//                sectionMap[secondSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { thirdSectionField ->
//            if (thirdSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        thirdSectionField.key ?: ""
//                    )
//                sectionMap[thirdSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { fourthSectionField ->
//            if (fourthSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        fourthSectionField.key ?: ""
//                    )
//                sectionMap[fourthSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields ?: listOf()
//            }
//        }
//        sectionResponse?.responseData?.fields?.forEach { fifthSectionField ->
//            if (fifthSectionField.type == FieldType.SECTION.name) {
//                sectionResponse =
//                    repository.getSection(
//                        responseData?.submissionId ?: "",
//                        fifthSectionField.key ?: ""
//                    )
//                sectionMap[fifthSectionField.key ?: ""] =
//                    sectionResponse?.responseData?.fields
//                        ?: listOf()
//            }
//        }
        val uiHolder = createUIHolder(section = responseData, sectionMap = sectionMap)

        return if (ApiResponse.checkStatus(response.httpCode) == ApiResponse.STATUS_OK && responseData != null) {
            Either.Right(uiHolder)
        } else {
            Either.Left(apiErrorHandler.getErrorMessage(response))
        }
    }

    private fun createUIHolder(
        section: Section?,
        sectionMap: MutableMap<String, List<Field>>
    ): UIHolder {
        val uiHolder = UIHolder()
        uiHolder.section = section
        uiHolder.sectionMap = sectionMap
        return uiHolder
    }
}