package com.formbuilder.sdk.presenter.common.views

import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.util.AttributeSet
import android.view.Gravity
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBAppearance.Companion.APPEARANCE_COLORS
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_BACKGROUND_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_FONT
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_TEXT_COLOR
import com.formbuilder.sdk.data.models.FBAppearance.Companion.INPUT_TEXT_SIZE
import com.formbuilder.sdk.data.models.FieldType
import com.formbuilder.sdk.presenter.common.FBFieldInput
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class FBTextInputView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBFieldInput {

    override var key: String = ""
    private val textInput: TextInputEditText
    private val textInputLayout: TextInputLayout
    private var errorMessageValue = ""
    private var regexValue = ""

    init {
        val view = inflate(context, R.layout.layout_text_input, this)
        val preferences = context.getSharedPreferences(APPEARANCE_COLORS, Context.MODE_PRIVATE)
        textInput = view.findViewById(R.id.text_input_edit_text)
        textInputLayout = view.findViewById(R.id.activity_form_builder_text_input_layout)
        textInput.setTextColor(preferences.getInt(INPUT_TEXT_COLOR, ContextCompat.getColor(context,R.color.text_color)))
        textInput.setBackgroundColor(preferences.getInt(INPUT_BACKGROUND_COLOR, ContextCompat.getColor(context,R.color.transparent)))
        textInput.apply {
            val font = preferences.getInt(INPUT_FONT, 0)
            if (font != 0){
                val tf = font.let { ResourcesCompat.getFont(context, it) }
                if (tf != null) {
                    typeface = tf
                }
            }

            if (preferences.getInt(INPUT_TEXT_SIZE, 0) != 0){
                textSize = preferences.getInt(INPUT_TEXT_SIZE, 18).toFloat()
            }
        }

        //This is necessary to avoid having the same component twice on the screen with the same id.
        textInput.id = generateViewId()
    }

    override fun getValue(): String {
        return textInput.text.toString()
    }

    override fun setHint(hint: String?) {
        textInputLayout.hint = hint
    }

    override fun setInputType(inputType: String) {
        when (inputType) {
            FieldType.AREA.name -> {
                textInput.inputType = InputType.TYPE_TEXT_FLAG_MULTI_LINE
                textInput.minLines = 6
                textInput.gravity = Gravity.TOP
            }
        }
    }

    override fun setRegex(regex: String) {
        regexValue = regex
    }

    override fun getRegex(): String =
        regexValue

    override fun setErrorMessage(errorMessage: String) {
        errorMessageValue = errorMessage
    }

    override fun getErrorMessage(): String =
        errorMessageValue

    override fun checkFieldData(regex: String, value: String, error: String): Boolean {
        if (regex.isNotEmpty() && !value.matches(regex.toRegex())) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setMessage(error)
            builder.setCancelable(true)
            builder.setNegativeButton(
                context.getString(R.string.close_btn_label)
            ) { dialog, _ -> dialog.cancel() }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            return false
        }

        return true
    }

    override fun isVisible(isVisible: Boolean) {
        textInputLayout.visibility = if (isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

    override fun getVisibility(): Int {
        return textInputLayout.visibility
    }
}