package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.SeekBar
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.formbuilder.sdk.R
import com.formbuilder.sdk.databinding.FbSeekBarLayoutBinding

class FBSeekBar : ConstraintLayout {

    private var binding: FbSeekBarLayoutBinding? = null

    private var titleValue: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private var minValueText: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private var maxValueText: String? = null
        set(value) {
            field = value
            invalidate()
        }

    private var minValue: Int = -1
        set(value) {
            field = value
            invalidate()
        }

    private var maxValue: Int = -1
        set(value) {
            field = value
            invalidate()
        }

    private var step: Int = -1
        set(value) {
            field = value
            invalidate()
        }

    private lateinit var seekBarTitleTextView: TextView
    private lateinit var seekBarCurrentValueTextView: TextView
    lateinit var seekBarView: SeekBar

    constructor(context: Context) : super(context) {
        initView()
    }

    constructor(context: Context, attr: AttributeSet) : super(context, attr) {
        setAttributes(attr)
        initView()
    }

    constructor(context: Context, attr: AttributeSet, def: Int) : super(context, attr, def) {
        setAttributes(attr)
        initView()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        initLayout()
    }

    private fun initLayout() {
        setSeekBarTitle(titleValue)
        setSeekBarValues(minValue, maxValue, step)
    }

    private fun setAttributes(attrs: AttributeSet) {

        val typedArray = context.theme.obtainStyledAttributes(
            attrs, R.styleable.FBSeekBar, 0, 0
        )

        try {
            titleValue = typedArray.getString(R.styleable.FBSeekBar_seek_bar_title)
            minValue = typedArray.getInt(R.styleable.FBSeekBar_seek_bar_min_value, 0)
            maxValue = typedArray.getInt(R.styleable.FBSeekBar_seek_bar_max_value, 100)
            step = typedArray.getInt(R.styleable.FBSeekBar_seek_bar_step, 1)
        } finally {
            typedArray.recycle()
        }
    }

    private fun initView() {
        binding = FbSeekBarLayoutBinding.inflate(LayoutInflater.from(context), this, true)
        binding?.let {
            seekBarTitleTextView = it.fbSeekBarTitleTextView
            seekBarView = it.fbSeekBarView
        }
    }

    fun setSeekBarValues(minValue: Int, maxValue: Int, step: Int) {
        seekBarView.max = (maxValue - minValue) / step
    }

    fun setSeekBarValuesWithCalculatedStep(minValue: Int, maxValue: Int, step: Int) {
        seekBarView.max = ((maxValue - minValue) / step) - 1
    }

    fun setSeekBarTitle(title: String?) {
        seekBarTitleTextView.text = title
    }

    fun resetSeekBar() {
        seekBarView.progress = 0
    }

    fun setSeekBarProgress(currentValue: Int, minValue: Int, step: Int) {
        seekBarView.progress = (currentValue - minValue) / step
    }
}