package com.formbuilder.sdk.data.networking.client

import android.content.res.Resources
import android.os.Build
import androidx.core.os.ConfigurationCompat
import okhttp3.Interceptor
import okhttp3.Response

class HeaderInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response = chain.run {
        proceed(
            request()
                .newBuilder()
                .addHeader("Accept-Language",
                    ConfigurationCompat.getLocales(Resources.getSystem().configuration)
                        .get(0)?.language ?: "bg"
                )
                .addHeader("User-Agent", Build.MANUFACTURER + "/Model: " + Build.MODEL + "/Android version: " + Build.VERSION.SDK_INT)
                .build()
        )
    }
}