package com.formbuilder.sdk.presenter.common.views

import android.content.Context
import android.content.res.Resources
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.AttributeSet
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import com.formbuilder.sdk.R
import com.formbuilder.sdk.presenter.common.FBImage
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class FBImageView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBImage {
    override var key: String = ""
    private val image: ImageView

    init {
        val view = inflate(context, R.layout.layout_image, this)
        image = view.findViewById(R.id.layout_image_view)
        image.elevation = 32f
        // is necessary to avoid having the same component twice on the screen with the same id.
        image.id = generateViewId()
    }


    override fun setImage(url: String?) {
        if (!url.isNullOrEmpty()){
            val executor = Executors.newSingleThreadExecutor()
            executor.execute {
                try {
                    val connection = URL(url).openConnection() as HttpURLConnection
                    connection.doInput = true
                    connection.connect()
                    val inputStream = connection.inputStream
                    val bitmap = BitmapFactory.decodeStream(inputStream)

                    // Update ImageView on the main thread
                    Handler(Looper.getMainLooper()).post {
                        image.setImageBitmap(bitmap)
                    }

                    inputStream.close()
                    connection.disconnect()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun setWidth(widthPercent: Int?) {
        if (widthPercent != null) {
            if (widthPercent > 0  && widthPercent <= 100){
                val screenWidth = Resources.getSystem().displayMetrics.widthPixels
                val targetWidth = (screenWidth * (widthPercent/100f)).toInt()

                Handler(Looper.getMainLooper()).post {
                    val params = image.layoutParams
                    params.width = targetWidth
                    params.height = ViewGroup.LayoutParams.WRAP_CONTENT
                    image.layoutParams = params
                    image.scaleType = ImageView.ScaleType.FIT_CENTER
                    image.adjustViewBounds = true
                }
            }
        }
    }

    override fun setAlignment(alignment: String?) {
        if (!alignment.isNullOrEmpty()){
            val params = LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )

            val viewAlignment = when (alignment?.lowercase()){
                "left"      -> Gravity.START
                "center"    -> Gravity.CENTER_HORIZONTAL
                "right"     -> Gravity.END
                else -> Gravity.CENTER_HORIZONTAL
            }
            params.gravity = viewAlignment
            image.layoutParams = params
            image.scaleType = ImageView.ScaleType.FIT_CENTER
            image.adjustViewBounds = true
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }

    override fun isVisible(isVisible: Boolean) {
        image.visibility = if(isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }
}