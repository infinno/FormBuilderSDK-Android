package com.formbuilder.sdk.presenter.common.views

import android.app.AlertDialog
import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.FrameLayout
import android.widget.Spinner
import com.formbuilder.sdk.R
import com.formbuilder.sdk.data.models.FBOption
import com.formbuilder.sdk.presenter.common.DropDownSelectedListener
import com.formbuilder.sdk.presenter.common.FBSpinner


class FBSpinnerView @JvmOverloads constructor(
    context: Context,
    attrSet: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrSet, defStyleAttr), FBSpinner {

    override var key: String = ""
    private var spinnerValue = ""
    private var errorMessageValue = ""
    private var isFieldRequired = false
    private var fbOptionsList: List<FBOption>? = null
    private var listener: DropDownSelectedListener? = null
    private val spinner: Spinner
    private val onItemSelectedListener = object : OnItemSelectedListener {
        override fun onItemSelected(p0: AdapterView<*>?, p1: View?, position: Int, p3: Long) {
            if(position == 0) {
                listener?.dropDownSelected(key, "")
            }

            if (position != 0) {
                spinnerValue = fbOptionsList?.get(position - 1)?.value ?: ""
                listener?.dropDownSelected(key, spinnerValue)
            }
        }
        override fun onNothingSelected(p0: AdapterView<*>?) {
            //No impl needed
        }
    }

    init {
        val view = inflate(context, R.layout.layout_spinner, this)
        spinner = view.findViewById(R.id.layout_spinner)

        //This is necessary to avoid having the same component twice on the screen with the same id.
        spinner.id = generateViewId()
    }

    override fun getValue(): String {
        return spinnerValue
    }

    override fun setSpinnerOptions(label: String, options: List<FBOption>?) {
        fbOptionsList = options
        val optionsList: MutableList<String> = mutableListOf(label)
        options?.forEach { optionsList.add(it.label) }

        val adapter: ArrayAdapter<String> = ArrayAdapter<String>(
            context,
            android.R.layout.simple_spinner_item, optionsList
        )

        spinner.adapter = adapter
        spinner.onItemSelectedListener = onItemSelectedListener
    }

    override fun setIsRequired(isRequired: Boolean) {
        isFieldRequired = isRequired
    }

    override fun getIsRequired(): Boolean =
        isFieldRequired

    override fun setErrorMessage(errorMessage: String) {
        errorMessageValue = errorMessage
    }

    override fun getErrorMessage(): String =
        errorMessageValue

    override fun checkFieldData(isRequired: Boolean, value: String, error: String): Boolean {
        if (isRequired && value.isEmpty()) {
            val builder: AlertDialog.Builder = AlertDialog.Builder(context)
            builder.setMessage(error)
            builder.setCancelable(true)
            builder.setNegativeButton(
                context.getString(R.string.close_btn_label)
            ) { dialog, _ -> dialog.cancel() }

            val alertDialog: AlertDialog = builder.create()
            alertDialog.show()
            alertDialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            alertDialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                .setTextColor(resources.getColor(R.color.text_color, null))
            return false
        }

        return true
    }

    override fun setDropDownSelectedListener(dropDownSelectedListener: DropDownSelectedListener) {
        listener = dropDownSelectedListener
    }

    override fun isVisible(isVisible: Boolean) {
        spinner.visibility = if(isVisible) {
            VISIBLE
        } else {
            GONE
        }
    }

    override fun setTag(sectionKey: String) {
        tag = sectionKey
    }
}