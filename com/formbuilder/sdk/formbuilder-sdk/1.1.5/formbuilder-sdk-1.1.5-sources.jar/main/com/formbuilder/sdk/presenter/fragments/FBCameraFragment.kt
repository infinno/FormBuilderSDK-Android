package com.formbuilder.sdk.presenter.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
//import com.formbuilder.sdk.data.networking.AppSdpObserver
//import com.formbuilder.sdk.data.networking.PeerConnectionObserver
//import com.formbuilder.sdk.data.networking.client.RTCClient
import com.formbuilder.sdk.databinding.FragmentFbCameraBinding
import com.formbuilder.sdk.presenter.activities.FormBuilderMainActivity
import com.formbuilder.sdk.presenter.models.UIHolder
import com.formbuilder.sdk.utils.Constants
import com.formbuilder.sdk.utils.Constants.MEDIA
import com.formbuilder.sdk.utils.Constants.REQUEST_MEDIA
import com.formbuilder.sdk.utils.Constants.SOCKET_ALREADY_CONNECTED
import com.formbuilder.sdk.utils.Constants.SOCKET_CONNECTED
import com.formbuilder.sdk.utils.Constants.TYPE_VIDEO
import com.formbuilder.sdk.utils.managers.MessageListener
import com.formbuilder.sdk.utils.managers.PermissionsManager
import com.formbuilder.sdk.utils.managers.WebSocketManager
import com.formbuilder.sdk.utils.managers.WebSocketManager.Companion.TAG
import kotlinx.coroutines.delay
import org.json.JSONObject
import org.koin.android.ext.android.inject
import org.koin.androidx.viewmodel.ext.android.viewModel
import org.koin.core.parameter.parametersOf
//import org.webrtc.IceCandidate
//import org.webrtc.SessionDescription

class FBCameraFragment : Fragment(), MessageListener {

    private val uiHolder by lazy { arguments?.getParcelable<UIHolder>(UI_HOLDER) }
    private var lastStatus: Int = -1
    private val permissionsManager: PermissionsManager by inject()
//    private var rtcClient: RTCClient? = null
    private val webSocketManager: WebSocketManager by inject {
        parametersOf(
            uiHolder?.section?.settings?.streamUrl,
            uiHolder?.section?.settings?.userHash
        )
    }
    private var _binding: FragmentFbCameraBinding? = null
    private val binding get() = _binding
    private lateinit var mRequestPermission: ActivityResultLauncher<String>
//    private val sdpObserver = object : AppSdpObserver() {
//        override fun onCreateSuccess(p0: SessionDescription?) {
//            super.onCreateSuccess(p0)
//            webSocketManager.sendHandshakeSdp(SessionDescription(p0?.type, p0?.description))
//        }
//    }
    private val mViewModel: FBCameraViewModel by viewModel()

//    private var answerSessionDescription: SessionDescription? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding?.selfieSwitchCamera?.setOnClickListener {
            //rtcClient?.switchCamera()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mRequestPermission =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) { permission ->
                if (isCameraPermissionGranted()) {
                    onCameraPermissionGranted()
                } else {
                    onCameraPermissionDenied()
                }
            }

        requestCameraPermission()

        lifecycleScope.launchWhenStarted {
            while (true) {
                val message = mViewModel.observeErrorChannel().receive()
                Toast.makeText(requireContext(), "Error - $message", Toast.LENGTH_LONG)
                    .show()
            }
        }

        mViewModel.observeGetStepSectionView().observe(this) {
            webSocketManager.close()
            (activity as FormBuilderMainActivity).navigateForward(it)
            mViewModel.cancelCoroutines()
        }

        mViewModel.observeSelfieStatus().observe(this) {
            if (lastStatus == it) return@observe
            when (it) {
                0 -> {
                    Log.d(TAG, "Selfie status $it")
                    lastStatus = it
                }
                1 -> {
                    webSocketManager.close()
                    //rtcClient?.stop()
                    mViewModel.getStep(
                        uiHolder?.section?.submissionId ?: "",
                        uiHolder?.section?.settings?.noFaceDirectionStepId ?: "",
                        uiHolder?.section?.settings?.noFaceDirectionStepId ?: "",
                        stepFields = emptyList()
                    )
                    lastStatus = it
                }
                2 -> {
                    webSocketManager.close()
                    //rtcClient?.stop()
                    mViewModel.getStep(
                        uiHolder?.section?.submissionId ?: "",
                        uiHolder?.section?.directionId ?: "",
                        uiHolder?.section?.directionId ?: "",
                        stepFields = emptyList()
                    )
                    lastStatus = it
                }
                3 -> {
                    Toast.makeText(requireContext(), "Analyzing...", Toast.LENGTH_LONG).show()
                    lastStatus = it
                }
                4 -> {
                    webSocketManager.close()
                    //rtcClient?.stop()
                    mViewModel.getStep(
                        uiHolder?.section?.submissionId ?: "",
                        uiHolder?.section?.settings?.livenessFailDirectionStepId ?: "",
                        uiHolder?.section?.settings?.livenessFailDirectionStepId ?: "",
                        stepFields = emptyList()
                    )
                    lastStatus = it
                }
                5 -> {
                    webSocketManager.close()
                    //rtcClient?.stop()
                    mViewModel.getStep(
                        uiHolder?.section?.submissionId ?: "",
                        uiHolder?.section?.directionId ?: "",
                        uiHolder?.section?.directionId ?: "",
                        stepFields = emptyList()
                    )
                    lastStatus = it
                }
                6 -> {
                    showAlertDialog("Smile please!", "OK")
                    lastStatus = it
                }
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentFbCameraBinding.inflate(inflater, container, false)
        return binding?.root
    }

    private fun onCameraPermissionGranted() {
        webSocketManager.setMessageListener(this)
        webSocketManager.connect()
    }

//    private fun startCamera() {
//        rtcClient = RTCClient(requireContext(), object : PeerConnectionObserver() {
//            override fun onIceCandidate(p0: IceCandidate?) {
//                super.onIceCandidate(p0)
//                val iceCandidate = IceCandidate(
//                    p0?.sdpMid, p0?.sdpMLineIndex ?: 0, p0?.sdp
//                )
//                webSocketManager.sendMessage(
//                    iceCandidate
//                )
//                rtcClient?.addIceCandidate(iceCandidate)
//            }
//        })
//        val surfaceViewRenderer = binding?.fbCameraLocalView
//        surfaceViewRenderer?.setMirror(true)
//        rtcClient?.initSurfaceView(surfaceViewRenderer)
////        rtcClient?.startLocalVideoCapture(
////            binding?.fbCameraLocalView,
////            requireActivity().resources.displayMetrics.widthPixels,
////            requireActivity().resources.displayMetrics.heightPixels
////        )
//        rtcClient?.call(sdpObserver)
//    }

    override fun onConnectSuccess() {
        webSocketManager.sendMessage(Constants.SOCKET_COMMAND_JOIN)
    }

    override fun onConnectFailed() {
        Log.d(TAG, "Connect failed")
    }

    override fun onClose(code: Int) {

    }

    override fun onMessage(text: String) {
        Log.d(TAG, text)
        val json = JSONObject(text)

        when (json.optString(Constants.SOCKET_COMMAND_CMD)) {
            Constants.SOCKET_COMMAND_HB -> {
                webSocketManager.sendMessage(Constants.SOCKET_COMMAND_HB)
            }
            Constants.SOCKET_PEER -> {
                webSocketManager.sendMessage(Constants.SOCKET_GOT_PEER)
                webSocketManager.sendPeerAnswer()
            }
            SOCKET_ALREADY_CONNECTED -> {
                webSocketManager.sendPeerAnswer()
            }
            SOCKET_CONNECTED -> {
                lifecycleScope.launchWhenStarted {
                    while (true) {
                        delay(1000)
                        mViewModel.getSelfieStatus(
                            uiHolder?.section?.submissionId ?: "",
                            uiHolder?.section?.settings?.userHash ?: ""
                        )
                    }
                }
            }
            REQUEST_MEDIA -> {
                lifecycleScope.launchWhenResumed {
                    if (json.optString(MEDIA) == TYPE_VIDEO) {
                        //startCamera()
                    }
                }
            }
        }
    }

//    override fun onIceCandidateReceived(iceCandidate: IceCandidate) {
//        rtcClient?.addIceCandidate(iceCandidate)
//    }
//
//    override fun onAnswerReceived(description: SessionDescription) {
//        rtcClient?.onRemoteSessionReceived(description)
//        answerSessionDescription = description
//    }

    private fun onCameraPermissionDenied() {
        Toast.makeText(requireContext(), "Camera Permission Denied", Toast.LENGTH_LONG).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun requestPermissions() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            if (isCameraPermissionGranted()) {
                onCameraPermissionGranted()
            }
        } else {
            mRequestPermission.launch(PermissionsManager.REQUEST_CAMERA_USE)
        }
    }

    private fun isCameraPermissionGranted(): Boolean {
        return permissionsManager.checkCameraPermission(this)
    }

    private fun requestCameraPermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            if (!isCameraPermissionGranted()) {
                mRequestPermission.launch(PermissionsManager.REQUEST_CAMERA_USE)
            } else {
                onCameraPermissionGranted()
            }
        } else {
            if (isCameraPermissionGranted()) {
                onCameraPermissionGranted()
            } else {
                requestPermissions()
            }
        }
    }

    private fun showAlertDialog(message: String, buttonName: String) {
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        builder.setMessage(message)
        builder.setCancelable(true)
        builder.setNegativeButton(
            buttonName
        ) { dialog, _ -> dialog.cancel() }

        val alertDialog: AlertDialog = builder.create()
        alertDialog.show()
    }

    override fun onDestroy() {
        super.onDestroy()
        webSocketManager.close()
        //rtcClient?.stop()
    }

    companion object {
        const val UI_HOLDER = "UI_HOLDER"

        fun newInstance(uiHolder: UIHolder?): FBCameraFragment {
            val fragment = FBCameraFragment()
            val bundle = Bundle().apply {
                putParcelable(UI_HOLDER, uiHolder)
            }
            fragment.arguments = bundle
            return fragment
        }
    }
}