package com.formbuilder.sdk.utils.managers

object ProcessResult {
    private var result: (( Boolean, String) -> Unit)? = null

    fun setProcessResult(isSuccessful: Boolean, message: String = "") {
        result?.invoke(isSuccessful, message)
    }

    fun getProcessResultCallback(callback: (Boolean, String) -> Unit) {
        this.result = callback
    }
}