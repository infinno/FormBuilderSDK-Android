package com.formbuilder.sdk.data.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

@Parcelize
data class FBSettings(
    @SerializedName("noCameraDirectionId")
    val noCameraDirectionId: String?,
    @SerializedName("noCameraAccessDirectionStepId")
    val noCameraAccessDirectionStepId: String?,
    @SerializedName("noServiceDirectionStepId")
    val noServiceDirectionStepId: String?,
    @SerializedName("idFaceFailDirectionStepId")
    val idFaceFailDirectionStepId: String?,
    @SerializedName("idBackFailDirectionStepId")
    val idBackFailDirectionStepId: String?,
    @SerializedName("streamUrl")
    val streamUrl: String?,
    @SerializedName("products")
    val products: List<SettingsProduct>?,
    @SerializedName("calculatorSubmitDirectionStepId")
    val calculatorSubmitDirectionStepId: String?,
    @SerializedName("noFaceDirectionStepId")
    val noFaceDirectionStepId: String?,
    @SerializedName("livenessFailDirectionStepId")
    val livenessFailDirectionStepId: String?,
    @SerializedName("userHash")
    val userHash: String?,
    @SerializedName("signallingUrl")
    val signallingUrl: String?,
    @SerializedName("endUserCreditProductSelection")
    val endUserCreditProductSelection: String?,
    @SerializedName("failedNoVideoStream")
    val failedNoVideoStream: String?,
    @SerializedName("failedNoServiceAttemptsUpDirectionId")
    val failedNoServiceAttemptsUpDirectionId: String?,
    @SerializedName("idType")//: null
    val idType: String?,
    @SerializedName("creditProductType")
    val creditProductType: String?
) : Parcelable {
}