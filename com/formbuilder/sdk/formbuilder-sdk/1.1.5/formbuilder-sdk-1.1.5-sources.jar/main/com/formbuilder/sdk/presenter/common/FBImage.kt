package com.formbuilder.sdk.presenter.common

interface FBImage: FBView {
    fun setImage(url: String?)
    fun setWidth(widthPercent: Int?)
    fun setAlignment(alignment: String?)
}