package com.formbuilder.sdk.data.models

import com.google.gson.annotations.SerializedName

data class StartFormRequest(
    @SerializedName("processId")
    val processId: String,
    @SerializedName("callingServiceToken")
    val callingServiceToken: String? = null
)