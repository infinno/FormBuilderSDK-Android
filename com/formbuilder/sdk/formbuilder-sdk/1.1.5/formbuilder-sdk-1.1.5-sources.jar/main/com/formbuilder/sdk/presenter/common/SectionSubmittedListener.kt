package com.formbuilder.sdk.presenter.common

import com.formbuilder.sdk.data.models.StepField

interface SectionSubmittedListener {
    fun onSectionSubmittedWithValidAnswers(
        submissionId: String,
        directionId: String,
        fromDirectionId: String,
        fromFlowDirectionId: String,
        answers: List<StepField>,
        activityId: Int? = null
    )
}